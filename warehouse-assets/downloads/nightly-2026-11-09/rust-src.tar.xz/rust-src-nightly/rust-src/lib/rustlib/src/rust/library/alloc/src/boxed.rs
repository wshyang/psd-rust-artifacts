//! The `Box<T>` type for heap allocation.
//!
//! [`Box<T>`], casually referred to as a 'box', provides the simplest form of
//! heap allocation in Rust. Boxes provide ownership for this allocation, and
//! drop their contents when they go out of scope. Boxes also ensure that they
//! never allocate more than `isize::MAX` bytes.
//!
//! # Examples
//!
//! Move a value from the stack to the heap by creating a [`Box`]:
//!
//! ```
//! let val: u8 = 5;
//! let boxed: Box<u8> = Box::new(val);
//! ```
//!
//! Move a value from a [`Box`] back to the stack by [dereferencing]:
//!
//! ```
//! let boxed: Box<u8> = Box::new(5);
//! let val: u8 = *boxed;
//! ```
//!
//! Creating a recursive data structure:
//!
//! ```
//! # #[allow(dead_code)]
//! #[derive(Debug)]
//! enum List<T> {
//!     Cons(T, Box<List<T>>),
//!     Nil,
//! }
//!
//! let list: List<i32> = List::Cons(1, Box::new(List::Cons(2, Box::new(List::Nil))));
//! println!("{list:?}");
//! ```
//!
//! This will print `Cons(1, Cons(2, Nil))`.
//!
//! Recursive structures must be boxed, because if the definition of `Cons`
//! looked like this:
//!
//! ```compile_fail,E0072
//! # enum List<T> {
//! Cons(T, List<T>),
//! # }
//! ```
//!
//! It wouldn't work. This is because the size of a `List` depends on how many
//! elements are in the list, and so we don't know how much memory to allocate
//! for a `Cons`. By introducing a [`Box<T>`], which has a defined size, we know how
//! big `Cons` needs to be.
//!
//! # Memory layout
//!
//! For non-zero-sized values, a [`Box<T, A>`] will use its allocator of type `A` for its allocation.
//! It is valid to convert both ways between a `Box` and a raw pointer allocated with `A`, so long as:
//! - the size of the pointee, as reported by [`size_of_val`], is non-zero,
//! - the [`Layout::for_value`] of the pointee [*fits*](Allocator#memory-fitting) the memory block, and
//! - the pointee is a valid instance of `T` (for the given metadata of the pointer).
//!
//! For zero-sized values, a [`Box<T, A>`] may use any sufficiently aligned non-null pointer.
//! While it is sound to convert a zero-sized allocation from `A` into a `Box`, as
//! long as it is backed by a valid value of `T`, doing so may lead to memory leaks, as
//! the destructor of [`Box`] will not call [`deallocate`](Allocator::deallocate)
//! on zero-sized values. It is recommended to use [`ptr::dangling`] instead.
//!
//! Likewise, manually deallocating the raw pointer acquired from a `Box` is only sound
//! if the size of the pointee is non-zero, as zero-sized values may be represented by
//! a pointer that is not [*currently allocated*] by that allocator. It is recommended to
//! pair [`Box::into_raw_with_allocator`] with [`Box::from_raw_in`], rather than
//! doing this.
//!
//! Note that even the [`Global`] allocator might not use dangling pointers for
//! zero-sized allocations, even though *most* implementations do this.
//!
//! So long as `T: Sized`, a `Box<T>` is guaranteed to be represented
//! as a single pointer and is also ABI-compatible with C pointers
//! (i.e. the C type `T*`). This means that if you have extern "C"
//! Rust functions that will be called from C, you can define those
//! Rust functions using `Box<T>` types, and use `T*` as corresponding
//! type on the C side. As an example, consider this C header which
//! declares functions that create and destroy some kind of `Foo`
//! value:
//!
//! ```c
//! /* C header */
//!
//! /* Returns ownership to the caller */
//! struct Foo* foo_new(void);
//!
//! /* Takes ownership from the caller; no-op when invoked with null */
//! void foo_delete(struct Foo*);
//! ```
//!
//! These two functions might be implemented in Rust as follows. Here, the
//! `struct Foo*` type from C is translated to `Box<Foo>`, which captures
//! the ownership constraints. Note also that the nullable argument to
//! `foo_delete` is represented in Rust as `Option<Box<Foo>>`, since `Box<Foo>`
//! cannot be null.
//!
//! ```
//! #[repr(C)]
//! pub struct Foo;
//!
//! #[unsafe(no_mangle)]
//! pub extern "C" fn foo_new() -> Box<Foo> {
//!     Box::new(Foo)
//! }
//!
//! #[unsafe(no_mangle)]
//! pub extern "C" fn foo_delete(_: Option<Box<Foo>>) {}
//! ```
//!
//! Even though `Box<T>` has the same representation and C ABI as a C pointer,
//! this does not mean that you can convert an arbitrary `T*` into a `Box<T>`
//! and expect things to work. `Box<T>` values will always be fully aligned,
//! non-null pointers. Moreover, the destructor for `Box<T>` will attempt to
//! free the value with the global allocator. In general, the best practice
//! is to only use `Box<T>` for pointers that originated from the global
//! allocator.
//!
//! **Important.** At least at present, you should avoid using
//! `Box<T>` types for functions that are defined in C but invoked
//! from Rust. In those cases, you should directly mirror the C types
//! as closely as possible. Using types like `Box<T>` where the C
//! definition is just using `T*` can lead to undefined behavior, as
//! described in [rust-lang/unsafe-code-guidelines#198][ucg#198].
//!
//! # Considerations for unsafe code
//!
//! **Warning: This section is not normative and is subject to change, possibly
//! being relaxed in the future! It is a simplified summary of the rules
//! currently implemented in the compiler.**
//!
//! The aliasing rules for `Box<T>` are the same as for `&mut T`. `Box<T>`
//! asserts uniqueness over its content. Using raw pointers derived from a box
//! after that box has been mutated through, moved or borrowed as `&mut T`
//! is not allowed. For more guidance on working with box from unsafe code, see
//! [rust-lang/unsafe-code-guidelines#326][ucg#326].
//!
//! # Editions
//!
//! A special case exists for the implementation of `IntoIterator` for arrays on the Rust 2021
//! edition, as documented [here][array]. Unfortunately, it was later found that a similar
//! workaround should be added for boxed slices, and this was applied in the 2024 edition.
//!
//! Specifically, `IntoIterator` is implemented for `Box<[T]>` on all editions, but specific calls
//! to `into_iter()` for boxed slices will defer to the slice implementation on editions before
//! 2024:
//!
//! ```rust,edition2021
//! // Rust 2015, 2018, and 2021:
//!
//! # #![allow(boxed_slice_into_iter)] // override our `deny(warnings)`
//! let boxed_slice: Box<[i32]> = vec![0; 3].into_boxed_slice();
//!
//! // This creates a slice iterator, producing references to each value.
//! for item in boxed_slice.into_iter().enumerate() {
//!     let (i, x): (usize, &i32) = item;
//!     println!("boxed_slice[{i}] = {x}");
//! }
//!
//! // The `boxed_slice_into_iter` lint suggests this change for future compatibility:
//! for item in boxed_slice.iter().enumerate() {
//!     let (i, x): (usize, &i32) = item;
//!     println!("boxed_slice[{i}] = {x}");
//! }
//!
//! // You can explicitly iterate a boxed slice by value using `IntoIterator::into_iter`
//! for item in IntoIterator::into_iter(boxed_slice).enumerate() {
//!     let (i, x): (usize, i32) = item;
//!     println!("boxed_slice[{i}] = {x}");
//! }
//! ```
//!
//! Similar to the array implementation, this may be modified in the future to remove this override,
//! and it's best to avoid relying on this edition-dependent behavior if you wish to preserve
//! compatibility with future versions of the compiler.
//!
//! [*currently allocated*]: Allocator#currently-allocated-memory
//! [ucg#198]: https://github.com/rust-lang/unsafe-code-guidelines/issues/198
//! [ucg#326]: https://github.com/rust-lang/unsafe-code-guidelines/issues/326
//! [dereferencing]: core::ops::Deref
//! [`Box::<T>::from_raw(value)`]: Box::from_raw
//! [`Global`]: crate::alloc::Global
//! [`Layout`]: crate::alloc::Layout
//! [`Layout::for_value(&*value)`]: crate::alloc::Layout::for_value
//! [valid]: ptr#safety

#![stable(feature = "rust1", since = "1.0.0")]

use core::borrow::{Borrow, BorrowMut};
use core::clone::CloneToUninit;
use core::cmp::Ordering;
use core::error::{self, Error};
use core::fmt;
use core::future::Future;
use core::hash::{Hash, Hasher};
use core::marker::{PhantomData, Tuple, Unsize};
#[cfg(not(no_global_oom_handling))]
use core::mem::MaybeUninit;
use core::mem::{self, SizedTypeProperties};
use core::ops::{
    AsyncFn, AsyncFnMut, AsyncFnOnce, CoerceUnsized, Coroutine, CoroutineState, Deref, DerefMut,
    DerefPure, DispatchFromDyn, LegacyReceiver,
};
#[cfg(not(no_global_oom_handling))]
use core::ops::{Residual, Try};
use core::pin::{Pin, PinSafePointer};
use core::ptr::{self, NonNull};
use core::task::{Context, Poll};

#[cfg(not(no_global_oom_handling))]
use crate::alloc::handle_alloc_error;
use crate::alloc::{AllocError, Allocator, AllocatorNightly, Global, Layout, StaticAllocator};
use crate::raw_vec::RawVec;
#[cfg(not(no_global_oom_handling))]
use crate::str::from_boxed_utf8_unchecked_in;

/// Conversion related impls for `Box<_>` (`From`, `downcast`, etc)
mod convert;
/// Iterator related impls for `Box<_>`.
mod iter;
/// [`ThinBox`] implementation.
mod thin;

#[stable(feature = "boxed_array_value_iter", since = "1.99.0")]
pub use iter::BoxedArrayIntoIter;
#[unstable(feature = "thin_box", issue = "92791")]
pub use thin::ThinBox;

/// An internal wrapper for the pointer + `PhantomData` inside a `Box`.
/// This type has no semantic meaning. It only exists because the layout of
/// `Box` is hard-coded into the compiler, and because moving the
/// auto trait impls to `Box` would cause regressions (#162850).
#[repr(transparent)]
struct BoxRaw<T: ?Sized> {
    pointer: NonNull<T>,
    _marker: PhantomData<T>,
}

unsafe impl<T: ?Sized + Send> Send for BoxRaw<T> {}
unsafe impl<T: ?Sized + Sync> Sync for BoxRaw<T> {}
impl<T: ?Sized + core::panic::UnwindSafe> core::panic::UnwindSafe for BoxRaw<T> {}
impl<T: ?Sized, U: ?Sized> CoerceUnsized<BoxRaw<U>> for BoxRaw<T> where T: Unsize<U> {}
impl<T: ?Sized, U: ?Sized> DispatchFromDyn<BoxRaw<U>> for BoxRaw<T> where T: Unsize<U> {}

impl<T: ?Sized> BoxRaw<T> {
    /// # Safety
    /// `ptr` must be non-null
    #[inline]
    const unsafe fn new_unchecked(ptr: *mut T) -> Self {
        // SAFETY: Upheld by the caller
        unsafe { BoxRaw { pointer: NonNull::new_unchecked(ptr), _marker: PhantomData } }
    }

    #[inline]
    const fn cast<U>(self) -> BoxRaw<U> {
        BoxRaw { pointer: self.pointer.cast(), _marker: PhantomData }
    }

    #[inline]
    const fn as_non_null_ptr(self) -> NonNull<T> {
        self.pointer
    }

    #[inline]
    const fn as_ptr(self) -> *mut T {
        self.pointer.as_ptr()
    }

    #[inline]
    #[cfg(not(no_global_oom_handling))]
    const fn dangling() -> Self
    where
        T: Sized,
    {
        BoxRaw { pointer: NonNull::dangling(), _marker: PhantomData }
    }
}

impl<T: ?Sized> Clone for BoxRaw<T> {
    fn clone(&self) -> Self {
        *self
    }
}
impl<T: ?Sized> Copy for BoxRaw<T> {}

#[expect(ineffective_unstable_trait_impl, reason = "See #164109")]
#[unstable(feature = "box_internals", issue = "none")]
impl<T: ?Sized> From<BoxRaw<T>> for NonNull<T> {
    fn from(value: BoxRaw<T>) -> Self {
        value.as_non_null_ptr()
    }
}

/// A pointer type that uniquely owns a heap allocation of type `T`.
///
/// See the [module-level documentation](../../std/boxed/index.html) for more.
#[lang = "owned_box"]
#[fundamental]
#[stable(feature = "rust1", since = "1.0.0")]
#[rustc_insignificant_dtor]
#[doc(search_unbox)]
// The declaration of the `Box` struct must be kept in sync with the
// compiler or ICEs will happen.
pub struct Box<
    #[rustc_assert_variance(covariant)] T: ?Sized,
    #[stable(feature = "allocator_api", since = "1.100.0")] A: Allocator = Global,
>(BoxRaw<T>, A);

/// Monomorphic function for allocating an uninit `Box`.
#[inline]
// The is a separate function to avoid doing it in every generic version, but it
// looks small to the mir inliner (particularly in panic=abort) so leave it to
// the backend to decide whether pulling it in everywhere is worth doing.
#[rustc_no_mir_inline]
#[cfg_attr(miri, track_caller)] // even without panics, this helps for Miri backtraces
#[cfg(not(no_global_oom_handling))]
#[rustc_const_unstable(feature = "const_heap", issue = "79597")]
const fn box_new_uninit(layout: Layout) -> *mut u8 {
    if layout.size() == 0 {
        return layout.dangling_ptr().as_ptr();
    }
    match Global.allocate(layout) {
        Ok(ptr) => ptr.as_mut_ptr(),
        Err(_) => handle_alloc_error(layout),
    }
}

/// Helper for `vec!`.
///
/// This is unsafe, but has to be marked as safe or else we couldn't use it in `vec!`.
#[doc(hidden)]
#[unstable(feature = "liballoc_internals", issue = "none")]
#[rustc_const_unstable(feature = "const_heap", issue = "79597")]
#[inline(always)]
#[cfg(not(no_global_oom_handling))]
#[rustc_diagnostic_item = "box_assume_init_into_vec_unsafe"]
pub const fn box_assume_init_into_vec_unsafe<T, const N: usize>(
    b: Box<MaybeUninit<[T; N]>>,
) -> crate::vec::Vec<T> {
    // SAFETY: Technically not, but this can't be
    // called stably except in ways we control.
    unsafe { (b.assume_init() as Box<[T]>).into_vec() }
}

impl<T> Box<T> {
    /// Allocates memory on the heap and then places `x` into it.
    ///
    /// This doesn't actually allocate if `T` is zero-sized.
    /// See the [memory layout] section for more details.
    ///
    /// # Examples
    ///
    /// ```
    /// let five = Box::new(5);
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    #[cfg(not(no_global_oom_handling))]
    #[inline(always)]
    #[stable(feature = "rust1", since = "1.0.0")]
    #[must_use]
    #[rustc_diagnostic_item = "box_new"]
    #[cfg_attr(miri, track_caller)] // even without panics, this helps for Miri backtraces
    pub fn new(x: T) -> Self {
        // This is `Box::new_uninit` but inlined to avoid build time regressions.
        let ptr = box_new_uninit(<T as SizedTypeProperties>::LAYOUT) as *mut T;
        // Nothing below can panic so we do not have to worry about deallocating `ptr`.
        // SAFETY: we just allocated the box to store `x`.
        unsafe { core::intrinsics::write_via_move(ptr, x) };
        // SAFETY: we just initialized the memory `ptr` points to.
        unsafe { mem::transmute(ptr) }
    }

    /// Constructs a new box with uninitialized contents.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut five = Box::<u32>::new_uninit();
    /// // Deferred initialization:
    /// five.write(5);
    /// let five = unsafe { five.assume_init() };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[cfg(not(no_global_oom_handling))]
    #[stable(feature = "new_uninit", since = "1.82.0")]
    #[rustc_const_unstable(feature = "const_heap", issue = "79597")]
    #[must_use]
    #[inline(always)]
    #[cfg_attr(miri, track_caller)] // even without panics, this helps for Miri backtraces
    pub const fn new_uninit() -> Box<mem::MaybeUninit<T>> {
        // This is the same as `Self::new_uninit_in(Global)`, but manually inlined (just like
        // `Box::new`).

        // SAFETY:
        // - If `allocate` succeeds, the returned pointer exactly matches what `Box` needs.
        unsafe { mem::transmute(box_new_uninit(<T as SizedTypeProperties>::LAYOUT)) }
    }

    /// Constructs a new `Box` with uninitialized contents, with the memory
    /// being filled with `0` bytes.
    ///
    /// See [`MaybeUninit::zeroed`][zeroed] for examples of correct and incorrect usage
    /// of this method.
    ///
    /// # Examples
    ///
    /// ```
    /// let zero = Box::<u32>::new_zeroed();
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    #[cfg(not(no_global_oom_handling))]
    #[inline]
    #[stable(feature = "new_zeroed_alloc", since = "1.92.0")]
    #[must_use]
    pub fn new_zeroed() -> Box<mem::MaybeUninit<T>> {
        Self::new_zeroed_in(Global)
    }

    /// Constructs a new `Pin<Box<T>>`. If `T` does not implement [`Unpin`], then
    /// `x` will be pinned in memory and unable to be moved.
    ///
    /// Constructing and pinning of the `Box` can also be done in two steps: `Box::pin(x)`
    /// does the same as <code>[Box::into_pin]\([Box::new]\(x))</code>. Consider using
    /// [`into_pin`](Box::into_pin) if you already have a `Box<T>`, or if you want to
    /// construct a (pinned) `Box` in a different way than with [`Box::new`].
    #[cfg(not(no_global_oom_handling))]
    #[stable(feature = "pin", since = "1.33.0")]
    #[must_use]
    #[inline(always)]
    pub fn pin(x: T) -> Pin<Box<T>> {
        Box::new(x).into()
    }

    /// Allocates memory on the heap then places `x` into it,
    /// returning an error if the allocation fails
    ///
    /// This doesn't actually allocate if `T` is zero-sized.
    /// See the [memory layout] section for more details.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_ext)]
    ///
    /// let five = Box::try_new(5)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    #[unstable(feature = "allocator_ext", issue = "163177", implied_by = "allocator_api")]
    #[inline]
    pub fn try_new(x: T) -> Result<Self, AllocError> {
        Self::try_new_in(x, Global)
    }

    /// Constructs a new box with uninitialized contents on the heap,
    /// returning an error if the allocation fails
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_ext)]
    ///
    /// let mut five = Box::<u32>::try_new_uninit()?;
    /// // Deferred initialization:
    /// five.write(5);
    /// let five = unsafe { five.assume_init() };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_ext", issue = "163177", implied_by = "allocator_api")]
    #[inline]
    pub fn try_new_uninit() -> Result<Box<mem::MaybeUninit<T>>, AllocError> {
        Box::try_new_uninit_in(Global)
    }

    /// Constructs a new `Box` with uninitialized contents, with the memory
    /// being filled with `0` bytes on the heap
    ///
    /// See [`MaybeUninit::zeroed`][zeroed] for examples of correct and incorrect usage
    /// of this method.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_ext)]
    ///
    /// let zero = Box::<u32>::try_new_zeroed()?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    #[unstable(feature = "allocator_ext", issue = "163177", implied_by = "allocator_api")]
    #[inline]
    pub fn try_new_zeroed() -> Result<Box<mem::MaybeUninit<T>>, AllocError> {
        Box::try_new_zeroed_in(Global)
    }
}

impl<T, A: Allocator> Box<T, A> {
    /// Allocates memory in the given allocator then places `x` into it.
    ///
    /// This doesn't actually allocate if `T` is zero-sized.
    /// See the [memory layout] section for more details.
    ///
    /// # Examples
    ///
    /// ```
    /// use std::alloc::System;
    ///
    /// let five = Box::new_in(5, System);
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    #[cfg(not(no_global_oom_handling))]
    #[stable(feature = "allocator_api", since = "1.100.0")]
    #[must_use]
    #[inline]
    pub fn new_in(x: T, alloc: A) -> Self {
        let mut boxed = Self::new_uninit_in(alloc);
        boxed.write(x);
        // SAFETY: Initialised by the above.
        unsafe { boxed.assume_init() }
    }

    /// Allocates memory in the given allocator then places `x` into it,
    /// returning an error if the allocation fails
    ///
    /// This doesn't actually allocate if `T` is zero-sized.
    /// See the [memory layout] section for more details.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_ext)]
    ///
    /// use std::alloc::System;
    ///
    /// let five = Box::try_new_in(5, System)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    #[unstable(feature = "allocator_ext", issue = "163177", implied_by = "allocator_api")]
    #[inline]
    pub fn try_new_in(x: T, alloc: A) -> Result<Self, AllocError> {
        let mut boxed = Self::try_new_uninit_in(alloc)?;
        boxed.write(x);
        // SAFETY: Initialised by the above.
        unsafe { Ok(boxed.assume_init()) }
    }

    /// Constructs a new box with uninitialized contents in the provided allocator.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_ext)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut five = Box::<u32, _>::new_uninit_in(System);
    /// // Deferred initialization:
    /// five.write(5);
    /// let five = unsafe { five.assume_init() };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[unstable(feature = "allocator_ext", issue = "163177", implied_by = "allocator_api")]
    #[cfg(not(no_global_oom_handling))]
    #[must_use]
    pub fn new_uninit_in(alloc: A) -> Box<mem::MaybeUninit<T>, A> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        // NOTE: Prefer match over unwrap_or_else since closure sometimes not inlineable.
        // That would make code size bigger.
        match Box::try_new_uninit_in(alloc) {
            Ok(m) => m,
            Err(_) => handle_alloc_error(layout),
        }
    }

    /// Constructs a new box with uninitialized contents in the provided allocator,
    /// returning an error if the allocation fails
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_ext)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut five = Box::<u32, _>::try_new_uninit_in(System)?;
    /// // Deferred initialization:
    /// five.write(5);
    /// let five = unsafe { five.assume_init() };
    ///
    /// assert_eq!(*five, 5);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_ext", issue = "163177", implied_by = "allocator_api")]
    pub fn try_new_uninit_in(alloc: A) -> Result<Box<mem::MaybeUninit<T>, A>, AllocError> {
        let ptr = if T::IS_ZST {
            NonNull::dangling()
        } else {
            let layout = Layout::new::<mem::MaybeUninit<T>>();
            alloc.allocate(layout)?.cast()
        };
        // SAFETY: Pointer is nonnull and matches the allocator.
        unsafe { Ok(Box::from_raw_in(ptr.as_ptr(), alloc)) }
    }

    /// Constructs a new `Box` with uninitialized contents, with the memory
    /// being filled with `0` bytes in the provided allocator.
    ///
    /// See [`MaybeUninit::zeroed`][zeroed] for examples of correct and incorrect usage
    /// of this method.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_ext)]
    ///
    /// use std::alloc::System;
    ///
    /// let zero = Box::<u32, _>::new_zeroed_in(System);
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0)
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    #[unstable(feature = "allocator_ext", issue = "163177", implied_by = "allocator_api")]
    #[cfg(not(no_global_oom_handling))]
    #[must_use]
    pub fn new_zeroed_in(alloc: A) -> Box<mem::MaybeUninit<T>, A> {
        let layout = Layout::new::<mem::MaybeUninit<T>>();
        // NOTE: Prefer match over unwrap_or_else since closure sometimes not inlineable.
        // That would make code size bigger.
        match Box::try_new_zeroed_in(alloc) {
            Ok(m) => m,
            Err(_) => handle_alloc_error(layout),
        }
    }

    /// Constructs a new `Box` with uninitialized contents, with the memory
    /// being filled with `0` bytes in the provided allocator,
    /// returning an error if the allocation fails,
    ///
    /// See [`MaybeUninit::zeroed`][zeroed] for examples of correct and incorrect usage
    /// of this method.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_ext)]
    ///
    /// use std::alloc::System;
    ///
    /// let zero = Box::<u32, _>::try_new_zeroed_in(System)?;
    /// let zero = unsafe { zero.assume_init() };
    ///
    /// assert_eq!(*zero, 0);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    #[unstable(feature = "allocator_ext", issue = "163177", implied_by = "allocator_api")]
    pub fn try_new_zeroed_in(alloc: A) -> Result<Box<mem::MaybeUninit<T>, A>, AllocError> {
        let ptr = if T::IS_ZST {
            NonNull::dangling()
        } else {
            let layout = Layout::new::<mem::MaybeUninit<T>>();
            alloc.allocate_zeroed(layout)?.cast()
        };
        // SAFETY: Pointer is nonnull and matches the allocator.
        unsafe { Ok(Box::from_raw_in(ptr.as_ptr(), alloc)) }
    }

    /// Constructs a new `Pin<Box<T, A>>`. If `T` does not implement [`Unpin`], then
    /// `x` will be pinned in memory and unable to be moved.
    ///
    /// Constructing and pinning of the `Box` can also be done in two steps: `Box::pin_in(x, alloc)`
    /// does the same as <code>[Box::into_pin]\([Box::new_in]\(x, alloc))</code>. Consider using
    /// [`into_pin`](Box::into_pin) if you already have a `Box<T, A>`, or if you want to
    /// construct a (pinned) `Box` in a different way than with [`Box::new_in`].
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_ext)]
    /// use std::alloc::System;
    ///
    /// let x = Box::pin_in(1, System);
    /// ```
    #[cfg(not(no_global_oom_handling))]
    #[unstable(feature = "allocator_ext", issue = "163177", implied_by = "allocator_api")]
    #[must_use]
    #[inline(always)]
    pub fn pin_in(x: T, alloc: A) -> Pin<Self>
    where
        A: StaticAllocator,
    {
        Self::into_pin(Self::new_in(x, alloc))
    }

    /// Converts a `Box<T>` into a `Box<[T]>`
    ///
    /// This conversion does not allocate on the heap and happens in place.
    #[unstable(feature = "box_into_boxed_slice", issue = "71582")]
    pub fn into_boxed_slice(boxed: Self) -> Box<[T], A> {
        let (raw, alloc) = Box::into_raw_with_allocator(boxed);
        // SAFETY: A pointer to T is also a valid pointer to [T; 1].
        unsafe { Box::from_raw_in(raw as *mut [T; 1], alloc) }
    }

    /// Consumes the `Box`, returning the wrapped value.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(box_into_inner)]
    ///
    /// let c = Box::new(5);
    ///
    /// assert_eq!(Box::into_inner(c), 5);
    /// ```
    #[unstable(feature = "box_into_inner", issue = "80437")]
    #[inline]
    pub fn into_inner(boxed: Self) -> T {
        *boxed
    }

    /// Consumes the `Box` without consuming its allocation, returning the wrapped value and a `Box`
    /// to the uninitialized memory where the wrapped value used to live.
    ///
    /// This can be used together with [`write`](Box::write) to reuse the allocation for multiple
    /// boxed values.
    ///
    /// # Examples
    ///
    /// ```
    /// let c = Box::new(5);
    ///
    /// // take the value out of the box
    /// let (value, uninit) = Box::take(c);
    /// assert_eq!(value, 5);
    ///
    /// // reuse the box for a second value
    /// let c = Box::write(uninit, 6);
    /// assert_eq!(*c, 6);
    /// ```
    #[stable(feature = "box_take", since = "1.100.0")]
    pub fn take(boxed: Self) -> (T, Box<mem::MaybeUninit<T>, A>) {
        // SAFETY: Reading out an initialised value & leaving behind a
        // box with uninit contents.
        unsafe {
            let (raw, alloc) = Box::into_non_null_with_allocator(boxed);
            let value = raw.read();
            let uninit = Box::from_non_null_in(raw.cast_uninit(), alloc);
            (value, uninit)
        }
    }

    /// Maps the value in a box, reusing the allocation if possible.
    ///
    /// `f` is called on the value in the box, and the result is returned, also boxed.
    ///
    /// Note: this is an associated function, which means that you have
    /// to call it as `Box::map(b, f)` instead of `b.map(f)`. This
    /// is so that there is no conflict with a method on the inner type.
    ///
    /// # Examples
    ///
    /// ```
    /// let b = Box::new(7);
    /// let new = Box::map(b, |i| i + 7);
    /// assert_eq!(*new, 14);
    /// ```
    #[cfg(not(no_global_oom_handling))]
    #[stable(feature = "smart_pointer_map", since = "1.100.0")]
    pub fn map<U>(this: Self, f: impl FnOnce(T) -> U) -> Box<U, A> {
        let (value, allocation) = Box::take(this);
        let (raw, alloc) = Box::into_non_null_with_allocator(allocation);
        if size_of::<T>() == size_of::<U>() && align_of::<T>() == align_of::<U>() {
            // SAFETY: We checked that the memory requirements are the same for both types
            // and `raw` is already a valid pointer for the requisite memory.
            let allocation = unsafe { Box::from_non_null_in(raw.cast::<MaybeUninit<U>>(), alloc) };
            Box::write(allocation, f(value))
        } else {
            if size_of::<T>() != 0 {
                // SAFETY: `raw` isn't dangling since it points to a non-zero-sized
                // allocation and is never used again after this point.
                unsafe { alloc.deallocate(raw.cast(), Layout::for_value(&value)) }
            }
            Box::new_in(f(value), alloc)
        }
    }

    /// Attempts to map the value in a box, reusing the allocation if possible.
    ///
    /// `f` is called on the value in the box, and if the operation succeeds, the result is
    /// returned, also boxed.
    ///
    /// Note: this is an associated function, which means that you have
    /// to call it as `Box::try_map(b, f)` instead of `b.try_map(f)`. This
    /// is so that there is no conflict with a method on the inner type.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(smart_pointer_try_map)]
    ///
    /// let b = Box::new(7);
    /// let new = Box::try_map(b, u32::try_from).unwrap();
    /// assert_eq!(*new, 7);
    /// ```
    #[cfg(not(no_global_oom_handling))]
    #[unstable(feature = "smart_pointer_try_map", issue = "144419")]
    pub fn try_map<R>(
        this: Self,
        f: impl FnOnce(T) -> R,
    ) -> <R::Residual as Residual<Box<R::Output, A>>>::TryType
    where
        R: Try,
        R::Residual: Residual<Box<R::Output, A>>,
    {
        let (value, allocation) = Box::take(this);
        let (raw, alloc) = Box::into_non_null_with_allocator(allocation);
        if size_of::<T>() == size_of::<R::Output>() && align_of::<T>() == align_of::<R::Output>() {
            let allocation =
                // SAFETY: We checked that the memory requirements are the same for both types
                // and `raw` is already a valid pointer for the requisite memory.
                unsafe { Box::from_non_null_in(raw.cast::<MaybeUninit<R::Output>>(), alloc) };
            try { Box::write(allocation, f(value)?) }
        } else {
            if size_of::<T>() != 0 {
                // SAFETY: `raw` isn't dangling since it points to a non-zero-sized
                // allocation and is never used again after this point.
                unsafe { alloc.deallocate(raw.cast(), Layout::for_value(&value)) }
            }
            try { Box::new_in(f(value)?, alloc) }
        }
    }
}

impl<T: ?Sized + CloneToUninit> Box<T> {
    /// Allocates memory on the heap then clones `src` into it.
    ///
    /// This doesn't actually allocate if `src` is zero-sized.
    /// See the [memory layout] section for more details.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(clone_from_ref)]
    ///
    /// let hello: Box<str> = Box::clone_from_ref("hello");
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    #[cfg(not(no_global_oom_handling))]
    #[unstable(feature = "clone_from_ref", issue = "149075")]
    #[must_use]
    #[inline]
    pub fn clone_from_ref(src: &T) -> Box<T> {
        Box::clone_from_ref_in(src, Global)
    }

    /// Allocates memory on the heap then clones `src` into it, returning an error if allocation fails.
    ///
    /// This doesn't actually allocate if `src` is zero-sized.
    /// See the [memory layout] section for more details.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(clone_from_ref)]
    ///
    /// let hello: Box<str> = Box::try_clone_from_ref("hello")?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    #[unstable(feature = "clone_from_ref", issue = "149075")]
    //#[unstable(feature = "allocator_ext", issue = "163177", implied_by = "allocator_api")]
    #[inline]
    pub fn try_clone_from_ref(src: &T) -> Result<Box<T>, AllocError> {
        Box::try_clone_from_ref_in(src, Global)
    }
}

impl<T: ?Sized + CloneToUninit, A: Allocator> Box<T, A> {
    /// Allocates memory in the given allocator then clones `src` into it.
    ///
    /// This doesn't actually allocate if `src` is zero-sized.
    /// See the [memory layout] section for more details.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(clone_from_ref)]
    ///
    /// use std::alloc::System;
    ///
    /// let hello: Box<str, System> = Box::clone_from_ref_in("hello", System);
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    #[cfg(not(no_global_oom_handling))]
    #[unstable(feature = "clone_from_ref", issue = "149075")]
    //#[unstable(feature = "allocator_ext", issue = "163177", implied_by = "allocator_api")]
    #[must_use]
    #[inline]
    pub fn clone_from_ref_in(src: &T, alloc: A) -> Box<T, A> {
        let layout = Layout::for_value::<T>(src);
        match Box::try_clone_from_ref_in(src, alloc) {
            Ok(bx) => bx,
            Err(_) => handle_alloc_error(layout),
        }
    }

    /// Allocates memory in the given allocator then clones `src` into it, returning an error if allocation fails.
    ///
    /// This doesn't actually allocate if `src` is zero-sized.
    /// See the [memory layout] section for more details.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(clone_from_ref)]
    ///
    /// use std::alloc::System;
    ///
    /// let hello: Box<str, System> = Box::try_clone_from_ref_in("hello", System)?;
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    #[unstable(feature = "clone_from_ref", issue = "149075")]
    //#[unstable(feature = "allocator_ext", issue = "163177", implied_by = "allocator_api")]
    #[inline]
    pub fn try_clone_from_ref_in(src: &T, alloc: A) -> Result<Box<T, A>, AllocError> {
        struct DeallocDropGuard<'a, A: Allocator>(Layout, &'a A, NonNull<u8>);
        impl<'a, A: Allocator> Drop for DeallocDropGuard<'a, A> {
            fn drop(&mut self) {
                let &mut DeallocDropGuard(layout, alloc, ptr) = self;
                // SAFETY: `ptr` was allocated by `*alloc` with layout `layout`
                unsafe {
                    alloc.deallocate(ptr, layout);
                }
            }
        }
        let layout = Layout::for_value::<T>(src);
        let (ptr, guard) = if layout.size() == 0 {
            (layout.dangling_ptr(), None)
        } else {
            // Safety: layout is non-zero-sized
            let ptr = alloc.allocate(layout)?.cast();
            (ptr, Some(DeallocDropGuard(layout, &alloc, ptr)))
        };
        let ptr = ptr.as_ptr();
        // SAFETY: `*ptr` is newly allocated (or a ZST), correctly aligned to
        // `align_of_val(src)`, and is valid for writes for `size_of_val(src)`.
        // If this panics, then `guard` will deallocate for us (if allocation occuured)
        unsafe {
            <T as CloneToUninit>::clone_to_uninit(src, ptr);
        }
        // Defuse the deallocate guard
        core::mem::forget(guard);
        // SAFETY: We just initialized `*ptr` as a clone of `src`
        Ok(unsafe { Box::from_raw_in(ptr.with_metadata_of(src), alloc) })
    }
}

impl<T> Box<[T]> {
    /// Constructs a new boxed slice with uninitialized contents.
    ///
    /// # Examples
    ///
    /// ```
    /// let mut values = Box::<[u32]>::new_uninit_slice(3);
    /// // Deferred initialization:
    /// values[0].write(1);
    /// values[1].write(2);
    /// values[2].write(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[cfg(not(no_global_oom_handling))]
    #[stable(feature = "new_uninit", since = "1.82.0")]
    #[must_use]
    pub fn new_uninit_slice(len: usize) -> Box<[mem::MaybeUninit<T>]> {
        // SAFETY: `len` is exactly the capacity of this `RawVec`.
        unsafe { RawVec::with_capacity(len).into_box(len) }
    }

    /// Constructs a new boxed slice with uninitialized contents, with the memory
    /// being filled with `0` bytes.
    ///
    /// See [`MaybeUninit::zeroed`][zeroed] for examples of correct and incorrect usage
    /// of this method.
    ///
    /// # Examples
    ///
    /// ```
    /// let values = Box::<[u32]>::new_zeroed_slice(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    #[cfg(not(no_global_oom_handling))]
    #[stable(feature = "new_zeroed_alloc", since = "1.92.0")]
    #[must_use]
    pub fn new_zeroed_slice(len: usize) -> Box<[mem::MaybeUninit<T>]> {
        // SAFETY: `len` is exactly the capacity of this `RawVec`.
        unsafe { RawVec::with_capacity_zeroed(len).into_box(len) }
    }

    /// Constructs a new boxed slice with uninitialized contents. Returns an error if
    /// the allocation fails.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_ext)]
    ///
    /// let mut values = Box::<[u32]>::try_new_uninit_slice(3)?;
    /// // Deferred initialization:
    /// values[0].write(1);
    /// values[1].write(2);
    /// values[2].write(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [1, 2, 3]);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_ext", issue = "163177", implied_by = "allocator_api")]
    #[inline]
    pub fn try_new_uninit_slice(len: usize) -> Result<Box<[mem::MaybeUninit<T>]>, AllocError> {
        let ptr = if T::IS_ZST || len == 0 {
            NonNull::dangling()
        } else {
            let layout = match Layout::array::<mem::MaybeUninit<T>>(len) {
                Ok(l) => l,
                Err(_) => return Err(AllocError),
            };
            Global.allocate(layout)?.cast()
        };
        // SAFETY: `ptr` was just allocated with `Global` with the layout for an array of length
        // `len`, and the layout creation would have failed if `len` overflowed an isize.
        // `into_box` is sound to call since `len` corresponds to the length of the just-created
        // `RawVec`.
        unsafe { Ok(RawVec::from_raw_parts_in(ptr.as_ptr(), len, Global).into_box(len)) }
    }

    /// Constructs a new boxed slice with uninitialized contents, with the memory
    /// being filled with `0` bytes. Returns an error if the allocation fails.
    ///
    /// See [`MaybeUninit::zeroed`][zeroed] for examples of correct and incorrect usage
    /// of this method.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_ext)]
    ///
    /// let values = Box::<[u32]>::try_new_zeroed_slice(3)?;
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0]);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    #[unstable(feature = "allocator_ext", issue = "163177", implied_by = "allocator_api")]
    #[inline]
    pub fn try_new_zeroed_slice(len: usize) -> Result<Box<[mem::MaybeUninit<T>]>, AllocError> {
        let ptr = if T::IS_ZST || len == 0 {
            NonNull::dangling()
        } else {
            let layout = match Layout::array::<mem::MaybeUninit<T>>(len) {
                Ok(l) => l,
                Err(_) => return Err(AllocError),
            };
            Global.allocate_zeroed(layout)?.cast()
        };
        // SAFETY: `ptr` was just allocated with `Global` with the layout for an array of length
        // `len`, and the layout creation would have failed if `len` overflowed an isize.
        // `into_box` is sound to call since `len` corresponds to the length of the just-created
        // `RawVec`.
        unsafe { Ok(RawVec::from_raw_parts_in(ptr.as_ptr(), len, Global).into_box(len)) }
    }
}

impl<T, A: Allocator> Box<[T], A> {
    /// Constructs a new boxed slice with uninitialized contents in the provided allocator.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_ext)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut values = Box::<[u32], _>::new_uninit_slice_in(3, System);
    /// // Deferred initialization:
    /// values[0].write(1);
    /// values[1].write(2);
    /// values[2].write(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[cfg(not(no_global_oom_handling))]
    #[unstable(feature = "allocator_ext", issue = "163177", implied_by = "allocator_api")]
    #[must_use]
    pub fn new_uninit_slice_in(len: usize, alloc: A) -> Box<[mem::MaybeUninit<T>], A> {
        // SAFETY: `len` is exactly the capacity of this `RawVec`.
        unsafe { RawVec::with_capacity_in(len, alloc).into_box(len) }
    }

    /// Constructs a new boxed slice with uninitialized contents in the provided allocator,
    /// with the memory being filled with `0` bytes.
    ///
    /// See [`MaybeUninit::zeroed`][zeroed] for examples of correct and incorrect usage
    /// of this method.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_ext)]
    ///
    /// use std::alloc::System;
    ///
    /// let values = Box::<[u32], _>::new_zeroed_slice_in(3, System);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0])
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    #[cfg(not(no_global_oom_handling))]
    #[unstable(feature = "allocator_ext", issue = "163177", implied_by = "allocator_api")]
    #[must_use]
    pub fn new_zeroed_slice_in(len: usize, alloc: A) -> Box<[mem::MaybeUninit<T>], A> {
        // SAFETY: `len` is exactly the capacity of this `RawVec`.
        unsafe { RawVec::with_capacity_zeroed_in(len, alloc).into_box(len) }
    }

    /// Constructs a new boxed slice with uninitialized contents in the provided allocator. Returns an error if
    /// the allocation fails.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_ext)]
    ///
    /// use std::alloc::System;
    ///
    /// let mut values = Box::<[u32], _>::try_new_uninit_slice_in(3, System)?;
    /// // Deferred initialization:
    /// values[0].write(1);
    /// values[1].write(2);
    /// values[2].write(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [1, 2, 3]);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    #[unstable(feature = "allocator_ext", issue = "163177", implied_by = "allocator_api")]
    #[inline]
    pub fn try_new_uninit_slice_in(
        len: usize,
        alloc: A,
    ) -> Result<Box<[mem::MaybeUninit<T>], A>, AllocError> {
        let ptr = if T::IS_ZST || len == 0 {
            NonNull::dangling()
        } else {
            let layout = match Layout::array::<mem::MaybeUninit<T>>(len) {
                Ok(l) => l,
                Err(_) => return Err(AllocError),
            };
            alloc.allocate(layout)?.cast()
        };
        // SAFETY: `ptr` was just allocated with `alloc` with the layout for an array of length
        // `len`, and the layout creation would have failed if `len` overflowed an isize.
        // `into_box` is sound to call since `len` corresponds to the length of the just-created
        // `RawVec`.
        unsafe { Ok(RawVec::from_raw_parts_in(ptr.as_ptr(), len, alloc).into_box(len)) }
    }

    /// Constructs a new boxed slice with uninitialized contents in the provided allocator, with the memory
    /// being filled with `0` bytes. Returns an error if the allocation fails.
    ///
    /// See [`MaybeUninit::zeroed`][zeroed] for examples of correct and incorrect usage
    /// of this method.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(allocator_ext)]
    ///
    /// use std::alloc::System;
    ///
    /// let values = Box::<[u32], _>::try_new_zeroed_slice_in(3, System)?;
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [0, 0, 0]);
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [zeroed]: mem::MaybeUninit::zeroed
    #[unstable(feature = "allocator_ext", issue = "163177", implied_by = "allocator_api")]
    #[inline]
    pub fn try_new_zeroed_slice_in(
        len: usize,
        alloc: A,
    ) -> Result<Box<[mem::MaybeUninit<T>], A>, AllocError> {
        let ptr = if T::IS_ZST || len == 0 {
            NonNull::dangling()
        } else {
            let layout = match Layout::array::<mem::MaybeUninit<T>>(len) {
                Ok(l) => l,
                Err(_) => return Err(AllocError),
            };
            alloc.allocate_zeroed(layout)?.cast()
        };
        // SAFETY: `ptr` was just allocated with `alloc` with the layout for an array of length
        // `len`, and the layout creation would have failed if `len` overflowed an isize.
        // `into_box` is sound to call since `len` corresponds to the length of the just-created
        // `RawVec`.
        unsafe { Ok(RawVec::from_raw_parts_in(ptr.as_ptr(), len, alloc).into_box(len)) }
    }

    /// Converts the boxed slice into a boxed array.
    ///
    /// This operation does not reallocate; the underlying array of the slice is simply reinterpreted as an array type.
    ///
    /// # Errors
    ///
    /// Returns the original `Box<[T]>` in the `Err` variant if `self.len()` does not equal `N`.
    ///
    /// # Examples
    ///
    /// ```
    /// #![feature(alloc_slice_into_array)]
    /// let box_slice: Box<[i32]> = Box::new([1, 2, 3]);
    ///
    /// let box_array: Box<[i32; 3]> = box_slice.into_array().unwrap();
    /// ```
    #[unstable(feature = "alloc_slice_into_array", issue = "148082")]
    #[inline]
    pub fn into_array<const N: usize>(self) -> Result<Box<[T; N], A>, Self> {
        if self.len() == N {
            let (ptr, alloc) = Self::into_raw_with_allocator(self);
            let ptr = ptr as *mut [T; N];

            // SAFETY: The underlying array of a slice has the exact same layout as an actual array `[T; N]` if `N` is equal to the slice's length.
            let me = unsafe { Box::from_raw_in(ptr, alloc) };
            Ok(me)
        } else {
            Err(self)
        }
    }
}

impl<T, A: Allocator> Box<mem::MaybeUninit<T>, A> {
    /// Converts to `Box<T, A>`.
    ///
    /// # Safety
    ///
    /// As with [`MaybeUninit::assume_init`],
    /// it is up to the caller to guarantee that the value
    /// really is in an initialized state.
    /// Calling this when the content is not yet fully initialized
    /// causes immediate undefined behavior.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// let mut five = Box::<u32>::new_uninit();
    /// // Deferred initialization:
    /// five.write(5);
    /// let five: Box<u32> = unsafe { five.assume_init() };
    ///
    /// assert_eq!(*five, 5)
    /// ```
    #[stable(feature = "new_uninit", since = "1.82.0")]
    #[rustc_const_unstable(feature = "const_heap", issue = "79597")]
    #[inline(always)]
    pub const unsafe fn assume_init(self) -> Box<T, A> {
        // This is used in the `vec!` macro, so we optimize for minimal IR generation
        // even in debug builds.
        // SAFETY: `Box<T>` and `Box<MaybeUninit<T>>` have the same layout.
        unsafe { core::intrinsics::transmute_unchecked(self) }
    }

    /// Writes the value and converts to `Box<T, A>`.
    ///
    /// This method converts the box similarly to [`Box::assume_init`] but
    /// writes `value` into it before conversion thus guaranteeing safety.
    /// In some scenarios use of this method may improve performance because
    /// the compiler may be able to optimize copying from stack.
    ///
    /// # Examples
    ///
    /// ```
    /// let big_box = Box::<[usize; 1024]>::new_uninit();
    ///
    /// let mut array = [0; 1024];
    /// for (i, place) in array.iter_mut().enumerate() {
    ///     *place = i;
    /// }
    ///
    /// // The optimizer may be able to elide this copy, so previous code writes
    /// // to heap directly.
    /// let big_box = Box::write(big_box, array);
    ///
    /// for (i, x) in big_box.iter().enumerate() {
    ///     assert_eq!(*x, i);
    /// }
    /// ```
    #[stable(feature = "box_uninit_write", since = "1.87.0")]
    #[inline]
    pub fn write(mut boxed: Self, value: T) -> Box<T, A> {
        // SAFETY: Writing initialises the boxed value.
        unsafe {
            (*boxed).write(value);
            boxed.assume_init()
        }
    }
}

impl<T, A: Allocator> Box<[mem::MaybeUninit<T>], A> {
    /// Converts to `Box<[T], A>`.
    ///
    /// # Safety
    ///
    /// As with [`MaybeUninit::assume_init`],
    /// it is up to the caller to guarantee that the values
    /// really are in an initialized state.
    /// Calling this when the content is not yet fully initialized
    /// causes immediate undefined behavior.
    ///
    /// [`MaybeUninit::assume_init`]: mem::MaybeUninit::assume_init
    ///
    /// # Examples
    ///
    /// ```
    /// let mut values = Box::<[u32]>::new_uninit_slice(3);
    /// // Deferred initialization:
    /// values[0].write(1);
    /// values[1].write(2);
    /// values[2].write(3);
    /// let values = unsafe { values.assume_init() };
    ///
    /// assert_eq!(*values, [1, 2, 3])
    /// ```
    #[stable(feature = "new_uninit", since = "1.82.0")]
    #[inline]
    pub unsafe fn assume_init(self) -> Box<[T], A> {
        let (raw, alloc) = Box::into_raw_with_allocator(self);
        // SAFETY: Upheld by caller.
        unsafe { Box::from_raw_in(raw as *mut [T], alloc) }
    }
}

impl<T: ?Sized> Box<T> {
    /// Constructs a box from a raw pointer.
    ///
    /// After calling this function, the raw pointer is owned by the
    /// resulting `Box`. Specifically, the `Box` destructor will call
    /// the destructor of `T` and free the allocated memory. For this
    /// to be safe, the memory must have been allocated in accordance
    /// with the [memory layout] used by `Box` .
    ///
    /// # Safety
    ///
    /// This function is unsafe because improper use may lead to
    /// memory problems. For example, a double-free may occur if the
    /// function is called twice on the same raw pointer.
    ///
    /// The exact safety requirements are described in the [memory layout] section, together
    /// with recommendations about how to handle the special case of zero-sized allocations
    /// correctly.
    ///
    /// In particular, if the size of the pointee, as reported by [`size_of_val`], is
    /// nonzero, then the raw pointer must point to a block of memory allocated by
    /// [`Global`].
    /// If the size of the pointee is zero, then the raw pointer can be any
    /// sufficiently aligned non-null pointer, e.g. [`ptr::dangling`].
    ///
    /// Note that the [considerations for unsafe code] apply to all `Box<T>` values.
    ///
    /// # Examples
    ///
    /// Recreate a `Box` which was previously converted to a raw pointer
    /// using [`Box::into_raw`]:
    /// ```
    /// let x = Box::new(5);
    /// let ptr = Box::into_raw(x);
    /// let x = unsafe { Box::from_raw(ptr) };
    /// ```
    /// Manually create a `Box` from scratch by using the global allocator:
    /// ```
    /// use std::alloc::{alloc, Layout};
    ///
    /// unsafe {
    ///     let ptr = alloc(Layout::new::<i32>()) as *mut i32;
    ///     // In general .write is required to avoid attempting to destruct
    ///     // the (uninitialized) previous contents of `ptr`, though for this
    ///     // simple example `*ptr = 5` would have worked as well.
    ///     ptr.write(5);
    ///     let x = Box::from_raw(ptr);
    /// }
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    /// [considerations for unsafe code]: self#considerations-for-unsafe-code
    #[stable(feature = "box_raw", since = "1.4.0")]
    #[inline]
    #[must_use = "call `drop(Box::from_raw(ptr))` if you intend to drop the `Box`"]
    pub unsafe fn from_raw(raw: *mut T) -> Self {
        // SAFETY: Upheld by caller.
        unsafe { Self::from_raw_in(raw, Global) }
    }

    /// Constructs a box from a `NonNull` pointer.
    ///
    /// After calling this function, the `NonNull` pointer is owned by
    /// the resulting `Box`. Specifically, the `Box` destructor will call
    /// the destructor of `T` and free the allocated memory. For this
    /// to be safe, the memory must have been allocated in accordance
    /// with the [memory layout] used by `Box` .
    ///
    /// # Safety
    ///
    /// This function is unsafe because improper use may lead to
    /// memory problems. For example, a double-free may occur if the
    /// function is called twice on the same `NonNull` pointer.
    ///
    /// The exact safety requirements are described in the [memory layout] section, together
    /// with recommendations about how to handle the special case of zero-sized allocations
    /// correctly.
    ///
    /// In particular, if the size of the pointee, as reported by [`size_of_val`], is
    /// nonzero, then the raw pointer must point to a block of memory allocated by
    /// [`Global`].
    /// If the size of the pointee is zero, then the raw pointer can be any
    /// sufficiently aligned pointer, e.g. [`NonNull::dangling`].
    ///
    /// Note that the [considerations for unsafe code] apply to all `Box<T>` values.
    ///
    /// # Examples
    ///
    /// Recreate a `Box` which was previously converted to a `NonNull`
    /// pointer using [`Box::into_non_null`]:
    /// ```
    /// let x = Box::new(5);
    /// let non_null = Box::into_non_null(x);
    /// let x = unsafe { Box::from_non_null(non_null) };
    /// ```
    /// Manually create a `Box` from scratch by using the global allocator:
    /// ```
    /// use std::alloc::{alloc, Layout};
    /// use std::ptr::NonNull;
    ///
    /// unsafe {
    ///     let non_null = NonNull::new(alloc(Layout::new::<i32>()).cast::<i32>())
    ///         .expect("alloc should have successfully allocated memory");
    ///     // In general .write is required to avoid attempting to destruct
    ///     // the (uninitialized) previous contents of `non_null`.
    ///     non_null.write(5);
    ///     let x = Box::from_non_null(non_null);
    /// }
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    /// [considerations for unsafe code]: self#considerations-for-unsafe-code
    #[stable(feature = "box_vec_non_null", since = "1.99.0")]
    #[inline]
    #[must_use = "call `drop(Box::from_non_null(ptr))` if you intend to drop the `Box`"]
    pub unsafe fn from_non_null(ptr: NonNull<T>) -> Self {
        // SAFETY: Upheld by caller.
        unsafe { Self::from_raw(ptr.as_ptr()) }
    }

    /// Consumes the `Box`, returning a wrapped raw pointer.
    ///
    /// The pointer will be properly aligned and non-null.
    ///
    /// After calling this function, the caller is responsible for the
    /// memory previously managed by the `Box`. In particular, the
    /// caller should properly destroy `T` and release the memory, taking
    /// into account the [memory layout] used by `Box`. The easiest way to
    /// do this is to convert the raw pointer back into a `Box` with the
    /// [`Box::from_raw`] function, allowing the `Box` destructor to perform
    /// the cleanup.
    ///
    /// While manually deallocating the pointer through [`deallocate`]
    /// is possible, you must only do this if the pointee's size, as reported by
    /// [`size_of_val`], is non-zero (the `Box` may be a dangling pointer
    /// otherwise). See the [memory layout] section for more details.
    ///
    /// Note: this is an associated function, which means that you have
    /// to call it as `Box::into_raw(b)` instead of `b.into_raw()`. This
    /// is so that there is no conflict with a method on the inner type.
    ///
    /// # Examples
    /// Converting the raw pointer back into a `Box` with [`Box::from_raw`]
    /// for automatic cleanup:
    /// ```
    /// let x = Box::new(String::from("Hello"));
    /// let ptr = Box::into_raw(x);
    /// let x = unsafe { Box::from_raw(ptr) };
    /// ```
    /// Manual cleanup by explicitly running the destructor and deallocating
    /// the memory:
    /// ```
    /// use std::alloc::{dealloc, Layout};
    /// use std::ptr;
    ///
    /// let x = Box::new(String::from("Hello"));
    /// let ptr = Box::into_raw(x);
    /// unsafe {
    ///     ptr::drop_in_place(ptr);
    ///     dealloc(ptr as *mut u8, Layout::new::<String>());
    /// }
    /// ```
    /// Note: This is equivalent to the following:
    /// ```
    /// let x = Box::new(String::from("Hello"));
    /// let ptr = Box::into_raw(x);
    /// unsafe {
    ///     drop(Box::from_raw(ptr));
    /// }
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    /// [`deallocate`]: Allocator::deallocate
    #[must_use = "losing the pointer will leak memory"]
    #[stable(feature = "box_raw", since = "1.4.0")]
    #[inline]
    pub fn into_raw(b: Self) -> *mut T {
        // Avoid `into_raw_with_allocator` as that interacts poorly with Miri's Stacked Borrows.
        let mut b = mem::ManuallyDrop::new(b);
        // We need to give Miri (specifically, Stacked Borrows) a chance to recognize this as a
        // safe-to-raw-pointer cast. To achieve this, we first create a mutable reference, and then
        // cast that to a raw pointer -- this cast is recognized by the aliasing model and leads to
        // a suitable retag.
        // It would be wrong for `into_raw_with_allocator` to do the same as that would induce
        // uniqueness assumptions (from the `&mut`) that we only want with the default allocator.
        (&mut **b) as *mut T
    }

    /// Consumes the `Box`, returning a wrapped `NonNull` pointer.
    ///
    /// The pointer will be properly aligned.
    ///
    /// After calling this function, the caller is responsible for the
    /// memory previously managed by the `Box`. In particular, the
    /// caller should properly destroy `T` and release the memory, taking
    /// into account the [memory layout] used by `Box`. The easiest way to
    /// do this is to convert the `NonNull` pointer back into a `Box` with the
    /// [`Box::from_non_null`] function, allowing the `Box` destructor to
    /// perform the cleanup.
    ///
    /// While manually deallocating the pointer through [`deallocate`]
    /// is possible, you must only do this if the pointee's size, as reported by
    /// [`size_of_val`], is non-zero (the `Box` may be a dangling pointer
    /// otherwise). See the [memory layout] section for more details.
    ///
    /// Note: this is an associated function, which means that you have
    /// to call it as `Box::into_non_null(b)` instead of `b.into_non_null()`.
    /// This is so that there is no conflict with a method on the inner type.
    ///
    /// # Examples
    /// Converting the `NonNull` pointer back into a `Box` with [`Box::from_non_null`]
    /// for automatic cleanup:
    /// ```
    /// let x = Box::new(String::from("Hello"));
    /// let non_null = Box::into_non_null(x);
    /// let x = unsafe { Box::from_non_null(non_null) };
    /// ```
    /// Manual cleanup by explicitly running the destructor and deallocating
    /// the memory:
    /// ```
    /// use std::alloc::{dealloc, Layout};
    ///
    /// let x = Box::new(String::from("Hello"));
    /// let non_null = Box::into_non_null(x);
    /// unsafe {
    ///     non_null.drop_in_place();
    ///     dealloc(non_null.as_ptr().cast::<u8>(), Layout::new::<String>());
    /// }
    /// ```
    /// Note: This is equivalent to the following:
    /// ```
    /// let x = Box::new(String::from("Hello"));
    /// let non_null = Box::into_non_null(x);
    /// unsafe {
    ///     drop(Box::from_non_null(non_null));
    /// }
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    /// [`deallocate`]: Allocator::deallocate
    #[must_use = "losing the pointer will leak memory"]
    #[stable(feature = "box_vec_non_null", since = "1.99.0")]
    #[inline]
    pub fn into_non_null(b: Self) -> NonNull<T> {
        // As of August 2026, we cannot utilize `Box::leak`
        // because whether or not you can reconstruct the `Box`
        // later using `Box::from_raw` or `Box::from_non_null` is
        // an open question.
        // SAFETY: `Box` is guaranteed to be non-null.
        unsafe { NonNull::new_unchecked(Self::into_raw(b)) }
    }
}

impl<T: ?Sized, A: Allocator> Box<T, A> {
    /// Constructs a box from a raw pointer in the given allocator.
    ///
    /// After calling this function, the raw pointer is owned by the
    /// resulting `Box`. Specifically, the `Box` destructor will call
    /// the destructor of `T` and free the allocated memory, except
    /// in the cases described in the [memory layout] section.
    ///
    /// # Safety
    ///
    /// This function is unsafe because improper use may lead to
    /// memory problems. For example, a double-free may occur if the
    /// function is called twice on the same raw pointer.
    ///
    /// The exact safety requirements are described in the [memory layout] section, together
    /// with recommendations about how to handle the special case of zero-sized allocations
    /// correctly.
    ///
    /// In particular, if the size of the pointee, as reported by [`size_of_val`], is
    /// nonzero, then the raw pointer must point to a block of memory allocated by
    /// `alloc`.
    /// If the size of the pointee is zero, then the raw pointer can be any
    /// sufficiently aligned non-null pointer, e.g. [`ptr::dangling`].
    ///
    /// Note that the [considerations for unsafe code] apply to all `Box<T, A>` values.
    ///
    /// # Examples
    ///
    /// Recreate a `Box` which was previously converted to a raw pointer
    /// using [`Box::into_raw_with_allocator`]:
    /// ```
    /// use std::alloc::System;
    ///
    /// let x = Box::new_in(5, System);
    /// let (ptr, alloc) = Box::into_raw_with_allocator(x);
    /// let x = unsafe { Box::from_raw_in(ptr, alloc) };
    /// ```
    /// Manually create a `Box` from scratch by using the system allocator:
    /// ```
    /// #![feature(slice_ptr_get)]
    ///
    /// use std::alloc::{Allocator, Layout, System};
    ///
    /// unsafe {
    ///     let ptr = System.allocate(Layout::new::<i32>())?.as_mut_ptr() as *mut i32;
    ///     // In general .write is required to avoid attempting to destruct
    ///     // the (uninitialized) previous contents of `ptr`, though for this
    ///     // simple example `*ptr = 5` would have worked as well.
    ///     ptr.write(5);
    ///     let x = Box::from_raw_in(ptr, System);
    /// }
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    /// [considerations for unsafe code]: self#considerations-for-unsafe-code
    #[stable(feature = "allocator_api", since = "1.100.0")]
    #[inline]
    pub unsafe fn from_raw_in(raw: *mut T, alloc: A) -> Self {
        // SAFETY: Upheld by caller.
        Box(unsafe { BoxRaw::new_unchecked(raw) }, alloc)
    }

    /// Constructs a box from a `NonNull` pointer in the given allocator.
    ///
    /// After calling this function, the `NonNull` pointer is owned by
    /// the resulting `Box`. Specifically, the `Box` destructor will call
    /// the destructor of `T` and free the allocated memory, except
    /// in the cases described in the [memory layout] section.
    ///
    /// # Safety
    ///
    /// This function is unsafe because improper use may lead to
    /// memory problems. For example, a double-free may occur if the
    /// function is called twice on the same raw pointer.
    ///
    /// The exact safety requirements are described in the [memory layout] section, together
    /// with recommendations about how to handle the special case of zero-sized allocations
    /// correctly.
    ///
    /// In particular, if the size of the pointee, as reported by [`size_of_val`], is
    /// nonzero, then the raw pointer must point to a block of memory allocated by
    /// `alloc`.
    /// If the size of the pointee is zero, then the raw pointer can be any
    /// sufficiently aligned pointer, e.g. [`NonNull::dangling`].
    ///
    /// Note that the [considerations for unsafe code] apply to all `Box<T, A>` values.
    ///
    /// # Examples
    ///
    /// Recreate a `Box` which was previously converted to a `NonNull` pointer
    /// using [`Box::into_non_null_with_allocator`]:
    /// ```
    /// use std::alloc::System;
    ///
    /// let x = Box::new_in(5, System);
    /// let (non_null, alloc) = Box::into_non_null_with_allocator(x);
    /// let x = unsafe { Box::from_non_null_in(non_null, alloc) };
    /// ```
    /// Manually create a `Box` from scratch by using the system allocator:
    /// ```
    /// use std::alloc::{Allocator, Layout, System};
    ///
    /// unsafe {
    ///     let non_null = System.allocate(Layout::new::<i32>())?.cast::<i32>();
    ///     // In general .write is required to avoid attempting to destruct
    ///     // the (uninitialized) previous contents of `non_null`.
    ///     non_null.write(5);
    ///     let x = Box::from_non_null_in(non_null, System);
    /// }
    /// # Ok::<(), std::alloc::AllocError>(())
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    /// [considerations for unsafe code]: self#considerations-for-unsafe-code
    #[stable(feature = "allocator_api", since = "1.100.0")]
    #[inline]
    pub unsafe fn from_non_null_in(raw: NonNull<T>, alloc: A) -> Self {
        // SAFETY: guaranteed by the caller.
        unsafe { Box::from_raw_in(raw.as_ptr(), alloc) }
    }

    /// Consumes the `Box`, returning a wrapped raw pointer and the allocator.
    ///
    /// The pointer will be properly aligned and non-null.
    ///
    /// After calling this function, the caller is responsible for the
    /// memory previously managed by the `Box`. In particular, the
    /// caller should properly destroy `T` and release the memory, taking
    /// into account the [memory layout] used by `Box`. The easiest way to
    /// do this is to convert the raw pointer back into a `Box` with the
    /// [`Box::from_raw_in`] function, allowing the `Box` destructor to perform
    /// the cleanup.
    ///
    /// While manually deallocating the pointer through [`deallocate`]
    /// is possible, you must only do this if the pointee's size, as reported by
    /// [`size_of_val`], is non-zero (the `Box` may be a dangling pointer
    /// otherwise). See the [memory layout] section for more details.
    ///
    /// Note: this is an associated function, which means that you have
    /// to call it as `Box::into_raw_with_allocator(b)` instead of `b.into_raw_with_allocator()`. This
    /// is so that there is no conflict with a method on the inner type.
    ///
    /// # Examples
    /// Converting the raw pointer back into a `Box` with [`Box::from_raw_in`]
    /// for automatic cleanup:
    /// ```
    /// use std::alloc::System;
    ///
    /// let x = Box::new_in(String::from("Hello"), System);
    /// let (ptr, alloc) = Box::into_raw_with_allocator(x);
    /// let x = unsafe { Box::from_raw_in(ptr, alloc) };
    /// ```
    /// Manual cleanup by explicitly running the destructor and deallocating
    /// the memory:
    /// ```
    /// use std::alloc::{Allocator, Layout, System};
    /// use std::ptr::{self, NonNull};
    ///
    /// let x = Box::new_in(String::from("Hello"), System);
    /// let (ptr, alloc) = Box::into_raw_with_allocator(x);
    /// unsafe {
    ///     ptr::drop_in_place(ptr);
    ///     let non_null = NonNull::new_unchecked(ptr);
    ///     alloc.deallocate(non_null.cast(), Layout::new::<String>());
    /// }
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    /// [`deallocate`]: Allocator::deallocate
    #[must_use = "losing the pointer will leak memory"]
    #[stable(feature = "allocator_api", since = "1.100.0")]
    #[rustc_const_unstable(feature = "const_heap", issue = "79597")]
    #[inline]
    pub const fn into_raw_with_allocator(b: Self) -> (*mut T, A) {
        let mut b = mem::ManuallyDrop::new(b);
        // We carefully get the raw pointer out in a way that Miri's aliasing model understands what
        // is happening: using the primitive "deref" of `Box`. In case `A` is *not* `Global`, we
        // want *no* aliasing requirements here!
        // In case `A` *is* `Global`, this does not quite have the right behavior; `into_raw`
        // works around that.
        let ptr = &raw mut **b;
        // SAFETY: See above.
        let alloc = unsafe { ptr::read(&b.1) };
        (ptr, alloc)
    }

    /// Consumes the `Box`, returning a wrapped `NonNull` pointer and the allocator.
    ///
    /// The pointer will be properly aligned.
    ///
    /// After calling this function, the caller is responsible for the
    /// memory previously managed by the `Box`. In particular, the
    /// caller should properly destroy `T` and release the memory, taking
    /// into account the [memory layout] used by `Box`. The easiest way to
    /// do this is to convert the `NonNull` pointer back into a `Box` with the
    /// [`Box::from_non_null_in`] function, allowing the `Box` destructor to
    /// perform the cleanup.
    ///
    /// While manually deallocating the pointer through [`deallocate`]
    /// is possible, you must only do this if the pointee's size, as reported by
    /// [`size_of_val`], is non-zero (the `Box` may be a dangling pointer
    /// otherwise). See the [memory layout] section for more details.
    ///
    /// Note: this is an associated function, which means that you have
    /// to call it as `Box::into_non_null_with_allocator(b)` instead of
    /// `b.into_non_null_with_allocator()`. This is so that there is no
    /// conflict with a method on the inner type.
    ///
    /// # Examples
    /// Converting the `NonNull` pointer back into a `Box` with
    /// [`Box::from_non_null_in`] for automatic cleanup:
    /// ```
    /// use std::alloc::System;
    ///
    /// let x = Box::new_in(String::from("Hello"), System);
    /// let (non_null, alloc) = Box::into_non_null_with_allocator(x);
    /// let x = unsafe { Box::from_non_null_in(non_null, alloc) };
    /// ```
    /// Manual cleanup by explicitly running the destructor and deallocating
    /// the memory:
    /// ```
    /// use std::alloc::{Allocator, Layout, System};
    ///
    /// let x = Box::new_in(String::from("Hello"), System);
    /// let (non_null, alloc) = Box::into_non_null_with_allocator(x);
    /// unsafe {
    ///     non_null.drop_in_place();
    ///     alloc.deallocate(non_null.cast::<u8>(), Layout::new::<String>());
    /// }
    /// ```
    ///
    /// [memory layout]: self#memory-layout
    /// [`deallocate`]: Allocator::deallocate
    #[must_use = "losing the pointer will leak memory"]
    #[stable(feature = "allocator_api", since = "1.100.0")]
    #[inline]
    pub fn into_non_null_with_allocator(b: Self) -> (NonNull<T>, A) {
        let (ptr, alloc) = Box::into_raw_with_allocator(b);
        // SAFETY: `Box` is guaranteed to be non-null.
        unsafe { (NonNull::new_unchecked(ptr), alloc) }
    }

    /// Returns a raw mutable pointer to the `Box`'s contents.
    ///
    /// The caller must ensure that the `Box` outlives the pointer this
    /// function returns, or else it will end up dangling.
    ///
    /// This method guarantees that for the purpose of the aliasing model, this method
    /// does not materialize a reference to the underlying memory, and thus the returned pointer
    /// will remain valid when mixed with other calls to [`as_ptr`], [`as_mut_ptr`], and [`as_non_null`].
    /// Note that calling other methods that materialize references to the memory
    /// may still invalidate this pointer.
    /// See the example below for how this guarantee can be used.
    ///
    /// # Examples
    ///
    /// Due to the aliasing guarantee, the following code is legal:
    ///
    /// ```rust
    /// unsafe {
    ///     let mut b = Box::new(0);
    ///     let ptr1 = Box::as_mut_ptr(&mut b);
    ///     ptr1.write(1);
    ///     let ptr2 = Box::as_mut_ptr(&mut b);
    ///     ptr2.write(2);
    ///     // Notably, the write to `ptr2` did *not* invalidate `ptr1`:
    ///     ptr1.write(3);
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: Self::as_mut_ptr
    /// [`as_ptr`]: Self::as_ptr
    /// [`as_non_null`]: Self::as_non_null
    #[must_use]
    #[stable(feature = "box_as_ptr", since = "1.98.0")]
    #[inline]
    #[lint::as_ptr]
    #[lint::never_returns_null_ptr]
    pub fn as_mut_ptr(b: &mut Self) -> *mut T {
        // This is a primitive deref, not going through `DerefMut`, and therefore not materializing
        // any references.
        &raw mut **b
    }

    /// Returns a raw pointer to the `Box`'s contents.
    ///
    /// The caller must ensure that the `Box` outlives the pointer this
    /// function returns, or else it will end up dangling.
    ///
    /// The caller must also ensure that the memory the pointer (non-transitively) points to
    /// is never written to (except inside an `UnsafeCell`) using this pointer or any pointer
    /// derived from it. If you need to mutate the contents of the `Box`, use [`as_mut_ptr`].
    ///
    /// This method guarantees that for the purpose of the aliasing model, this method
    /// does not materialize a reference to the underlying memory, and thus the returned pointer
    /// will remain valid when mixed with other calls to [`as_ptr`], [`as_mut_ptr`], and [`as_non_null`].
    /// Note that calling other methods that materialize mutable references to the memory,
    /// as well as writing to this memory, may still invalidate this pointer.
    /// See the example below for how this guarantee can be used.
    ///
    /// # Examples
    ///
    /// Due to the aliasing guarantee, the following code is legal:
    ///
    /// ```rust
    /// unsafe {
    ///     let mut v = Box::new(0);
    ///     let ptr1 = Box::as_ptr(&v);
    ///     let ptr2 = Box::as_mut_ptr(&mut v);
    ///     let _val = ptr2.read();
    ///     // No write to this memory has happened yet, so `ptr1` is still valid.
    ///     let _val = ptr1.read();
    ///     // However, once we do a write...
    ///     ptr2.write(1);
    ///     // ... `ptr1` is no longer valid.
    ///     // This would be UB: let _val = ptr1.read();
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: Self::as_mut_ptr
    /// [`as_ptr`]: Self::as_ptr
    /// [`as_non_null`]: Self::as_non_null
    #[must_use]
    #[stable(feature = "box_as_ptr", since = "1.98.0")]
    #[inline]
    #[lint::as_ptr]
    #[lint::never_returns_null_ptr]
    pub fn as_ptr(b: &Self) -> *const T {
        // This is a primitive deref, not going through `DerefMut`, and therefore not materializing
        // any references.
        &raw const **b
    }

    /// Returns a `NonNull` pointer to the `Box`'s contents.
    ///
    /// The caller must ensure that the `Box` outlives the pointer this
    /// function returns, or else it will end up dangling.
    ///
    /// This method guarantees that for the purpose of the aliasing model, this method
    /// does not materialize a reference to the underlying memory, and thus the returned pointer
    /// will remain valid when mixed with other calls to [`as_ptr`], [`as_mut_ptr`], and [`as_non_null`].
    /// Note that calling other methods that materialize references to the memory
    /// may still invalidate this pointer.
    /// See the example below for how this guarantee can be used.
    ///
    /// # Examples
    ///
    /// Due to the aliasing guarantee, the following code is legal:
    ///
    /// ```rust
    /// #![feature(box_as_non_null)]
    ///
    /// unsafe {
    ///     let mut b = Box::new(0);
    ///     let ptr1 = Box::as_non_null(&mut b);
    ///     ptr1.write(1);
    ///     let ptr2 = Box::as_non_null(&mut b);
    ///     ptr2.write(2);
    ///     // Notably, the write to `ptr2` did *not* invalidate `ptr1`:
    ///     ptr1.write(3);
    /// }
    /// ```
    ///
    /// [`as_mut_ptr`]: Self::as_mut_ptr
    /// [`as_ptr`]: Self::as_ptr
    /// [`as_non_null`]: Self::as_non_null
    #[must_use]
    #[unstable(feature = "box_as_non_null", issue = "157345")]
    #[lint::as_ptr]
    #[inline]
    pub fn as_non_null(b: &mut Self) -> NonNull<T> {
        // SAFETY: `Box` is guaranteed to be non-null.
        unsafe { NonNull::new_unchecked(Self::as_mut_ptr(b)) }
    }

    /// Returns a reference to the underlying allocator.
    ///
    /// Note: this is an associated function, which means that you have
    /// to call it as `Box::allocator(&b)` instead of `b.allocator()`. This
    /// is so that there is no conflict with a method on the inner type.
    #[stable(feature = "allocator_api", since = "1.100.0")]
    #[inline]
    pub fn allocator(b: &Self) -> &A {
        &b.1
    }

    /// Consumes and leaks the `Box`, returning a mutable reference,
    /// `&'a mut T`.
    ///
    /// Note that the type `T` must outlive the chosen lifetime `'a`. If the type
    /// has only static references, or none at all, then this may be chosen to be
    /// `'static`.
    ///
    /// This function is mainly useful for data that lives for the remainder of the program's life,
    /// i.e., memory that is meant to leak. If the memory should eventually be freed, prefer to use
    /// [`Box::into_raw`] or [`Box::into_non_null`] instead. Reconstructing ("unleaking") a `Box` from
    /// the mutable reference returned here (e.g. via [`Box::from_raw`]) is only possible if the
    /// allocator is `Global`, and even then it is a grey area (meaning it is possible under specific
    /// circumstances but many seemingly harmless ways of doing it are undefined behavior) and should
    /// be avoided.
    ///
    /// Note: this is an associated function, which means that you have
    /// to call it as `Box::leak(b)` instead of `b.leak()`. This
    /// is so that there is no conflict with a method on the inner type.
    ///
    /// # Examples
    ///
    /// Simple usage:
    ///
    /// ```
    /// let x = Box::new(41);
    /// let static_ref: &'static mut usize = Box::leak(x);
    /// *static_ref += 1;
    /// assert_eq!(*static_ref, 42);
    /// # // FIXME(https://github.com/rust-lang/miri/issues/3670):
    /// # // use -Zmiri-disable-leak-check instead of unleaking in tests meant to leak.
    /// # drop(unsafe { Box::from_raw(static_ref) });
    /// ```
    ///
    /// Unsized data:
    ///
    /// ```
    /// let x = vec![1, 2, 3].into_boxed_slice();
    /// let static_ref = Box::leak(x);
    /// static_ref[0] = 4;
    /// assert_eq!(*static_ref, [4, 2, 3]);
    /// # // FIXME(https://github.com/rust-lang/miri/issues/3670):
    /// # // use -Zmiri-disable-leak-check instead of unleaking in tests meant to leak.
    /// # drop(unsafe { Box::from_raw(static_ref) });
    /// ```
    #[stable(feature = "box_leak", since = "1.26.0")]
    #[inline]
    pub fn leak<'a>(b: Self) -> &'a mut T
    where
        A: 'a,
    {
        let (ptr, alloc) = Box::into_raw_with_allocator(b);
        mem::forget(alloc);
        // SAFETY: Pointer is valid and unique.
        unsafe { &mut *ptr }
    }

    /// Converts a `Box<T>` into a `Pin<Box<T>>`. If `T` does not implement [`Unpin`], then
    /// `*boxed` will be pinned in memory and unable to be moved.
    ///
    /// This conversion does not allocate on the heap and happens in place.
    ///
    /// This is also available via [`From`].
    ///
    /// Constructing and pinning a `Box` with <code>Box::into_pin([Box::new]\(x))</code>
    /// can also be written more concisely using <code>[Box::pin]\(x)</code>.
    /// This `into_pin` method is useful if you already have a `Box<T>`, or you are
    /// constructing a (pinned) `Box` in a different way than with [`Box::new`].
    ///
    /// # Notes
    ///
    /// It's not recommended that crates add an impl like `From<Box<T>> for Pin<T>`,
    /// as it'll introduce an ambiguity when calling `Pin::from`.
    /// A demonstration of such a poor impl is shown below.
    ///
    /// ```compile_fail
    /// # use std::pin::Pin;
    /// struct Foo; // A type defined in this crate.
    /// impl From<Box<()>> for Pin<Foo> {
    ///     fn from(_: Box<()>) -> Pin<Foo> {
    ///         Pin::new(Foo)
    ///     }
    /// }
    ///
    /// let foo = Box::new(());
    /// let bar = Pin::from(foo);
    /// ```
    #[stable(feature = "box_into_pin", since = "1.63.0")]
    pub fn into_pin(boxed: Self) -> Pin<Self>
    where
        A: StaticAllocator,
    {
        // SAFETY: It's not possible to move or replace the insides of a
        // `Pin<Box<T>>` when `T: !Unpin`, so it's safe to pin it directly
        // so long as the allocator promises to not break the pinning invariants.
        unsafe { Pin::new_unchecked(boxed) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
unsafe impl<#[may_dangle] T: ?Sized, A: Allocator> Drop for Box<T, A> {
    #[inline]
    fn drop(&mut self) {
        // the T in the Box is dropped by the compiler before the destructor is run

        let ptr = self.0;

        // SAFETY: The construction site of the unsized box had ensured for us that the
        // allocation was made with a valid layout (the size does not overflow an isize,
        // possibly because the size of the type is 0).
        let layout = unsafe { Layout::for_value_raw(ptr.as_ptr()) };
        if layout.size() != 0 {
            // SAFETY: Any nonzero allocation would have been created with the allocator
            // of this box and `layout` would fit that allocation. We also are the only ones
            // responsible for doing this deallocation and know that the pointer must be valid.
            unsafe {
                self.1.deallocate(From::from(ptr.cast()), layout);
            }
        }
    }
}

#[cfg(not(no_global_oom_handling))]
#[stable(feature = "rust1", since = "1.0.0")]
impl<T: Default> Default for Box<T> {
    /// Creates a `Box<T>`, with the `Default` value for `T`.
    #[inline]
    fn default() -> Self {
        let mut x: Box<mem::MaybeUninit<T>> = Box::new_uninit();

        // SAFETY: `x` is valid for writing and has the same layout as `T`.
        // If `T::default()` panics, dropping `x` will just deallocate the Box as `MaybeUninit<T>`
        // does not have a destructor.
        //
        // We use `ptr::write` as `MaybeUninit::write` creates
        // extra stack copies of `T` in debug mode.
        //
        // See https://github.com/rust-lang/rust/issues/136043 for more context.
        unsafe { ptr::write(&raw mut *x as *mut T, T::default()) };
        // SAFETY: `x` was just initialized above.
        unsafe { x.assume_init() }
    }
}

#[cfg(not(no_global_oom_handling))]
#[stable(feature = "rust1", since = "1.0.0")]
impl<T> Default for Box<[T]> {
    /// Creates an empty `[T]` inside a `Box`.
    #[inline]
    fn default() -> Self {
        let ptr: BoxRaw<[T]> = BoxRaw::<[T; 0]>::dangling();
        // SAFETY: `[T; 0]` is a ZST, for which `dangling` is valid to turn into a `Box`,
        // even after unsize coercion.
        Box(ptr, Global)
    }
}

#[cfg(not(no_global_oom_handling))]
#[stable(feature = "default_box_extra", since = "1.17.0")]
impl Default for Box<str> {
    #[inline]
    fn default() -> Self {
        // SAFETY:
        // - `[u8; 0]` is a ZST, for which `dangling` is valid to turn into a `Box`
        // - Casting `[u8]` to `str` is correct
        // - The empty byte slice is valid UTF-8
        let ptr: BoxRaw<str> = unsafe {
            let bytes: BoxRaw<[u8]> = BoxRaw::<[u8; 0]>::dangling();
            BoxRaw::new_unchecked(bytes.as_ptr() as *mut str)
        };
        Box(ptr, Global)
    }
}

#[cfg(not(no_global_oom_handling))]
#[stable(feature = "pin_default_impls", since = "1.91.0")]
impl<T> Default for Pin<Box<T>>
where
    T: ?Sized,
    Box<T>: Default,
{
    #[inline]
    fn default() -> Self {
        Box::into_pin(Box::<T>::default())
    }
}

#[cfg(not(no_global_oom_handling))]
#[stable(feature = "rust1", since = "1.0.0")]
// NB: This is not `AllocatorClone` since we don't care about allocator
// equivalence when cloning boxes.
impl<T: Clone, A: Allocator + Clone> Clone for Box<T, A> {
    /// Returns a new box with a `clone()` of this box's contents.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Box::new(5);
    /// let y = x.clone();
    ///
    /// // The value is the same
    /// assert_eq!(x, y);
    ///
    /// // But they are unique objects
    /// assert_ne!(&*x as *const i32, &*y as *const i32);
    /// ```
    #[inline]
    fn clone(&self) -> Self {
        // Pre-allocate memory to allow writing the cloned value directly.
        let mut boxed = Self::new_uninit_in(self.1.clone());
        // SAFETY: Destination pointer is valid and will then become initialised.
        unsafe {
            (**self).clone_to_uninit(boxed.as_mut_ptr().cast());
            boxed.assume_init()
        }
    }

    /// Copies `source`'s contents into `self` without creating a new allocation.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Box::new(5);
    /// let mut y = Box::new(10);
    /// let yp: *const i32 = &*y;
    ///
    /// y.clone_from(&x);
    ///
    /// // The value is the same
    /// assert_eq!(x, y);
    ///
    /// // And no allocation occurred
    /// assert_eq!(yp, &*y);
    /// ```
    #[inline]
    fn clone_from(&mut self, source: &Self) {
        (**self).clone_from(&(**source));
    }
}

#[cfg(not(no_global_oom_handling))]
#[stable(feature = "box_slice_clone", since = "1.3.0")]
impl<T: Clone, A: Allocator + Clone> Clone for Box<[T], A> {
    fn clone(&self) -> Self {
        let alloc = Box::allocator(self).clone();
        self.to_vec_in(alloc).into_boxed_slice()
    }

    /// Copies `source`'s contents into `self` without creating a new allocation,
    /// so long as the two are of the same length.
    ///
    /// # Examples
    ///
    /// ```
    /// let x = Box::new([5, 6, 7]);
    /// let mut y = Box::new([8, 9, 10]);
    /// let yp: *const [i32] = &*y;
    ///
    /// y.clone_from(&x);
    ///
    /// // The value is the same
    /// assert_eq!(x, y);
    ///
    /// // And no allocation occurred
    /// assert_eq!(yp, &*y);
    /// ```
    fn clone_from(&mut self, source: &Self) {
        if self.len() == source.len() {
            self.clone_from_slice(source);
        } else {
            *self = source.clone();
        }
    }
}

#[cfg(not(no_global_oom_handling))]
#[stable(feature = "box_slice_clone", since = "1.3.0")]
impl<A: Allocator + Clone> Clone for Box<str, A> {
    fn clone(&self) -> Self {
        let buf = Box::clone_from_ref_in(self.as_bytes(), self.1.clone());
        // SAFETY: We know the [u8] is a valid str.
        unsafe { from_boxed_utf8_unchecked_in(buf) }
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialEq, A: Allocator> PartialEq for Box<T, A> {
    #[inline]
    fn eq(&self, other: &Self) -> bool {
        PartialEq::eq(&**self, &**other)
    }
    #[inline]
    fn ne(&self, other: &Self) -> bool {
        PartialEq::ne(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + PartialOrd, A: Allocator> PartialOrd for Box<T, A> {
    #[inline]
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        PartialOrd::partial_cmp(&**self, &**other)
    }
    #[inline]
    fn lt(&self, other: &Self) -> bool {
        PartialOrd::lt(&**self, &**other)
    }
    #[inline]
    fn le(&self, other: &Self) -> bool {
        PartialOrd::le(&**self, &**other)
    }
    #[inline]
    fn ge(&self, other: &Self) -> bool {
        PartialOrd::ge(&**self, &**other)
    }
    #[inline]
    fn gt(&self, other: &Self) -> bool {
        PartialOrd::gt(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Ord, A: Allocator> Ord for Box<T, A> {
    #[inline]
    fn cmp(&self, other: &Self) -> Ordering {
        Ord::cmp(&**self, &**other)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Eq, A: Allocator> Eq for Box<T, A> {}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized + Hash, A: Allocator> Hash for Box<T, A> {
    fn hash<H: Hasher>(&self, state: &mut H) {
        (**self).hash(state);
    }
}

#[stable(feature = "indirect_hasher_impl", since = "1.22.0")]
impl<T: ?Sized + Hasher, A: Allocator> Hasher for Box<T, A> {
    fn finish(&self) -> u64 {
        (**self).finish()
    }
    fn write(&mut self, bytes: &[u8]) {
        (**self).write(bytes)
    }
    fn write_u8(&mut self, i: u8) {
        (**self).write_u8(i)
    }
    fn write_u16(&mut self, i: u16) {
        (**self).write_u16(i)
    }
    fn write_u32(&mut self, i: u32) {
        (**self).write_u32(i)
    }
    fn write_u64(&mut self, i: u64) {
        (**self).write_u64(i)
    }
    fn write_u128(&mut self, i: u128) {
        (**self).write_u128(i)
    }
    fn write_usize(&mut self, i: usize) {
        (**self).write_usize(i)
    }
    fn write_i8(&mut self, i: i8) {
        (**self).write_i8(i)
    }
    fn write_i16(&mut self, i: i16) {
        (**self).write_i16(i)
    }
    fn write_i32(&mut self, i: i32) {
        (**self).write_i32(i)
    }
    fn write_i64(&mut self, i: i64) {
        (**self).write_i64(i)
    }
    fn write_i128(&mut self, i: i128) {
        (**self).write_i128(i)
    }
    fn write_isize(&mut self, i: isize) {
        (**self).write_isize(i)
    }
    fn write_length_prefix(&mut self, len: usize) {
        (**self).write_length_prefix(len)
    }
    fn write_str(&mut self, s: &str) {
        (**self).write_str(s)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Display + ?Sized, A: Allocator> fmt::Display for Box<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Display::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: fmt::Debug + ?Sized, A: Allocator> fmt::Debug for Box<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        fmt::Debug::fmt(&**self, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, A: Allocator> fmt::Pointer for Box<T, A> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let ptr: *const T = &**self;
        fmt::Pointer::fmt(&ptr, f)
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, A: Allocator> Deref for Box<T, A> {
    type Target = T;

    fn deref(&self) -> &T {
        self
    }
}

#[stable(feature = "rust1", since = "1.0.0")]
impl<T: ?Sized, A: Allocator> DerefMut for Box<T, A> {
    fn deref_mut(&mut self) -> &mut T {
        self
    }
}

#[unstable(feature = "deref_pure_trait", issue = "87121")]
unsafe impl<T: ?Sized, A: Allocator> DerefPure for Box<T, A> {}

#[unstable(feature = "legacy_receiver_trait", issue = "none")]
impl<T: ?Sized, A: Allocator> LegacyReceiver for Box<T, A> {}

#[stable(feature = "boxed_closure_impls", since = "1.35.0")]
impl<Args: Tuple, F: FnOnce<Args> + ?Sized, A: Allocator> FnOnce<Args> for Box<F, A> {
    type Output = <F as FnOnce<Args>>::Output;

    extern "rust-call" fn call_once(self, args: Args) -> Self::Output {
        <F as FnOnce<Args>>::call_once(*self, args)
    }
}

#[stable(feature = "boxed_closure_impls", since = "1.35.0")]
impl<Args: Tuple, F: FnMut<Args> + ?Sized, A: Allocator> FnMut<Args> for Box<F, A> {
    extern "rust-call" fn call_mut(&mut self, args: Args) -> Self::Output {
        <F as FnMut<Args>>::call_mut(self, args)
    }
}

#[stable(feature = "boxed_closure_impls", since = "1.35.0")]
impl<Args: Tuple, F: Fn<Args> + ?Sized, A: Allocator> Fn<Args> for Box<F, A> {
    extern "rust-call" fn call(&self, args: Args) -> Self::Output {
        <F as Fn<Args>>::call(self, args)
    }
}

#[stable(feature = "async_closure", since = "1.85.0")]
impl<Args: Tuple, F: AsyncFnOnce<Args> + ?Sized, A: Allocator> AsyncFnOnce<Args> for Box<F, A> {
    type Output = F::Output;
    type CallOnceFuture = F::CallOnceFuture;

    extern "rust-call" fn async_call_once(self, args: Args) -> Self::CallOnceFuture {
        F::async_call_once(*self, args)
    }
}

#[stable(feature = "async_closure", since = "1.85.0")]
impl<Args: Tuple, F: AsyncFnMut<Args> + ?Sized, A: Allocator> AsyncFnMut<Args> for Box<F, A> {
    type CallRefFuture<'a>
        = F::CallRefFuture<'a>
    where
        Self: 'a;

    extern "rust-call" fn async_call_mut(&mut self, args: Args) -> Self::CallRefFuture<'_> {
        F::async_call_mut(self, args)
    }
}

#[stable(feature = "async_closure", since = "1.85.0")]
impl<Args: Tuple, F: AsyncFn<Args> + ?Sized, A: Allocator> AsyncFn<Args> for Box<F, A> {
    extern "rust-call" fn async_call(&self, args: Args) -> Self::CallRefFuture<'_> {
        F::async_call(self, args)
    }
}

#[unstable(feature = "coerce_unsized", issue = "18598")]
impl<T: ?Sized + Unsize<U>, U: ?Sized, A: Allocator> CoerceUnsized<Box<U, A>> for Box<T, A> {}

// A pointer can only be pin safe if it does not implement certain safe traits
// maliciously. Since `Box` is fundamental, downstream crates may be able to
// implement those traits for `Box<LocalType>`, so we must carefully check that
// this is not a problem for each trait.
//
// The `Box` type always implements `Deref` and `DerefMut`, so despite being
// fundamental, downstream crates cannot implement these traits for
// `Box<LocalType>`.
//
// Conversely, downstream crates are able to implement `Clone`, `Debug`, and
// `Display` for `Box<LocalType>` as long as `LocalType` does not implement
// said trait. However, the `Box<T>` type does not treat the existence of an
// `&Box<T>` as evidence that the `T` is not pinned, so this is not
// problematic.
//
// Finally, even if downstream crates provide their own implementation of
// `Clone` for `Box<LocalType>`, it is not problematic for the cloned box to be
// wrapped in `Pin`, since the same conversion could have been carried out
// safely as `Box::pin((*p).clone())`.
#[unstable(feature = "pin_coerce_unsized_trait", issue = "150112")]
unsafe impl<T: ?Sized, A: StaticAllocator> PinSafePointer for Box<T, A> {}

// It is quite crucial that we only allow the `Global` allocator here.
// Handling arbitrary custom allocators (which can affect the `Box` layout heavily!)
// would need a lot of codegen and interpreter adjustments.
#[unstable(feature = "dispatch_from_dyn", issue = "none")]
impl<T: ?Sized + Unsize<U>, U: ?Sized> DispatchFromDyn<Box<U>> for Box<T, Global> {}

#[stable(feature = "box_borrow", since = "1.1.0")]
impl<T: ?Sized, A: Allocator> Borrow<T> for Box<T, A> {
    fn borrow(&self) -> &T {
        self
    }
}

#[stable(feature = "box_borrow", since = "1.1.0")]
impl<T: ?Sized, A: Allocator> BorrowMut<T> for Box<T, A> {
    fn borrow_mut(&mut self) -> &mut T {
        self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized, A: Allocator> AsRef<T> for Box<T, A> {
    fn as_ref(&self) -> &T {
        self
    }
}

#[stable(since = "1.5.0", feature = "smart_ptr_as_ref")]
impl<T: ?Sized, A: Allocator> AsMut<T> for Box<T, A> {
    fn as_mut(&mut self) -> &mut T {
        self
    }
}

/* Nota bene
 *
 *  We could have chosen not to add this impl, and instead have written a
 *  function of Pin<Box<T>> to Pin<T>. Such a function would not be sound,
 *  because Box<T> implements Unpin even when T does not, as a result of
 *  this impl.
 *
 *  We chose this API instead of the alternative for a few reasons:
 *      - Logically, it is helpful to understand pinning in regard to the
 *        memory region being pointed to. For this reason none of the
 *        standard library pointer types support projecting through a pin
 *        (Box<T> is the only pointer type in std for which this would be
 *        safe.)
 *      - It is in practice very useful to have Box<T> be unconditionally
 *        Unpin because of trait objects, for which the structural auto
 *        trait functionality does not apply (e.g., Box<dyn Foo> would
 *        otherwise not be Unpin).
 *
 *  Another type with the same semantics as Box but only a conditional
 *  implementation of `Unpin` (where `T: Unpin`) would be valid/safe, and
 *  could have a method to project a Pin<T> from it.
 */
#[stable(feature = "pin", since = "1.33.0")]
impl<T: ?Sized, A: Allocator> Unpin for Box<T, A> {}

#[unstable(feature = "coroutine_trait", issue = "43122")]
impl<G: ?Sized + Coroutine<R> + Unpin, R, A: Allocator> Coroutine<R> for Box<G, A> {
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> CoroutineState<Self::Yield, Self::Return> {
        G::resume(Pin::new(&mut *self), arg)
    }
}

#[unstable(feature = "coroutine_trait", issue = "43122")]
impl<G: ?Sized + Coroutine<R>, R, A: Allocator> Coroutine<R> for Pin<Box<G, A>>
where
    A: StaticAllocator,
{
    type Yield = G::Yield;
    type Return = G::Return;

    fn resume(mut self: Pin<&mut Self>, arg: R) -> CoroutineState<Self::Yield, Self::Return> {
        G::resume((*self).as_mut(), arg)
    }
}

#[stable(feature = "futures_api", since = "1.36.0")]
impl<F: ?Sized + Future + Unpin, A: Allocator> Future for Box<F, A> {
    type Output = F::Output;

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<Self::Output> {
        F::poll(Pin::new(&mut *self), cx)
    }
}

#[stable(feature = "box_error", since = "1.8.0")]
impl<E: Error, A: Allocator> Error for Box<E, A> {
    #[allow(deprecated)]
    fn cause(&self) -> Option<&dyn Error> {
        Error::cause(&**self)
    }

    fn source(&self) -> Option<&(dyn Error + 'static)> {
        Error::source(&**self)
    }

    fn provide<'b>(&'b self, request: &mut error::Request<'b>) {
        Error::provide(&**self, request);
    }
}

#[stable(feature = "allocator_api", since = "1.100.0")]
unsafe impl<T: ?Sized + Allocator, A: Allocator> Allocator for Box<T, A> {
    #[inline]
    fn allocate(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate(layout)
    }

    #[inline]
    fn allocate_zeroed(&self, layout: Layout) -> Result<NonNull<[u8]>, AllocError> {
        (**self).allocate_zeroed(layout)
    }

    #[inline]
    unsafe fn deallocate(&self, ptr: NonNull<u8>, layout: Layout) {
        // SAFETY: the safety contract must be upheld by the caller
        unsafe { (**self).deallocate(ptr, layout) }
    }

    #[inline]
    unsafe fn grow(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SAFETY: the safety contract must be upheld by the caller
        unsafe { (**self).grow(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn grow_zeroed(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SAFETY: the safety contract must be upheld by the caller
        unsafe { (**self).grow_zeroed(ptr, old_layout, new_layout) }
    }

    #[inline]
    unsafe fn shrink(
        &self,
        ptr: NonNull<u8>,
        old_layout: Layout,
        new_layout: Layout,
    ) -> Result<NonNull<[u8]>, AllocError> {
        // SAFETY: the safety contract must be upheld by the caller
        unsafe { (**self).shrink(ptr, old_layout, new_layout) }
    }
}

/// This trait impl is unstable and only usable on nightly with `feature(allocator_ext)`.
#[unstable(feature = "allocator_ext", issue = "163177", implied_by = "allocator_api")]
#[unstable_feature_bound(allocator_ext)]
impl<T: ?Sized + Allocator, A: Allocator> AllocatorNightly for Box<T, A> {}

#[unstable(feature = "random", issue = "130703")]
impl<R: core::random::Rng + ?Sized, A: Allocator> core::random::Rng for Box<R, A> {
    #[inline]
    fn fill_bytes(&mut self, bytes: &mut [u8]) {
        (**self).fill_bytes(bytes)
    }
}
