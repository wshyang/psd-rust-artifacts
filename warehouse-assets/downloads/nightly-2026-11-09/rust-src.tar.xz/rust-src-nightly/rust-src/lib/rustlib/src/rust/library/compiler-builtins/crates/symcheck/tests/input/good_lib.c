void good() {}
