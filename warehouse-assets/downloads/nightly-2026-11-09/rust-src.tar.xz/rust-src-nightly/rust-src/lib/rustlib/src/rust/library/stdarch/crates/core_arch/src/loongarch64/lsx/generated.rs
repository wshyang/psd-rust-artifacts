// This code is automatically generated. DO NOT MODIFY.
//
// Instead, modify `crates/stdarch-gen-loongarch/lsx.spec` and run the following command to re-generate this file:
//
// ```
// OUT_DIR=`pwd`/crates/core_arch cargo run -p stdarch-gen-loongarch -- crates/stdarch-gen-loongarch/lsx.spec
// ```

use super::super::*;
use crate::mem::transmute;

#[allow(improper_ctypes)]
unsafe extern "llvm-intrinsic" {
    #[link_name = "llvm.loongarch.lsx.vsrar.b"]
    fn __lsx_vsrar_b(a: __v16i8, b: __v16i8) -> __v16i8;
    #[link_name = "llvm.loongarch.lsx.vsrar.h"]
    fn __lsx_vsrar_h(a: __v8i16, b: __v8i16) -> __v8i16;
    #[link_name = "llvm.loongarch.lsx.vsrar.w"]
    fn __lsx_vsrar_w(a: __v4i32, b: __v4i32) -> __v4i32;
    #[link_name = "llvm.loongarch.lsx.vsrar.d"]
    fn __lsx_vsrar_d(a: __v2i64, b: __v2i64) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vsrari.b"]
    fn __lsx_vsrari_b(a: __v16i8, b: u32) -> __v16i8;
    #[link_name = "llvm.loongarch.lsx.vsrari.h"]
    fn __lsx_vsrari_h(a: __v8i16, b: u32) -> __v8i16;
    #[link_name = "llvm.loongarch.lsx.vsrari.w"]
    fn __lsx_vsrari_w(a: __v4i32, b: u32) -> __v4i32;
    #[link_name = "llvm.loongarch.lsx.vsrari.d"]
    fn __lsx_vsrari_d(a: __v2i64, b: u32) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vsrlr.b"]
    fn __lsx_vsrlr_b(a: __v16i8, b: __v16i8) -> __v16i8;
    #[link_name = "llvm.loongarch.lsx.vsrlr.h"]
    fn __lsx_vsrlr_h(a: __v8i16, b: __v8i16) -> __v8i16;
    #[link_name = "llvm.loongarch.lsx.vsrlr.w"]
    fn __lsx_vsrlr_w(a: __v4i32, b: __v4i32) -> __v4i32;
    #[link_name = "llvm.loongarch.lsx.vsrlr.d"]
    fn __lsx_vsrlr_d(a: __v2i64, b: __v2i64) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vsrlri.b"]
    fn __lsx_vsrlri_b(a: __v16i8, b: u32) -> __v16i8;
    #[link_name = "llvm.loongarch.lsx.vsrlri.h"]
    fn __lsx_vsrlri_h(a: __v8i16, b: u32) -> __v8i16;
    #[link_name = "llvm.loongarch.lsx.vsrlri.w"]
    fn __lsx_vsrlri_w(a: __v4i32, b: u32) -> __v4i32;
    #[link_name = "llvm.loongarch.lsx.vsrlri.d"]
    fn __lsx_vsrlri_d(a: __v2i64, b: u32) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vbitclri.b"]
    fn __lsx_vbitclri_b(a: __v16u8, b: u32) -> __v16u8;
    #[link_name = "llvm.loongarch.lsx.vbitclri.h"]
    fn __lsx_vbitclri_h(a: __v8u16, b: u32) -> __v8u16;
    #[link_name = "llvm.loongarch.lsx.vbitclri.w"]
    fn __lsx_vbitclri_w(a: __v4u32, b: u32) -> __v4u32;
    #[link_name = "llvm.loongarch.lsx.vbitclri.d"]
    fn __lsx_vbitclri_d(a: __v2u64, b: u32) -> __v2u64;
    #[link_name = "llvm.loongarch.lsx.vbitseti.b"]
    fn __lsx_vbitseti_b(a: __v16u8, b: u32) -> __v16u8;
    #[link_name = "llvm.loongarch.lsx.vbitseti.h"]
    fn __lsx_vbitseti_h(a: __v8u16, b: u32) -> __v8u16;
    #[link_name = "llvm.loongarch.lsx.vbitseti.w"]
    fn __lsx_vbitseti_w(a: __v4u32, b: u32) -> __v4u32;
    #[link_name = "llvm.loongarch.lsx.vbitseti.d"]
    fn __lsx_vbitseti_d(a: __v2u64, b: u32) -> __v2u64;
    #[link_name = "llvm.loongarch.lsx.vbitrevi.b"]
    fn __lsx_vbitrevi_b(a: __v16u8, b: u32) -> __v16u8;
    #[link_name = "llvm.loongarch.lsx.vbitrevi.h"]
    fn __lsx_vbitrevi_h(a: __v8u16, b: u32) -> __v8u16;
    #[link_name = "llvm.loongarch.lsx.vbitrevi.w"]
    fn __lsx_vbitrevi_w(a: __v4u32, b: u32) -> __v4u32;
    #[link_name = "llvm.loongarch.lsx.vbitrevi.d"]
    fn __lsx_vbitrevi_d(a: __v2u64, b: u32) -> __v2u64;
    #[link_name = "llvm.loongarch.lsx.vsubi.bu"]
    fn __lsx_vsubi_bu(a: __v16i8, b: u32) -> __v16i8;
    #[link_name = "llvm.loongarch.lsx.vsubi.hu"]
    fn __lsx_vsubi_hu(a: __v8i16, b: u32) -> __v8i16;
    #[link_name = "llvm.loongarch.lsx.vsubi.wu"]
    fn __lsx_vsubi_wu(a: __v4i32, b: u32) -> __v4i32;
    #[link_name = "llvm.loongarch.lsx.vsubi.du"]
    fn __lsx_vsubi_du(a: __v2i64, b: u32) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vsat.b"]
    fn __lsx_vsat_b(a: __v16i8, b: u32) -> __v16i8;
    #[link_name = "llvm.loongarch.lsx.vsat.h"]
    fn __lsx_vsat_h(a: __v8i16, b: u32) -> __v8i16;
    #[link_name = "llvm.loongarch.lsx.vsat.w"]
    fn __lsx_vsat_w(a: __v4i32, b: u32) -> __v4i32;
    #[link_name = "llvm.loongarch.lsx.vsat.d"]
    fn __lsx_vsat_d(a: __v2i64, b: u32) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vsat.bu"]
    fn __lsx_vsat_bu(a: __v16u8, b: u32) -> __v16u8;
    #[link_name = "llvm.loongarch.lsx.vsat.hu"]
    fn __lsx_vsat_hu(a: __v8u16, b: u32) -> __v8u16;
    #[link_name = "llvm.loongarch.lsx.vsat.wu"]
    fn __lsx_vsat_wu(a: __v4u32, b: u32) -> __v4u32;
    #[link_name = "llvm.loongarch.lsx.vsat.du"]
    fn __lsx_vsat_du(a: __v2u64, b: u32) -> __v2u64;
    #[link_name = "llvm.loongarch.lsx.vdiv.b"]
    fn __lsx_vdiv_b(a: __v16i8, b: __v16i8) -> __v16i8;
    #[link_name = "llvm.loongarch.lsx.vdiv.h"]
    fn __lsx_vdiv_h(a: __v8i16, b: __v8i16) -> __v8i16;
    #[link_name = "llvm.loongarch.lsx.vdiv.w"]
    fn __lsx_vdiv_w(a: __v4i32, b: __v4i32) -> __v4i32;
    #[link_name = "llvm.loongarch.lsx.vdiv.d"]
    fn __lsx_vdiv_d(a: __v2i64, b: __v2i64) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vdiv.bu"]
    fn __lsx_vdiv_bu(a: __v16u8, b: __v16u8) -> __v16u8;
    #[link_name = "llvm.loongarch.lsx.vdiv.hu"]
    fn __lsx_vdiv_hu(a: __v8u16, b: __v8u16) -> __v8u16;
    #[link_name = "llvm.loongarch.lsx.vdiv.wu"]
    fn __lsx_vdiv_wu(a: __v4u32, b: __v4u32) -> __v4u32;
    #[link_name = "llvm.loongarch.lsx.vdiv.du"]
    fn __lsx_vdiv_du(a: __v2u64, b: __v2u64) -> __v2u64;
    #[link_name = "llvm.loongarch.lsx.vhaddw.h.b"]
    fn __lsx_vhaddw_h_b(a: __v16i8, b: __v16i8) -> __v8i16;
    #[link_name = "llvm.loongarch.lsx.vhaddw.w.h"]
    fn __lsx_vhaddw_w_h(a: __v8i16, b: __v8i16) -> __v4i32;
    #[link_name = "llvm.loongarch.lsx.vhaddw.d.w"]
    fn __lsx_vhaddw_d_w(a: __v4i32, b: __v4i32) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vhaddw.hu.bu"]
    fn __lsx_vhaddw_hu_bu(a: __v16u8, b: __v16u8) -> __v8u16;
    #[link_name = "llvm.loongarch.lsx.vhaddw.wu.hu"]
    fn __lsx_vhaddw_wu_hu(a: __v8u16, b: __v8u16) -> __v4u32;
    #[link_name = "llvm.loongarch.lsx.vhaddw.du.wu"]
    fn __lsx_vhaddw_du_wu(a: __v4u32, b: __v4u32) -> __v2u64;
    #[link_name = "llvm.loongarch.lsx.vhsubw.h.b"]
    fn __lsx_vhsubw_h_b(a: __v16i8, b: __v16i8) -> __v8i16;
    #[link_name = "llvm.loongarch.lsx.vhsubw.w.h"]
    fn __lsx_vhsubw_w_h(a: __v8i16, b: __v8i16) -> __v4i32;
    #[link_name = "llvm.loongarch.lsx.vhsubw.d.w"]
    fn __lsx_vhsubw_d_w(a: __v4i32, b: __v4i32) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vhsubw.hu.bu"]
    fn __lsx_vhsubw_hu_bu(a: __v16u8, b: __v16u8) -> __v8i16;
    #[link_name = "llvm.loongarch.lsx.vhsubw.wu.hu"]
    fn __lsx_vhsubw_wu_hu(a: __v8u16, b: __v8u16) -> __v4i32;
    #[link_name = "llvm.loongarch.lsx.vhsubw.du.wu"]
    fn __lsx_vhsubw_du_wu(a: __v4u32, b: __v4u32) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vmod.b"]
    fn __lsx_vmod_b(a: __v16i8, b: __v16i8) -> __v16i8;
    #[link_name = "llvm.loongarch.lsx.vmod.h"]
    fn __lsx_vmod_h(a: __v8i16, b: __v8i16) -> __v8i16;
    #[link_name = "llvm.loongarch.lsx.vmod.w"]
    fn __lsx_vmod_w(a: __v4i32, b: __v4i32) -> __v4i32;
    #[link_name = "llvm.loongarch.lsx.vmod.d"]
    fn __lsx_vmod_d(a: __v2i64, b: __v2i64) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vmod.bu"]
    fn __lsx_vmod_bu(a: __v16u8, b: __v16u8) -> __v16u8;
    #[link_name = "llvm.loongarch.lsx.vmod.hu"]
    fn __lsx_vmod_hu(a: __v8u16, b: __v8u16) -> __v8u16;
    #[link_name = "llvm.loongarch.lsx.vmod.wu"]
    fn __lsx_vmod_wu(a: __v4u32, b: __v4u32) -> __v4u32;
    #[link_name = "llvm.loongarch.lsx.vmod.du"]
    fn __lsx_vmod_du(a: __v2u64, b: __v2u64) -> __v2u64;
    #[link_name = "llvm.loongarch.lsx.vreplve.b"]
    fn __lsx_vreplve_b(a: __v16i8, b: i32) -> __v16i8;
    #[link_name = "llvm.loongarch.lsx.vreplve.h"]
    fn __lsx_vreplve_h(a: __v8i16, b: i32) -> __v8i16;
    #[link_name = "llvm.loongarch.lsx.vreplve.w"]
    fn __lsx_vreplve_w(a: __v4i32, b: i32) -> __v4i32;
    #[link_name = "llvm.loongarch.lsx.vreplve.d"]
    fn __lsx_vreplve_d(a: __v2i64, b: i32) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vshuf.h"]
    fn __lsx_vshuf_h(a: __v8i16, b: __v8i16, c: __v8i16) -> __v8i16;
    #[link_name = "llvm.loongarch.lsx.vshuf.w"]
    fn __lsx_vshuf_w(a: __v4i32, b: __v4i32, c: __v4i32) -> __v4i32;
    #[link_name = "llvm.loongarch.lsx.vshuf.d"]
    fn __lsx_vshuf_d(a: __v2i64, b: __v2i64, c: __v2i64) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vandi.b"]
    fn __lsx_vandi_b(a: __v16u8, b: u32) -> __v16u8;
    #[link_name = "llvm.loongarch.lsx.vori.b"]
    fn __lsx_vori_b(a: __v16u8, b: u32) -> __v16u8;
    #[link_name = "llvm.loongarch.lsx.vnori.b"]
    fn __lsx_vnori_b(a: __v16u8, b: u32) -> __v16u8;
    #[link_name = "llvm.loongarch.lsx.vxori.b"]
    fn __lsx_vxori_b(a: __v16u8, b: u32) -> __v16u8;
    #[link_name = "llvm.loongarch.lsx.vbitsel.v"]
    fn __lsx_vbitsel_v(a: __v16u8, b: __v16u8, c: __v16u8) -> __v16u8;
    #[link_name = "llvm.loongarch.lsx.vbitseli.b"]
    fn __lsx_vbitseli_b(a: __v16u8, b: __v16u8, c: u32) -> __v16u8;
    #[link_name = "llvm.loongarch.lsx.vclo.b"]
    fn __lsx_vclo_b(a: __v16i8) -> __v16i8;
    #[link_name = "llvm.loongarch.lsx.vclo.h"]
    fn __lsx_vclo_h(a: __v8i16) -> __v8i16;
    #[link_name = "llvm.loongarch.lsx.vclo.w"]
    fn __lsx_vclo_w(a: __v4i32) -> __v4i32;
    #[link_name = "llvm.loongarch.lsx.vclo.d"]
    fn __lsx_vclo_d(a: __v2i64) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vfcvt.h.s"]
    fn __lsx_vfcvt_h_s(a: __v4f32, b: __v4f32) -> __v8i16;
    #[link_name = "llvm.loongarch.lsx.vfcvt.s.d"]
    fn __lsx_vfcvt_s_d(a: __v2f64, b: __v2f64) -> __v4f32;
    #[link_name = "llvm.loongarch.lsx.vfmin.s"]
    fn __lsx_vfmin_s(a: __v4f32, b: __v4f32) -> __v4f32;
    #[link_name = "llvm.loongarch.lsx.vfmin.d"]
    fn __lsx_vfmin_d(a: __v2f64, b: __v2f64) -> __v2f64;
    #[link_name = "llvm.loongarch.lsx.vfmina.s"]
    fn __lsx_vfmina_s(a: __v4f32, b: __v4f32) -> __v4f32;
    #[link_name = "llvm.loongarch.lsx.vfmina.d"]
    fn __lsx_vfmina_d(a: __v2f64, b: __v2f64) -> __v2f64;
    #[link_name = "llvm.loongarch.lsx.vfmax.s"]
    fn __lsx_vfmax_s(a: __v4f32, b: __v4f32) -> __v4f32;
    #[link_name = "llvm.loongarch.lsx.vfmax.d"]
    fn __lsx_vfmax_d(a: __v2f64, b: __v2f64) -> __v2f64;
    #[link_name = "llvm.loongarch.lsx.vfmaxa.s"]
    fn __lsx_vfmaxa_s(a: __v4f32, b: __v4f32) -> __v4f32;
    #[link_name = "llvm.loongarch.lsx.vfmaxa.d"]
    fn __lsx_vfmaxa_d(a: __v2f64, b: __v2f64) -> __v2f64;
    #[link_name = "llvm.loongarch.lsx.vfclass.s"]
    fn __lsx_vfclass_s(a: __v4f32) -> __v4i32;
    #[link_name = "llvm.loongarch.lsx.vfclass.d"]
    fn __lsx_vfclass_d(a: __v2f64) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vfrecipe.s"]
    fn __lsx_vfrecipe_s(a: __v4f32) -> __v4f32;
    #[link_name = "llvm.loongarch.lsx.vfrecipe.d"]
    fn __lsx_vfrecipe_d(a: __v2f64) -> __v2f64;
    #[link_name = "llvm.loongarch.lsx.vfrsqrte.s"]
    fn __lsx_vfrsqrte_s(a: __v4f32) -> __v4f32;
    #[link_name = "llvm.loongarch.lsx.vfrsqrte.d"]
    fn __lsx_vfrsqrte_d(a: __v2f64) -> __v2f64;
    #[link_name = "llvm.loongarch.lsx.vfrint.s"]
    fn __lsx_vfrint_s(a: __v4f32) -> __v4f32;
    #[link_name = "llvm.loongarch.lsx.vfrint.d"]
    fn __lsx_vfrint_d(a: __v2f64) -> __v2f64;
    #[link_name = "llvm.loongarch.lsx.vflogb.s"]
    fn __lsx_vflogb_s(a: __v4f32) -> __v4f32;
    #[link_name = "llvm.loongarch.lsx.vflogb.d"]
    fn __lsx_vflogb_d(a: __v2f64) -> __v2f64;
    #[link_name = "llvm.loongarch.lsx.vfcvth.s.h"]
    fn __lsx_vfcvth_s_h(a: __v8i16) -> __v4f32;
    #[link_name = "llvm.loongarch.lsx.vfcvth.d.s"]
    fn __lsx_vfcvth_d_s(a: __v4f32) -> __v2f64;
    #[link_name = "llvm.loongarch.lsx.vfcvtl.s.h"]
    fn __lsx_vfcvtl_s_h(a: __v8i16) -> __v4f32;
    #[link_name = "llvm.loongarch.lsx.vfcvtl.d.s"]
    fn __lsx_vfcvtl_d_s(a: __v4f32) -> __v2f64;
    #[link_name = "llvm.loongarch.lsx.vftint.w.s"]
    fn __lsx_vftint_w_s(a: __v4f32) -> __v4i32;
    #[link_name = "llvm.loongarch.lsx.vftint.l.d"]
    fn __lsx_vftint_l_d(a: __v2f64) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vftint.wu.s"]
    fn __lsx_vftint_wu_s(a: __v4f32) -> __v4u32;
    #[link_name = "llvm.loongarch.lsx.vftint.lu.d"]
    fn __lsx_vftint_lu_d(a: __v2f64) -> __v2u64;
    #[link_name = "llvm.loongarch.lsx.vftintrz.w.s"]
    fn __lsx_vftintrz_w_s(a: __v4f32) -> __v4i32;
    #[link_name = "llvm.loongarch.lsx.vftintrz.l.d"]
    fn __lsx_vftintrz_l_d(a: __v2f64) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vftintrz.wu.s"]
    fn __lsx_vftintrz_wu_s(a: __v4f32) -> __v4u32;
    #[link_name = "llvm.loongarch.lsx.vftintrz.lu.d"]
    fn __lsx_vftintrz_lu_d(a: __v2f64) -> __v2u64;
    #[link_name = "llvm.loongarch.lsx.vffint.s.w"]
    fn __lsx_vffint_s_w(a: __v4i32) -> __v4f32;
    #[link_name = "llvm.loongarch.lsx.vffint.d.l"]
    fn __lsx_vffint_d_l(a: __v2i64) -> __v2f64;
    #[link_name = "llvm.loongarch.lsx.vffint.s.wu"]
    fn __lsx_vffint_s_wu(a: __v4u32) -> __v4f32;
    #[link_name = "llvm.loongarch.lsx.vffint.d.lu"]
    fn __lsx_vffint_d_lu(a: __v2u64) -> __v2f64;
    #[link_name = "llvm.loongarch.lsx.vsllwil.h.b"]
    fn __lsx_vsllwil_h_b(a: __v16i8, b: u32) -> __v8i16;
    #[link_name = "llvm.loongarch.lsx.vsllwil.w.h"]
    fn __lsx_vsllwil_w_h(a: __v8i16, b: u32) -> __v4i32;
    #[link_name = "llvm.loongarch.lsx.vsllwil.d.w"]
    fn __lsx_vsllwil_d_w(a: __v4i32, b: u32) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vsllwil.hu.bu"]
    fn __lsx_vsllwil_hu_bu(a: __v16u8, b: u32) -> __v8u16;
    #[link_name = "llvm.loongarch.lsx.vsllwil.wu.hu"]
    fn __lsx_vsllwil_wu_hu(a: __v8u16, b: u32) -> __v4u32;
    #[link_name = "llvm.loongarch.lsx.vsllwil.du.wu"]
    fn __lsx_vsllwil_du_wu(a: __v4u32, b: u32) -> __v2u64;
    #[link_name = "llvm.loongarch.lsx.vsran.b.h"]
    fn __lsx_vsran_b_h(a: __v8i16, b: __v8i16) -> __v16i8;
    #[link_name = "llvm.loongarch.lsx.vsran.h.w"]
    fn __lsx_vsran_h_w(a: __v4i32, b: __v4i32) -> __v8i16;
    #[link_name = "llvm.loongarch.lsx.vsran.w.d"]
    fn __lsx_vsran_w_d(a: __v2i64, b: __v2i64) -> __v4i32;
    #[link_name = "llvm.loongarch.lsx.vssran.b.h"]
    fn __lsx_vssran_b_h(a: __v8i16, b: __v8i16) -> __v16i8;
    #[link_name = "llvm.loongarch.lsx.vssran.h.w"]
    fn __lsx_vssran_h_w(a: __v4i32, b: __v4i32) -> __v8i16;
    #[link_name = "llvm.loongarch.lsx.vssran.w.d"]
    fn __lsx_vssran_w_d(a: __v2i64, b: __v2i64) -> __v4i32;
    #[link_name = "llvm.loongarch.lsx.vssran.bu.h"]
    fn __lsx_vssran_bu_h(a: __v8u16, b: __v8u16) -> __v16u8;
    #[link_name = "llvm.loongarch.lsx.vssran.hu.w"]
    fn __lsx_vssran_hu_w(a: __v4u32, b: __v4u32) -> __v8u16;
    #[link_name = "llvm.loongarch.lsx.vssran.wu.d"]
    fn __lsx_vssran_wu_d(a: __v2u64, b: __v2u64) -> __v4u32;
    #[link_name = "llvm.loongarch.lsx.vsrarn.b.h"]
    fn __lsx_vsrarn_b_h(a: __v8i16, b: __v8i16) -> __v16i8;
    #[link_name = "llvm.loongarch.lsx.vsrarn.h.w"]
    fn __lsx_vsrarn_h_w(a: __v4i32, b: __v4i32) -> __v8i16;
    #[link_name = "llvm.loongarch.lsx.vsrarn.w.d"]
    fn __lsx_vsrarn_w_d(a: __v2i64, b: __v2i64) -> __v4i32;
    #[link_name = "llvm.loongarch.lsx.vssrarn.b.h"]
    fn __lsx_vssrarn_b_h(a: __v8i16, b: __v8i16) -> __v16i8;
    #[link_name = "llvm.loongarch.lsx.vssrarn.h.w"]
    fn __lsx_vssrarn_h_w(a: __v4i32, b: __v4i32) -> __v8i16;
    #[link_name = "llvm.loongarch.lsx.vssrarn.w.d"]
    fn __lsx_vssrarn_w_d(a: __v2i64, b: __v2i64) -> __v4i32;
    #[link_name = "llvm.loongarch.lsx.vssrarn.bu.h"]
    fn __lsx_vssrarn_bu_h(a: __v8u16, b: __v8u16) -> __v16u8;
    #[link_name = "llvm.loongarch.lsx.vssrarn.hu.w"]
    fn __lsx_vssrarn_hu_w(a: __v4u32, b: __v4u32) -> __v8u16;
    #[link_name = "llvm.loongarch.lsx.vssrarn.wu.d"]
    fn __lsx_vssrarn_wu_d(a: __v2u64, b: __v2u64) -> __v4u32;
    #[link_name = "llvm.loongarch.lsx.vsrln.b.h"]
    fn __lsx_vsrln_b_h(a: __v8i16, b: __v8i16) -> __v16i8;
    #[link_name = "llvm.loongarch.lsx.vsrln.h.w"]
    fn __lsx_vsrln_h_w(a: __v4i32, b: __v4i32) -> __v8i16;
    #[link_name = "llvm.loongarch.lsx.vsrln.w.d"]
    fn __lsx_vsrln_w_d(a: __v2i64, b: __v2i64) -> __v4i32;
    #[link_name = "llvm.loongarch.lsx.vssrln.bu.h"]
    fn __lsx_vssrln_bu_h(a: __v8u16, b: __v8u16) -> __v16u8;
    #[link_name = "llvm.loongarch.lsx.vssrln.hu.w"]
    fn __lsx_vssrln_hu_w(a: __v4u32, b: __v4u32) -> __v8u16;
    #[link_name = "llvm.loongarch.lsx.vssrln.wu.d"]
    fn __lsx_vssrln_wu_d(a: __v2u64, b: __v2u64) -> __v4u32;
    #[link_name = "llvm.loongarch.lsx.vsrlrn.b.h"]
    fn __lsx_vsrlrn_b_h(a: __v8i16, b: __v8i16) -> __v16i8;
    #[link_name = "llvm.loongarch.lsx.vsrlrn.h.w"]
    fn __lsx_vsrlrn_h_w(a: __v4i32, b: __v4i32) -> __v8i16;
    #[link_name = "llvm.loongarch.lsx.vsrlrn.w.d"]
    fn __lsx_vsrlrn_w_d(a: __v2i64, b: __v2i64) -> __v4i32;
    #[link_name = "llvm.loongarch.lsx.vssrlrn.bu.h"]
    fn __lsx_vssrlrn_bu_h(a: __v8u16, b: __v8u16) -> __v16u8;
    #[link_name = "llvm.loongarch.lsx.vssrlrn.hu.w"]
    fn __lsx_vssrlrn_hu_w(a: __v4u32, b: __v4u32) -> __v8u16;
    #[link_name = "llvm.loongarch.lsx.vssrlrn.wu.d"]
    fn __lsx_vssrlrn_wu_d(a: __v2u64, b: __v2u64) -> __v4u32;
    #[link_name = "llvm.loongarch.lsx.vfrstpi.b"]
    fn __lsx_vfrstpi_b(a: __v16i8, b: __v16i8, c: u32) -> __v16i8;
    #[link_name = "llvm.loongarch.lsx.vfrstpi.h"]
    fn __lsx_vfrstpi_h(a: __v8i16, b: __v8i16, c: u32) -> __v8i16;
    #[link_name = "llvm.loongarch.lsx.vfrstp.b"]
    fn __lsx_vfrstp_b(a: __v16i8, b: __v16i8, c: __v16i8) -> __v16i8;
    #[link_name = "llvm.loongarch.lsx.vfrstp.h"]
    fn __lsx_vfrstp_h(a: __v8i16, b: __v8i16, c: __v8i16) -> __v8i16;
    #[link_name = "llvm.loongarch.lsx.vextrins.b"]
    fn __lsx_vextrins_b(a: __v16i8, b: __v16i8, c: u32) -> __v16i8;
    #[link_name = "llvm.loongarch.lsx.vextrins.h"]
    fn __lsx_vextrins_h(a: __v8i16, b: __v8i16, c: u32) -> __v8i16;
    #[link_name = "llvm.loongarch.lsx.vextrins.w"]
    fn __lsx_vextrins_w(a: __v4i32, b: __v4i32, c: u32) -> __v4i32;
    #[link_name = "llvm.loongarch.lsx.vextrins.d"]
    fn __lsx_vextrins_d(a: __v2i64, b: __v2i64, c: u32) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vmskltz.b"]
    fn __lsx_vmskltz_b(a: __v16i8) -> __v16i8;
    #[link_name = "llvm.loongarch.lsx.vmskltz.h"]
    fn __lsx_vmskltz_h(a: __v8i16) -> __v8i16;
    #[link_name = "llvm.loongarch.lsx.vmskltz.w"]
    fn __lsx_vmskltz_w(a: __v4i32) -> __v4i32;
    #[link_name = "llvm.loongarch.lsx.vmskltz.d"]
    fn __lsx_vmskltz_d(a: __v2i64) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vsigncov.b"]
    fn __lsx_vsigncov_b(a: __v16i8, b: __v16i8) -> __v16i8;
    #[link_name = "llvm.loongarch.lsx.vsigncov.h"]
    fn __lsx_vsigncov_h(a: __v8i16, b: __v8i16) -> __v8i16;
    #[link_name = "llvm.loongarch.lsx.vsigncov.w"]
    fn __lsx_vsigncov_w(a: __v4i32, b: __v4i32) -> __v4i32;
    #[link_name = "llvm.loongarch.lsx.vsigncov.d"]
    fn __lsx_vsigncov_d(a: __v2i64, b: __v2i64) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vftintrne.w.s"]
    fn __lsx_vftintrne_w_s(a: __v4f32) -> __v4i32;
    #[link_name = "llvm.loongarch.lsx.vftintrne.l.d"]
    fn __lsx_vftintrne_l_d(a: __v2f64) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vftintrp.w.s"]
    fn __lsx_vftintrp_w_s(a: __v4f32) -> __v4i32;
    #[link_name = "llvm.loongarch.lsx.vftintrp.l.d"]
    fn __lsx_vftintrp_l_d(a: __v2f64) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vftintrm.w.s"]
    fn __lsx_vftintrm_w_s(a: __v4f32) -> __v4i32;
    #[link_name = "llvm.loongarch.lsx.vftintrm.l.d"]
    fn __lsx_vftintrm_l_d(a: __v2f64) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vftint.w.d"]
    fn __lsx_vftint_w_d(a: __v2f64, b: __v2f64) -> __v4i32;
    #[link_name = "llvm.loongarch.lsx.vffint.s.l"]
    fn __lsx_vffint_s_l(a: __v2i64, b: __v2i64) -> __v4f32;
    #[link_name = "llvm.loongarch.lsx.vftintrz.w.d"]
    fn __lsx_vftintrz_w_d(a: __v2f64, b: __v2f64) -> __v4i32;
    #[link_name = "llvm.loongarch.lsx.vftintrp.w.d"]
    fn __lsx_vftintrp_w_d(a: __v2f64, b: __v2f64) -> __v4i32;
    #[link_name = "llvm.loongarch.lsx.vftintrm.w.d"]
    fn __lsx_vftintrm_w_d(a: __v2f64, b: __v2f64) -> __v4i32;
    #[link_name = "llvm.loongarch.lsx.vftintrne.w.d"]
    fn __lsx_vftintrne_w_d(a: __v2f64, b: __v2f64) -> __v4i32;
    #[link_name = "llvm.loongarch.lsx.vftintl.l.s"]
    fn __lsx_vftintl_l_s(a: __v4f32) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vftinth.l.s"]
    fn __lsx_vftinth_l_s(a: __v4f32) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vffinth.d.w"]
    fn __lsx_vffinth_d_w(a: __v4i32) -> __v2f64;
    #[link_name = "llvm.loongarch.lsx.vffintl.d.w"]
    fn __lsx_vffintl_d_w(a: __v4i32) -> __v2f64;
    #[link_name = "llvm.loongarch.lsx.vftintrzl.l.s"]
    fn __lsx_vftintrzl_l_s(a: __v4f32) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vftintrzh.l.s"]
    fn __lsx_vftintrzh_l_s(a: __v4f32) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vftintrpl.l.s"]
    fn __lsx_vftintrpl_l_s(a: __v4f32) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vftintrph.l.s"]
    fn __lsx_vftintrph_l_s(a: __v4f32) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vftintrml.l.s"]
    fn __lsx_vftintrml_l_s(a: __v4f32) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vftintrmh.l.s"]
    fn __lsx_vftintrmh_l_s(a: __v4f32) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vftintrnel.l.s"]
    fn __lsx_vftintrnel_l_s(a: __v4f32) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vftintrneh.l.s"]
    fn __lsx_vftintrneh_l_s(a: __v4f32) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vfrintrne.s"]
    fn __lsx_vfrintrne_s(a: __v4f32) -> __v4f32;
    #[link_name = "llvm.loongarch.lsx.vfrintrne.d"]
    fn __lsx_vfrintrne_d(a: __v2f64) -> __v2f64;
    #[link_name = "llvm.loongarch.lsx.vstelm.b"]
    fn __lsx_vstelm_b(a: __v16i8, b: *mut i8, c: i32, d: u32);
    #[link_name = "llvm.loongarch.lsx.vstelm.h"]
    fn __lsx_vstelm_h(a: __v8i16, b: *mut i8, c: i32, d: u32);
    #[link_name = "llvm.loongarch.lsx.vstelm.w"]
    fn __lsx_vstelm_w(a: __v4i32, b: *mut i8, c: i32, d: u32);
    #[link_name = "llvm.loongarch.lsx.vstelm.d"]
    fn __lsx_vstelm_d(a: __v2i64, b: *mut i8, c: i32, d: u32);
    #[link_name = "llvm.loongarch.lsx.vaddwev.d.w"]
    fn __lsx_vaddwev_d_w(a: __v4i32, b: __v4i32) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vaddwev.w.h"]
    fn __lsx_vaddwev_w_h(a: __v8i16, b: __v8i16) -> __v4i32;
    #[link_name = "llvm.loongarch.lsx.vaddwev.h.b"]
    fn __lsx_vaddwev_h_b(a: __v16i8, b: __v16i8) -> __v8i16;
    #[link_name = "llvm.loongarch.lsx.vaddwod.d.w"]
    fn __lsx_vaddwod_d_w(a: __v4i32, b: __v4i32) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vaddwod.w.h"]
    fn __lsx_vaddwod_w_h(a: __v8i16, b: __v8i16) -> __v4i32;
    #[link_name = "llvm.loongarch.lsx.vaddwod.h.b"]
    fn __lsx_vaddwod_h_b(a: __v16i8, b: __v16i8) -> __v8i16;
    #[link_name = "llvm.loongarch.lsx.vaddwev.d.wu"]
    fn __lsx_vaddwev_d_wu(a: __v4u32, b: __v4u32) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vaddwev.w.hu"]
    fn __lsx_vaddwev_w_hu(a: __v8u16, b: __v8u16) -> __v4i32;
    #[link_name = "llvm.loongarch.lsx.vaddwev.h.bu"]
    fn __lsx_vaddwev_h_bu(a: __v16u8, b: __v16u8) -> __v8i16;
    #[link_name = "llvm.loongarch.lsx.vaddwod.d.wu"]
    fn __lsx_vaddwod_d_wu(a: __v4u32, b: __v4u32) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vaddwod.w.hu"]
    fn __lsx_vaddwod_w_hu(a: __v8u16, b: __v8u16) -> __v4i32;
    #[link_name = "llvm.loongarch.lsx.vaddwod.h.bu"]
    fn __lsx_vaddwod_h_bu(a: __v16u8, b: __v16u8) -> __v8i16;
    #[link_name = "llvm.loongarch.lsx.vaddwev.d.wu.w"]
    fn __lsx_vaddwev_d_wu_w(a: __v4u32, b: __v4i32) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vaddwev.w.hu.h"]
    fn __lsx_vaddwev_w_hu_h(a: __v8u16, b: __v8i16) -> __v4i32;
    #[link_name = "llvm.loongarch.lsx.vaddwev.h.bu.b"]
    fn __lsx_vaddwev_h_bu_b(a: __v16u8, b: __v16i8) -> __v8i16;
    #[link_name = "llvm.loongarch.lsx.vaddwod.d.wu.w"]
    fn __lsx_vaddwod_d_wu_w(a: __v4u32, b: __v4i32) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vaddwod.w.hu.h"]
    fn __lsx_vaddwod_w_hu_h(a: __v8u16, b: __v8i16) -> __v4i32;
    #[link_name = "llvm.loongarch.lsx.vaddwod.h.bu.b"]
    fn __lsx_vaddwod_h_bu_b(a: __v16u8, b: __v16i8) -> __v8i16;
    #[link_name = "llvm.loongarch.lsx.vsubwev.d.w"]
    fn __lsx_vsubwev_d_w(a: __v4i32, b: __v4i32) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vsubwev.w.h"]
    fn __lsx_vsubwev_w_h(a: __v8i16, b: __v8i16) -> __v4i32;
    #[link_name = "llvm.loongarch.lsx.vsubwev.h.b"]
    fn __lsx_vsubwev_h_b(a: __v16i8, b: __v16i8) -> __v8i16;
    #[link_name = "llvm.loongarch.lsx.vsubwod.d.w"]
    fn __lsx_vsubwod_d_w(a: __v4i32, b: __v4i32) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vsubwod.w.h"]
    fn __lsx_vsubwod_w_h(a: __v8i16, b: __v8i16) -> __v4i32;
    #[link_name = "llvm.loongarch.lsx.vsubwod.h.b"]
    fn __lsx_vsubwod_h_b(a: __v16i8, b: __v16i8) -> __v8i16;
    #[link_name = "llvm.loongarch.lsx.vsubwev.d.wu"]
    fn __lsx_vsubwev_d_wu(a: __v4u32, b: __v4u32) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vsubwev.w.hu"]
    fn __lsx_vsubwev_w_hu(a: __v8u16, b: __v8u16) -> __v4i32;
    #[link_name = "llvm.loongarch.lsx.vsubwev.h.bu"]
    fn __lsx_vsubwev_h_bu(a: __v16u8, b: __v16u8) -> __v8i16;
    #[link_name = "llvm.loongarch.lsx.vsubwod.d.wu"]
    fn __lsx_vsubwod_d_wu(a: __v4u32, b: __v4u32) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vsubwod.w.hu"]
    fn __lsx_vsubwod_w_hu(a: __v8u16, b: __v8u16) -> __v4i32;
    #[link_name = "llvm.loongarch.lsx.vsubwod.h.bu"]
    fn __lsx_vsubwod_h_bu(a: __v16u8, b: __v16u8) -> __v8i16;
    #[link_name = "llvm.loongarch.lsx.vaddwev.q.d"]
    fn __lsx_vaddwev_q_d(a: __v2i64, b: __v2i64) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vaddwod.q.d"]
    fn __lsx_vaddwod_q_d(a: __v2i64, b: __v2i64) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vaddwev.q.du"]
    fn __lsx_vaddwev_q_du(a: __v2u64, b: __v2u64) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vaddwod.q.du"]
    fn __lsx_vaddwod_q_du(a: __v2u64, b: __v2u64) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vsubwev.q.d"]
    fn __lsx_vsubwev_q_d(a: __v2i64, b: __v2i64) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vsubwod.q.d"]
    fn __lsx_vsubwod_q_d(a: __v2i64, b: __v2i64) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vsubwev.q.du"]
    fn __lsx_vsubwev_q_du(a: __v2u64, b: __v2u64) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vsubwod.q.du"]
    fn __lsx_vsubwod_q_du(a: __v2u64, b: __v2u64) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vaddwev.q.du.d"]
    fn __lsx_vaddwev_q_du_d(a: __v2u64, b: __v2i64) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vaddwod.q.du.d"]
    fn __lsx_vaddwod_q_du_d(a: __v2u64, b: __v2i64) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vmulwev.d.w"]
    fn __lsx_vmulwev_d_w(a: __v4i32, b: __v4i32) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vmulwev.w.h"]
    fn __lsx_vmulwev_w_h(a: __v8i16, b: __v8i16) -> __v4i32;
    #[link_name = "llvm.loongarch.lsx.vmulwev.h.b"]
    fn __lsx_vmulwev_h_b(a: __v16i8, b: __v16i8) -> __v8i16;
    #[link_name = "llvm.loongarch.lsx.vmulwod.d.w"]
    fn __lsx_vmulwod_d_w(a: __v4i32, b: __v4i32) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vmulwod.w.h"]
    fn __lsx_vmulwod_w_h(a: __v8i16, b: __v8i16) -> __v4i32;
    #[link_name = "llvm.loongarch.lsx.vmulwod.h.b"]
    fn __lsx_vmulwod_h_b(a: __v16i8, b: __v16i8) -> __v8i16;
    #[link_name = "llvm.loongarch.lsx.vmulwev.d.wu"]
    fn __lsx_vmulwev_d_wu(a: __v4u32, b: __v4u32) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vmulwev.w.hu"]
    fn __lsx_vmulwev_w_hu(a: __v8u16, b: __v8u16) -> __v4i32;
    #[link_name = "llvm.loongarch.lsx.vmulwev.h.bu"]
    fn __lsx_vmulwev_h_bu(a: __v16u8, b: __v16u8) -> __v8i16;
    #[link_name = "llvm.loongarch.lsx.vmulwod.d.wu"]
    fn __lsx_vmulwod_d_wu(a: __v4u32, b: __v4u32) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vmulwod.w.hu"]
    fn __lsx_vmulwod_w_hu(a: __v8u16, b: __v8u16) -> __v4i32;
    #[link_name = "llvm.loongarch.lsx.vmulwod.h.bu"]
    fn __lsx_vmulwod_h_bu(a: __v16u8, b: __v16u8) -> __v8i16;
    #[link_name = "llvm.loongarch.lsx.vmulwev.d.wu.w"]
    fn __lsx_vmulwev_d_wu_w(a: __v4u32, b: __v4i32) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vmulwev.w.hu.h"]
    fn __lsx_vmulwev_w_hu_h(a: __v8u16, b: __v8i16) -> __v4i32;
    #[link_name = "llvm.loongarch.lsx.vmulwev.h.bu.b"]
    fn __lsx_vmulwev_h_bu_b(a: __v16u8, b: __v16i8) -> __v8i16;
    #[link_name = "llvm.loongarch.lsx.vmulwod.d.wu.w"]
    fn __lsx_vmulwod_d_wu_w(a: __v4u32, b: __v4i32) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vmulwod.w.hu.h"]
    fn __lsx_vmulwod_w_hu_h(a: __v8u16, b: __v8i16) -> __v4i32;
    #[link_name = "llvm.loongarch.lsx.vmulwod.h.bu.b"]
    fn __lsx_vmulwod_h_bu_b(a: __v16u8, b: __v16i8) -> __v8i16;
    #[link_name = "llvm.loongarch.lsx.vmulwev.q.d"]
    fn __lsx_vmulwev_q_d(a: __v2i64, b: __v2i64) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vmulwod.q.d"]
    fn __lsx_vmulwod_q_d(a: __v2i64, b: __v2i64) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vmulwev.q.du"]
    fn __lsx_vmulwev_q_du(a: __v2u64, b: __v2u64) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vmulwod.q.du"]
    fn __lsx_vmulwod_q_du(a: __v2u64, b: __v2u64) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vmulwev.q.du.d"]
    fn __lsx_vmulwev_q_du_d(a: __v2u64, b: __v2i64) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vmulwod.q.du.d"]
    fn __lsx_vmulwod_q_du_d(a: __v2u64, b: __v2i64) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vhaddw.q.d"]
    fn __lsx_vhaddw_q_d(a: __v2i64, b: __v2i64) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vhaddw.qu.du"]
    fn __lsx_vhaddw_qu_du(a: __v2u64, b: __v2u64) -> __v2u64;
    #[link_name = "llvm.loongarch.lsx.vhsubw.q.d"]
    fn __lsx_vhsubw_q_d(a: __v2i64, b: __v2i64) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vhsubw.qu.du"]
    fn __lsx_vhsubw_qu_du(a: __v2u64, b: __v2u64) -> __v2u64;
    #[link_name = "llvm.loongarch.lsx.vmaddwev.d.w"]
    fn __lsx_vmaddwev_d_w(a: __v2i64, b: __v4i32, c: __v4i32) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vmaddwev.w.h"]
    fn __lsx_vmaddwev_w_h(a: __v4i32, b: __v8i16, c: __v8i16) -> __v4i32;
    #[link_name = "llvm.loongarch.lsx.vmaddwev.h.b"]
    fn __lsx_vmaddwev_h_b(a: __v8i16, b: __v16i8, c: __v16i8) -> __v8i16;
    #[link_name = "llvm.loongarch.lsx.vmaddwev.d.wu"]
    fn __lsx_vmaddwev_d_wu(a: __v2u64, b: __v4u32, c: __v4u32) -> __v2u64;
    #[link_name = "llvm.loongarch.lsx.vmaddwev.w.hu"]
    fn __lsx_vmaddwev_w_hu(a: __v4u32, b: __v8u16, c: __v8u16) -> __v4u32;
    #[link_name = "llvm.loongarch.lsx.vmaddwev.h.bu"]
    fn __lsx_vmaddwev_h_bu(a: __v8u16, b: __v16u8, c: __v16u8) -> __v8u16;
    #[link_name = "llvm.loongarch.lsx.vmaddwod.d.w"]
    fn __lsx_vmaddwod_d_w(a: __v2i64, b: __v4i32, c: __v4i32) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vmaddwod.w.h"]
    fn __lsx_vmaddwod_w_h(a: __v4i32, b: __v8i16, c: __v8i16) -> __v4i32;
    #[link_name = "llvm.loongarch.lsx.vmaddwod.h.b"]
    fn __lsx_vmaddwod_h_b(a: __v8i16, b: __v16i8, c: __v16i8) -> __v8i16;
    #[link_name = "llvm.loongarch.lsx.vmaddwod.d.wu"]
    fn __lsx_vmaddwod_d_wu(a: __v2u64, b: __v4u32, c: __v4u32) -> __v2u64;
    #[link_name = "llvm.loongarch.lsx.vmaddwod.w.hu"]
    fn __lsx_vmaddwod_w_hu(a: __v4u32, b: __v8u16, c: __v8u16) -> __v4u32;
    #[link_name = "llvm.loongarch.lsx.vmaddwod.h.bu"]
    fn __lsx_vmaddwod_h_bu(a: __v8u16, b: __v16u8, c: __v16u8) -> __v8u16;
    #[link_name = "llvm.loongarch.lsx.vmaddwev.d.wu.w"]
    fn __lsx_vmaddwev_d_wu_w(a: __v2i64, b: __v4u32, c: __v4i32) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vmaddwev.w.hu.h"]
    fn __lsx_vmaddwev_w_hu_h(a: __v4i32, b: __v8u16, c: __v8i16) -> __v4i32;
    #[link_name = "llvm.loongarch.lsx.vmaddwev.h.bu.b"]
    fn __lsx_vmaddwev_h_bu_b(a: __v8i16, b: __v16u8, c: __v16i8) -> __v8i16;
    #[link_name = "llvm.loongarch.lsx.vmaddwod.d.wu.w"]
    fn __lsx_vmaddwod_d_wu_w(a: __v2i64, b: __v4u32, c: __v4i32) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vmaddwod.w.hu.h"]
    fn __lsx_vmaddwod_w_hu_h(a: __v4i32, b: __v8u16, c: __v8i16) -> __v4i32;
    #[link_name = "llvm.loongarch.lsx.vmaddwod.h.bu.b"]
    fn __lsx_vmaddwod_h_bu_b(a: __v8i16, b: __v16u8, c: __v16i8) -> __v8i16;
    #[link_name = "llvm.loongarch.lsx.vmaddwev.q.d"]
    fn __lsx_vmaddwev_q_d(a: __v2i64, b: __v2i64, c: __v2i64) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vmaddwod.q.d"]
    fn __lsx_vmaddwod_q_d(a: __v2i64, b: __v2i64, c: __v2i64) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vmaddwev.q.du"]
    fn __lsx_vmaddwev_q_du(a: __v2u64, b: __v2u64, c: __v2u64) -> __v2u64;
    #[link_name = "llvm.loongarch.lsx.vmaddwod.q.du"]
    fn __lsx_vmaddwod_q_du(a: __v2u64, b: __v2u64, c: __v2u64) -> __v2u64;
    #[link_name = "llvm.loongarch.lsx.vmaddwev.q.du.d"]
    fn __lsx_vmaddwev_q_du_d(a: __v2i64, b: __v2u64, c: __v2i64) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vmaddwod.q.du.d"]
    fn __lsx_vmaddwod_q_du_d(a: __v2i64, b: __v2u64, c: __v2i64) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vadd.q"]
    fn __lsx_vadd_q(a: __v2i64, b: __v2i64) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vsub.q"]
    fn __lsx_vsub_q(a: __v2i64, b: __v2i64) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vldrepl.b"]
    fn __lsx_vldrepl_b(a: *const i8, b: i32) -> __v16i8;
    #[link_name = "llvm.loongarch.lsx.vldrepl.h"]
    fn __lsx_vldrepl_h(a: *const i8, b: i32) -> __v8i16;
    #[link_name = "llvm.loongarch.lsx.vldrepl.w"]
    fn __lsx_vldrepl_w(a: *const i8, b: i32) -> __v4i32;
    #[link_name = "llvm.loongarch.lsx.vldrepl.d"]
    fn __lsx_vldrepl_d(a: *const i8, b: i32) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vmskgez.b"]
    fn __lsx_vmskgez_b(a: __v16i8) -> __v16i8;
    #[link_name = "llvm.loongarch.lsx.vmsknz.b"]
    fn __lsx_vmsknz_b(a: __v16i8) -> __v16i8;
    #[link_name = "llvm.loongarch.lsx.vexth.h.b"]
    fn __lsx_vexth_h_b(a: __v16i8) -> __v8i16;
    #[link_name = "llvm.loongarch.lsx.vexth.w.h"]
    fn __lsx_vexth_w_h(a: __v8i16) -> __v4i32;
    #[link_name = "llvm.loongarch.lsx.vexth.d.w"]
    fn __lsx_vexth_d_w(a: __v4i32) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vexth.q.d"]
    fn __lsx_vexth_q_d(a: __v2i64) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vexth.hu.bu"]
    fn __lsx_vexth_hu_bu(a: __v16u8) -> __v8u16;
    #[link_name = "llvm.loongarch.lsx.vexth.wu.hu"]
    fn __lsx_vexth_wu_hu(a: __v8u16) -> __v4u32;
    #[link_name = "llvm.loongarch.lsx.vexth.du.wu"]
    fn __lsx_vexth_du_wu(a: __v4u32) -> __v2u64;
    #[link_name = "llvm.loongarch.lsx.vexth.qu.du"]
    fn __lsx_vexth_qu_du(a: __v2u64) -> __v2u64;
    #[link_name = "llvm.loongarch.lsx.vextl.q.d"]
    fn __lsx_vextl_q_d(a: __v2i64) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vsrlni.b.h"]
    fn __lsx_vsrlni_b_h(a: __v16i8, b: __v16i8, c: u32) -> __v16i8;
    #[link_name = "llvm.loongarch.lsx.vsrlni.h.w"]
    fn __lsx_vsrlni_h_w(a: __v8i16, b: __v8i16, c: u32) -> __v8i16;
    #[link_name = "llvm.loongarch.lsx.vsrlni.w.d"]
    fn __lsx_vsrlni_w_d(a: __v4i32, b: __v4i32, c: u32) -> __v4i32;
    #[link_name = "llvm.loongarch.lsx.vsrlni.d.q"]
    fn __lsx_vsrlni_d_q(a: __v2i64, b: __v2i64, c: u32) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vsrlrni.b.h"]
    fn __lsx_vsrlrni_b_h(a: __v16i8, b: __v16i8, c: u32) -> __v16i8;
    #[link_name = "llvm.loongarch.lsx.vsrlrni.h.w"]
    fn __lsx_vsrlrni_h_w(a: __v8i16, b: __v8i16, c: u32) -> __v8i16;
    #[link_name = "llvm.loongarch.lsx.vsrlrni.w.d"]
    fn __lsx_vsrlrni_w_d(a: __v4i32, b: __v4i32, c: u32) -> __v4i32;
    #[link_name = "llvm.loongarch.lsx.vsrlrni.d.q"]
    fn __lsx_vsrlrni_d_q(a: __v2i64, b: __v2i64, c: u32) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vssrlni.b.h"]
    fn __lsx_vssrlni_b_h(a: __v16i8, b: __v16i8, c: u32) -> __v16i8;
    #[link_name = "llvm.loongarch.lsx.vssrlni.h.w"]
    fn __lsx_vssrlni_h_w(a: __v8i16, b: __v8i16, c: u32) -> __v8i16;
    #[link_name = "llvm.loongarch.lsx.vssrlni.w.d"]
    fn __lsx_vssrlni_w_d(a: __v4i32, b: __v4i32, c: u32) -> __v4i32;
    #[link_name = "llvm.loongarch.lsx.vssrlni.d.q"]
    fn __lsx_vssrlni_d_q(a: __v2i64, b: __v2i64, c: u32) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vssrlni.bu.h"]
    fn __lsx_vssrlni_bu_h(a: __v16u8, b: __v16i8, c: u32) -> __v16u8;
    #[link_name = "llvm.loongarch.lsx.vssrlni.hu.w"]
    fn __lsx_vssrlni_hu_w(a: __v8u16, b: __v8i16, c: u32) -> __v8u16;
    #[link_name = "llvm.loongarch.lsx.vssrlni.wu.d"]
    fn __lsx_vssrlni_wu_d(a: __v4u32, b: __v4i32, c: u32) -> __v4u32;
    #[link_name = "llvm.loongarch.lsx.vssrlni.du.q"]
    fn __lsx_vssrlni_du_q(a: __v2u64, b: __v2i64, c: u32) -> __v2u64;
    #[link_name = "llvm.loongarch.lsx.vssrlrni.b.h"]
    fn __lsx_vssrlrni_b_h(a: __v16i8, b: __v16i8, c: u32) -> __v16i8;
    #[link_name = "llvm.loongarch.lsx.vssrlrni.h.w"]
    fn __lsx_vssrlrni_h_w(a: __v8i16, b: __v8i16, c: u32) -> __v8i16;
    #[link_name = "llvm.loongarch.lsx.vssrlrni.w.d"]
    fn __lsx_vssrlrni_w_d(a: __v4i32, b: __v4i32, c: u32) -> __v4i32;
    #[link_name = "llvm.loongarch.lsx.vssrlrni.d.q"]
    fn __lsx_vssrlrni_d_q(a: __v2i64, b: __v2i64, c: u32) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vssrlrni.bu.h"]
    fn __lsx_vssrlrni_bu_h(a: __v16u8, b: __v16i8, c: u32) -> __v16u8;
    #[link_name = "llvm.loongarch.lsx.vssrlrni.hu.w"]
    fn __lsx_vssrlrni_hu_w(a: __v8u16, b: __v8i16, c: u32) -> __v8u16;
    #[link_name = "llvm.loongarch.lsx.vssrlrni.wu.d"]
    fn __lsx_vssrlrni_wu_d(a: __v4u32, b: __v4i32, c: u32) -> __v4u32;
    #[link_name = "llvm.loongarch.lsx.vssrlrni.du.q"]
    fn __lsx_vssrlrni_du_q(a: __v2u64, b: __v2i64, c: u32) -> __v2u64;
    #[link_name = "llvm.loongarch.lsx.vsrani.b.h"]
    fn __lsx_vsrani_b_h(a: __v16i8, b: __v16i8, c: u32) -> __v16i8;
    #[link_name = "llvm.loongarch.lsx.vsrani.h.w"]
    fn __lsx_vsrani_h_w(a: __v8i16, b: __v8i16, c: u32) -> __v8i16;
    #[link_name = "llvm.loongarch.lsx.vsrani.w.d"]
    fn __lsx_vsrani_w_d(a: __v4i32, b: __v4i32, c: u32) -> __v4i32;
    #[link_name = "llvm.loongarch.lsx.vsrani.d.q"]
    fn __lsx_vsrani_d_q(a: __v2i64, b: __v2i64, c: u32) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vsrarni.b.h"]
    fn __lsx_vsrarni_b_h(a: __v16i8, b: __v16i8, c: u32) -> __v16i8;
    #[link_name = "llvm.loongarch.lsx.vsrarni.h.w"]
    fn __lsx_vsrarni_h_w(a: __v8i16, b: __v8i16, c: u32) -> __v8i16;
    #[link_name = "llvm.loongarch.lsx.vsrarni.w.d"]
    fn __lsx_vsrarni_w_d(a: __v4i32, b: __v4i32, c: u32) -> __v4i32;
    #[link_name = "llvm.loongarch.lsx.vsrarni.d.q"]
    fn __lsx_vsrarni_d_q(a: __v2i64, b: __v2i64, c: u32) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vssrani.b.h"]
    fn __lsx_vssrani_b_h(a: __v16i8, b: __v16i8, c: u32) -> __v16i8;
    #[link_name = "llvm.loongarch.lsx.vssrani.h.w"]
    fn __lsx_vssrani_h_w(a: __v8i16, b: __v8i16, c: u32) -> __v8i16;
    #[link_name = "llvm.loongarch.lsx.vssrani.w.d"]
    fn __lsx_vssrani_w_d(a: __v4i32, b: __v4i32, c: u32) -> __v4i32;
    #[link_name = "llvm.loongarch.lsx.vssrani.d.q"]
    fn __lsx_vssrani_d_q(a: __v2i64, b: __v2i64, c: u32) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vssrani.bu.h"]
    fn __lsx_vssrani_bu_h(a: __v16u8, b: __v16i8, c: u32) -> __v16u8;
    #[link_name = "llvm.loongarch.lsx.vssrani.hu.w"]
    fn __lsx_vssrani_hu_w(a: __v8u16, b: __v8i16, c: u32) -> __v8u16;
    #[link_name = "llvm.loongarch.lsx.vssrani.wu.d"]
    fn __lsx_vssrani_wu_d(a: __v4u32, b: __v4i32, c: u32) -> __v4u32;
    #[link_name = "llvm.loongarch.lsx.vssrani.du.q"]
    fn __lsx_vssrani_du_q(a: __v2u64, b: __v2i64, c: u32) -> __v2u64;
    #[link_name = "llvm.loongarch.lsx.vssrarni.b.h"]
    fn __lsx_vssrarni_b_h(a: __v16i8, b: __v16i8, c: u32) -> __v16i8;
    #[link_name = "llvm.loongarch.lsx.vssrarni.h.w"]
    fn __lsx_vssrarni_h_w(a: __v8i16, b: __v8i16, c: u32) -> __v8i16;
    #[link_name = "llvm.loongarch.lsx.vssrarni.w.d"]
    fn __lsx_vssrarni_w_d(a: __v4i32, b: __v4i32, c: u32) -> __v4i32;
    #[link_name = "llvm.loongarch.lsx.vssrarni.d.q"]
    fn __lsx_vssrarni_d_q(a: __v2i64, b: __v2i64, c: u32) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vssrarni.bu.h"]
    fn __lsx_vssrarni_bu_h(a: __v16u8, b: __v16i8, c: u32) -> __v16u8;
    #[link_name = "llvm.loongarch.lsx.vssrarni.hu.w"]
    fn __lsx_vssrarni_hu_w(a: __v8u16, b: __v8i16, c: u32) -> __v8u16;
    #[link_name = "llvm.loongarch.lsx.vssrarni.wu.d"]
    fn __lsx_vssrarni_wu_d(a: __v4u32, b: __v4i32, c: u32) -> __v4u32;
    #[link_name = "llvm.loongarch.lsx.vssrarni.du.q"]
    fn __lsx_vssrarni_du_q(a: __v2u64, b: __v2i64, c: u32) -> __v2u64;
    #[link_name = "llvm.loongarch.lsx.vpermi.w"]
    fn __lsx_vpermi_w(a: __v4i32, b: __v4i32, c: u32) -> __v4i32;
    #[link_name = "llvm.loongarch.lsx.vssrlrn.b.h"]
    fn __lsx_vssrlrn_b_h(a: __v8i16, b: __v8i16) -> __v16i8;
    #[link_name = "llvm.loongarch.lsx.vssrlrn.h.w"]
    fn __lsx_vssrlrn_h_w(a: __v4i32, b: __v4i32) -> __v8i16;
    #[link_name = "llvm.loongarch.lsx.vssrlrn.w.d"]
    fn __lsx_vssrlrn_w_d(a: __v2i64, b: __v2i64) -> __v4i32;
    #[link_name = "llvm.loongarch.lsx.vssrln.b.h"]
    fn __lsx_vssrln_b_h(a: __v8i16, b: __v8i16) -> __v16i8;
    #[link_name = "llvm.loongarch.lsx.vssrln.h.w"]
    fn __lsx_vssrln_h_w(a: __v4i32, b: __v4i32) -> __v8i16;
    #[link_name = "llvm.loongarch.lsx.vssrln.w.d"]
    fn __lsx_vssrln_w_d(a: __v2i64, b: __v2i64) -> __v4i32;
    #[link_name = "llvm.loongarch.lsx.vshuf.b"]
    fn __lsx_vshuf_b(a: __v16i8, b: __v16i8, c: __v16i8) -> __v16i8;
    #[link_name = "llvm.loongarch.lsx.vextl.qu.du"]
    fn __lsx_vextl_qu_du(a: __v2u64) -> __v2u64;
    #[link_name = "llvm.loongarch.lsx.bnz.b"]
    fn __lsx_bnz_b(a: __v16u8) -> i32;
    #[link_name = "llvm.loongarch.lsx.bnz.d"]
    fn __lsx_bnz_d(a: __v2u64) -> i32;
    #[link_name = "llvm.loongarch.lsx.bnz.h"]
    fn __lsx_bnz_h(a: __v8u16) -> i32;
    #[link_name = "llvm.loongarch.lsx.bnz.v"]
    fn __lsx_bnz_v(a: __v16u8) -> i32;
    #[link_name = "llvm.loongarch.lsx.bnz.w"]
    fn __lsx_bnz_w(a: __v4u32) -> i32;
    #[link_name = "llvm.loongarch.lsx.bz.b"]
    fn __lsx_bz_b(a: __v16u8) -> i32;
    #[link_name = "llvm.loongarch.lsx.bz.d"]
    fn __lsx_bz_d(a: __v2u64) -> i32;
    #[link_name = "llvm.loongarch.lsx.bz.h"]
    fn __lsx_bz_h(a: __v8u16) -> i32;
    #[link_name = "llvm.loongarch.lsx.bz.v"]
    fn __lsx_bz_v(a: __v16u8) -> i32;
    #[link_name = "llvm.loongarch.lsx.bz.w"]
    fn __lsx_bz_w(a: __v4u32) -> i32;
    #[link_name = "llvm.loongarch.lsx.vfcmp.caf.d"]
    fn __lsx_vfcmp_caf_d(a: __v2f64, b: __v2f64) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vfcmp.caf.s"]
    fn __lsx_vfcmp_caf_s(a: __v4f32, b: __v4f32) -> __v4i32;
    #[link_name = "llvm.loongarch.lsx.vfcmp.ceq.d"]
    fn __lsx_vfcmp_ceq_d(a: __v2f64, b: __v2f64) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vfcmp.ceq.s"]
    fn __lsx_vfcmp_ceq_s(a: __v4f32, b: __v4f32) -> __v4i32;
    #[link_name = "llvm.loongarch.lsx.vfcmp.cle.d"]
    fn __lsx_vfcmp_cle_d(a: __v2f64, b: __v2f64) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vfcmp.cle.s"]
    fn __lsx_vfcmp_cle_s(a: __v4f32, b: __v4f32) -> __v4i32;
    #[link_name = "llvm.loongarch.lsx.vfcmp.clt.d"]
    fn __lsx_vfcmp_clt_d(a: __v2f64, b: __v2f64) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vfcmp.clt.s"]
    fn __lsx_vfcmp_clt_s(a: __v4f32, b: __v4f32) -> __v4i32;
    #[link_name = "llvm.loongarch.lsx.vfcmp.cne.d"]
    fn __lsx_vfcmp_cne_d(a: __v2f64, b: __v2f64) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vfcmp.cne.s"]
    fn __lsx_vfcmp_cne_s(a: __v4f32, b: __v4f32) -> __v4i32;
    #[link_name = "llvm.loongarch.lsx.vfcmp.cor.d"]
    fn __lsx_vfcmp_cor_d(a: __v2f64, b: __v2f64) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vfcmp.cor.s"]
    fn __lsx_vfcmp_cor_s(a: __v4f32, b: __v4f32) -> __v4i32;
    #[link_name = "llvm.loongarch.lsx.vfcmp.cueq.d"]
    fn __lsx_vfcmp_cueq_d(a: __v2f64, b: __v2f64) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vfcmp.cueq.s"]
    fn __lsx_vfcmp_cueq_s(a: __v4f32, b: __v4f32) -> __v4i32;
    #[link_name = "llvm.loongarch.lsx.vfcmp.cule.d"]
    fn __lsx_vfcmp_cule_d(a: __v2f64, b: __v2f64) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vfcmp.cule.s"]
    fn __lsx_vfcmp_cule_s(a: __v4f32, b: __v4f32) -> __v4i32;
    #[link_name = "llvm.loongarch.lsx.vfcmp.cult.d"]
    fn __lsx_vfcmp_cult_d(a: __v2f64, b: __v2f64) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vfcmp.cult.s"]
    fn __lsx_vfcmp_cult_s(a: __v4f32, b: __v4f32) -> __v4i32;
    #[link_name = "llvm.loongarch.lsx.vfcmp.cun.d"]
    fn __lsx_vfcmp_cun_d(a: __v2f64, b: __v2f64) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vfcmp.cune.d"]
    fn __lsx_vfcmp_cune_d(a: __v2f64, b: __v2f64) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vfcmp.cune.s"]
    fn __lsx_vfcmp_cune_s(a: __v4f32, b: __v4f32) -> __v4i32;
    #[link_name = "llvm.loongarch.lsx.vfcmp.cun.s"]
    fn __lsx_vfcmp_cun_s(a: __v4f32, b: __v4f32) -> __v4i32;
    #[link_name = "llvm.loongarch.lsx.vfcmp.saf.d"]
    fn __lsx_vfcmp_saf_d(a: __v2f64, b: __v2f64) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vfcmp.saf.s"]
    fn __lsx_vfcmp_saf_s(a: __v4f32, b: __v4f32) -> __v4i32;
    #[link_name = "llvm.loongarch.lsx.vfcmp.seq.d"]
    fn __lsx_vfcmp_seq_d(a: __v2f64, b: __v2f64) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vfcmp.seq.s"]
    fn __lsx_vfcmp_seq_s(a: __v4f32, b: __v4f32) -> __v4i32;
    #[link_name = "llvm.loongarch.lsx.vfcmp.sle.d"]
    fn __lsx_vfcmp_sle_d(a: __v2f64, b: __v2f64) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vfcmp.sle.s"]
    fn __lsx_vfcmp_sle_s(a: __v4f32, b: __v4f32) -> __v4i32;
    #[link_name = "llvm.loongarch.lsx.vfcmp.slt.d"]
    fn __lsx_vfcmp_slt_d(a: __v2f64, b: __v2f64) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vfcmp.slt.s"]
    fn __lsx_vfcmp_slt_s(a: __v4f32, b: __v4f32) -> __v4i32;
    #[link_name = "llvm.loongarch.lsx.vfcmp.sne.d"]
    fn __lsx_vfcmp_sne_d(a: __v2f64, b: __v2f64) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vfcmp.sne.s"]
    fn __lsx_vfcmp_sne_s(a: __v4f32, b: __v4f32) -> __v4i32;
    #[link_name = "llvm.loongarch.lsx.vfcmp.sor.d"]
    fn __lsx_vfcmp_sor_d(a: __v2f64, b: __v2f64) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vfcmp.sor.s"]
    fn __lsx_vfcmp_sor_s(a: __v4f32, b: __v4f32) -> __v4i32;
    #[link_name = "llvm.loongarch.lsx.vfcmp.sueq.d"]
    fn __lsx_vfcmp_sueq_d(a: __v2f64, b: __v2f64) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vfcmp.sueq.s"]
    fn __lsx_vfcmp_sueq_s(a: __v4f32, b: __v4f32) -> __v4i32;
    #[link_name = "llvm.loongarch.lsx.vfcmp.sule.d"]
    fn __lsx_vfcmp_sule_d(a: __v2f64, b: __v2f64) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vfcmp.sule.s"]
    fn __lsx_vfcmp_sule_s(a: __v4f32, b: __v4f32) -> __v4i32;
    #[link_name = "llvm.loongarch.lsx.vfcmp.sult.d"]
    fn __lsx_vfcmp_sult_d(a: __v2f64, b: __v2f64) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vfcmp.sult.s"]
    fn __lsx_vfcmp_sult_s(a: __v4f32, b: __v4f32) -> __v4i32;
    #[link_name = "llvm.loongarch.lsx.vfcmp.sun.d"]
    fn __lsx_vfcmp_sun_d(a: __v2f64, b: __v2f64) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vfcmp.sune.d"]
    fn __lsx_vfcmp_sune_d(a: __v2f64, b: __v2f64) -> __v2i64;
    #[link_name = "llvm.loongarch.lsx.vfcmp.sune.s"]
    fn __lsx_vfcmp_sune_s(a: __v4f32, b: __v4f32) -> __v4i32;
    #[link_name = "llvm.loongarch.lsx.vfcmp.sun.s"]
    fn __lsx_vfcmp_sun_s(a: __v4f32, b: __v4f32) -> __v4i32;
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vsrar_b(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vsrar_b(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vsrar_h(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vsrar_h(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vsrar_w(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vsrar_w(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vsrar_d(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vsrar_d(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vsrari_b<const IMM3: u32>(a: m128i) -> m128i {
    static_assert_uimm_bits!(IMM3, 3);
    unsafe { transmute(__lsx_vsrari_b(transmute(a), IMM3)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vsrari_h<const IMM4: u32>(a: m128i) -> m128i {
    static_assert_uimm_bits!(IMM4, 4);
    unsafe { transmute(__lsx_vsrari_h(transmute(a), IMM4)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vsrari_w<const IMM5: u32>(a: m128i) -> m128i {
    static_assert_uimm_bits!(IMM5, 5);
    unsafe { transmute(__lsx_vsrari_w(transmute(a), IMM5)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vsrari_d<const IMM6: u32>(a: m128i) -> m128i {
    static_assert_uimm_bits!(IMM6, 6);
    unsafe { transmute(__lsx_vsrari_d(transmute(a), IMM6)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vsrlr_b(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vsrlr_b(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vsrlr_h(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vsrlr_h(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vsrlr_w(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vsrlr_w(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vsrlr_d(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vsrlr_d(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vsrlri_b<const IMM3: u32>(a: m128i) -> m128i {
    static_assert_uimm_bits!(IMM3, 3);
    unsafe { transmute(__lsx_vsrlri_b(transmute(a), IMM3)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vsrlri_h<const IMM4: u32>(a: m128i) -> m128i {
    static_assert_uimm_bits!(IMM4, 4);
    unsafe { transmute(__lsx_vsrlri_h(transmute(a), IMM4)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vsrlri_w<const IMM5: u32>(a: m128i) -> m128i {
    static_assert_uimm_bits!(IMM5, 5);
    unsafe { transmute(__lsx_vsrlri_w(transmute(a), IMM5)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vsrlri_d<const IMM6: u32>(a: m128i) -> m128i {
    static_assert_uimm_bits!(IMM6, 6);
    unsafe { transmute(__lsx_vsrlri_d(transmute(a), IMM6)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vbitclri_b<const IMM3: u32>(a: m128i) -> m128i {
    static_assert_uimm_bits!(IMM3, 3);
    unsafe { transmute(__lsx_vbitclri_b(transmute(a), IMM3)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vbitclri_h<const IMM4: u32>(a: m128i) -> m128i {
    static_assert_uimm_bits!(IMM4, 4);
    unsafe { transmute(__lsx_vbitclri_h(transmute(a), IMM4)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vbitclri_w<const IMM5: u32>(a: m128i) -> m128i {
    static_assert_uimm_bits!(IMM5, 5);
    unsafe { transmute(__lsx_vbitclri_w(transmute(a), IMM5)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vbitclri_d<const IMM6: u32>(a: m128i) -> m128i {
    static_assert_uimm_bits!(IMM6, 6);
    unsafe { transmute(__lsx_vbitclri_d(transmute(a), IMM6)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vbitseti_b<const IMM3: u32>(a: m128i) -> m128i {
    static_assert_uimm_bits!(IMM3, 3);
    unsafe { transmute(__lsx_vbitseti_b(transmute(a), IMM3)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vbitseti_h<const IMM4: u32>(a: m128i) -> m128i {
    static_assert_uimm_bits!(IMM4, 4);
    unsafe { transmute(__lsx_vbitseti_h(transmute(a), IMM4)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vbitseti_w<const IMM5: u32>(a: m128i) -> m128i {
    static_assert_uimm_bits!(IMM5, 5);
    unsafe { transmute(__lsx_vbitseti_w(transmute(a), IMM5)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vbitseti_d<const IMM6: u32>(a: m128i) -> m128i {
    static_assert_uimm_bits!(IMM6, 6);
    unsafe { transmute(__lsx_vbitseti_d(transmute(a), IMM6)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vbitrevi_b<const IMM3: u32>(a: m128i) -> m128i {
    static_assert_uimm_bits!(IMM3, 3);
    unsafe { transmute(__lsx_vbitrevi_b(transmute(a), IMM3)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vbitrevi_h<const IMM4: u32>(a: m128i) -> m128i {
    static_assert_uimm_bits!(IMM4, 4);
    unsafe { transmute(__lsx_vbitrevi_h(transmute(a), IMM4)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vbitrevi_w<const IMM5: u32>(a: m128i) -> m128i {
    static_assert_uimm_bits!(IMM5, 5);
    unsafe { transmute(__lsx_vbitrevi_w(transmute(a), IMM5)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vbitrevi_d<const IMM6: u32>(a: m128i) -> m128i {
    static_assert_uimm_bits!(IMM6, 6);
    unsafe { transmute(__lsx_vbitrevi_d(transmute(a), IMM6)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vsubi_bu<const IMM5: u32>(a: m128i) -> m128i {
    static_assert_uimm_bits!(IMM5, 5);
    unsafe { transmute(__lsx_vsubi_bu(transmute(a), IMM5)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vsubi_hu<const IMM5: u32>(a: m128i) -> m128i {
    static_assert_uimm_bits!(IMM5, 5);
    unsafe { transmute(__lsx_vsubi_hu(transmute(a), IMM5)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vsubi_wu<const IMM5: u32>(a: m128i) -> m128i {
    static_assert_uimm_bits!(IMM5, 5);
    unsafe { transmute(__lsx_vsubi_wu(transmute(a), IMM5)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vsubi_du<const IMM5: u32>(a: m128i) -> m128i {
    static_assert_uimm_bits!(IMM5, 5);
    unsafe { transmute(__lsx_vsubi_du(transmute(a), IMM5)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vsat_b<const IMM3: u32>(a: m128i) -> m128i {
    static_assert_uimm_bits!(IMM3, 3);
    unsafe { transmute(__lsx_vsat_b(transmute(a), IMM3)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vsat_h<const IMM4: u32>(a: m128i) -> m128i {
    static_assert_uimm_bits!(IMM4, 4);
    unsafe { transmute(__lsx_vsat_h(transmute(a), IMM4)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vsat_w<const IMM5: u32>(a: m128i) -> m128i {
    static_assert_uimm_bits!(IMM5, 5);
    unsafe { transmute(__lsx_vsat_w(transmute(a), IMM5)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vsat_d<const IMM6: u32>(a: m128i) -> m128i {
    static_assert_uimm_bits!(IMM6, 6);
    unsafe { transmute(__lsx_vsat_d(transmute(a), IMM6)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vsat_bu<const IMM3: u32>(a: m128i) -> m128i {
    static_assert_uimm_bits!(IMM3, 3);
    unsafe { transmute(__lsx_vsat_bu(transmute(a), IMM3)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vsat_hu<const IMM4: u32>(a: m128i) -> m128i {
    static_assert_uimm_bits!(IMM4, 4);
    unsafe { transmute(__lsx_vsat_hu(transmute(a), IMM4)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vsat_wu<const IMM5: u32>(a: m128i) -> m128i {
    static_assert_uimm_bits!(IMM5, 5);
    unsafe { transmute(__lsx_vsat_wu(transmute(a), IMM5)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vsat_du<const IMM6: u32>(a: m128i) -> m128i {
    static_assert_uimm_bits!(IMM6, 6);
    unsafe { transmute(__lsx_vsat_du(transmute(a), IMM6)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vdiv_b(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vdiv_b(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vdiv_h(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vdiv_h(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vdiv_w(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vdiv_w(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vdiv_d(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vdiv_d(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vdiv_bu(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vdiv_bu(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vdiv_hu(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vdiv_hu(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vdiv_wu(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vdiv_wu(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vdiv_du(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vdiv_du(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vhaddw_h_b(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vhaddw_h_b(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vhaddw_w_h(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vhaddw_w_h(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vhaddw_d_w(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vhaddw_d_w(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vhaddw_hu_bu(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vhaddw_hu_bu(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vhaddw_wu_hu(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vhaddw_wu_hu(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vhaddw_du_wu(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vhaddw_du_wu(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vhsubw_h_b(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vhsubw_h_b(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vhsubw_w_h(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vhsubw_w_h(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vhsubw_d_w(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vhsubw_d_w(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vhsubw_hu_bu(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vhsubw_hu_bu(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vhsubw_wu_hu(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vhsubw_wu_hu(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vhsubw_du_wu(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vhsubw_du_wu(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vmod_b(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vmod_b(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vmod_h(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vmod_h(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vmod_w(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vmod_w(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vmod_d(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vmod_d(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vmod_bu(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vmod_bu(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vmod_hu(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vmod_hu(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vmod_wu(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vmod_wu(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vmod_du(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vmod_du(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vreplve_b(a: m128i, b: i32) -> m128i {
    unsafe { transmute(__lsx_vreplve_b(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vreplve_h(a: m128i, b: i32) -> m128i {
    unsafe { transmute(__lsx_vreplve_h(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vreplve_w(a: m128i, b: i32) -> m128i {
    unsafe { transmute(__lsx_vreplve_w(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vreplve_d(a: m128i, b: i32) -> m128i {
    unsafe { transmute(__lsx_vreplve_d(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vshuf_h(a: m128i, b: m128i, c: m128i) -> m128i {
    unsafe { transmute(__lsx_vshuf_h(transmute(a), transmute(b), transmute(c))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vshuf_w(a: m128i, b: m128i, c: m128i) -> m128i {
    unsafe { transmute(__lsx_vshuf_w(transmute(a), transmute(b), transmute(c))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vshuf_d(a: m128i, b: m128i, c: m128i) -> m128i {
    unsafe { transmute(__lsx_vshuf_d(transmute(a), transmute(b), transmute(c))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vandi_b<const IMM8: u32>(a: m128i) -> m128i {
    static_assert_uimm_bits!(IMM8, 8);
    unsafe { transmute(__lsx_vandi_b(transmute(a), IMM8)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vori_b<const IMM8: u32>(a: m128i) -> m128i {
    static_assert_uimm_bits!(IMM8, 8);
    unsafe { transmute(__lsx_vori_b(transmute(a), IMM8)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vnori_b<const IMM8: u32>(a: m128i) -> m128i {
    static_assert_uimm_bits!(IMM8, 8);
    unsafe { transmute(__lsx_vnori_b(transmute(a), IMM8)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vxori_b<const IMM8: u32>(a: m128i) -> m128i {
    static_assert_uimm_bits!(IMM8, 8);
    unsafe { transmute(__lsx_vxori_b(transmute(a), IMM8)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vbitsel_v(a: m128i, b: m128i, c: m128i) -> m128i {
    unsafe { transmute(__lsx_vbitsel_v(transmute(a), transmute(b), transmute(c))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vbitseli_b<const IMM8: u32>(a: m128i, b: m128i) -> m128i {
    static_assert_uimm_bits!(IMM8, 8);
    unsafe { transmute(__lsx_vbitseli_b(transmute(a), transmute(b), IMM8)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vclo_b(a: m128i) -> m128i {
    unsafe { transmute(__lsx_vclo_b(transmute(a))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vclo_h(a: m128i) -> m128i {
    unsafe { transmute(__lsx_vclo_h(transmute(a))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vclo_w(a: m128i) -> m128i {
    unsafe { transmute(__lsx_vclo_w(transmute(a))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vclo_d(a: m128i) -> m128i {
    unsafe { transmute(__lsx_vclo_d(transmute(a))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vfcvt_h_s(a: m128, b: m128) -> m128i {
    unsafe { transmute(__lsx_vfcvt_h_s(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vfcvt_s_d(a: m128d, b: m128d) -> m128 {
    unsafe { transmute(__lsx_vfcvt_s_d(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vfmin_s(a: m128, b: m128) -> m128 {
    unsafe { transmute(__lsx_vfmin_s(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vfmin_d(a: m128d, b: m128d) -> m128d {
    unsafe { transmute(__lsx_vfmin_d(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vfmina_s(a: m128, b: m128) -> m128 {
    unsafe { transmute(__lsx_vfmina_s(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vfmina_d(a: m128d, b: m128d) -> m128d {
    unsafe { transmute(__lsx_vfmina_d(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vfmax_s(a: m128, b: m128) -> m128 {
    unsafe { transmute(__lsx_vfmax_s(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vfmax_d(a: m128d, b: m128d) -> m128d {
    unsafe { transmute(__lsx_vfmax_d(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vfmaxa_s(a: m128, b: m128) -> m128 {
    unsafe { transmute(__lsx_vfmaxa_s(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vfmaxa_d(a: m128d, b: m128d) -> m128d {
    unsafe { transmute(__lsx_vfmaxa_d(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vfclass_s(a: m128) -> m128i {
    unsafe { transmute(__lsx_vfclass_s(transmute(a))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vfclass_d(a: m128d) -> m128i {
    unsafe { transmute(__lsx_vfclass_d(transmute(a))) }
}

#[inline]
#[target_feature(enable = "lsx,frecipe")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vfrecipe_s(a: m128) -> m128 {
    unsafe { transmute(__lsx_vfrecipe_s(transmute(a))) }
}

#[inline]
#[target_feature(enable = "lsx,frecipe")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vfrecipe_d(a: m128d) -> m128d {
    unsafe { transmute(__lsx_vfrecipe_d(transmute(a))) }
}

#[inline]
#[target_feature(enable = "lsx,frecipe")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vfrsqrte_s(a: m128) -> m128 {
    unsafe { transmute(__lsx_vfrsqrte_s(transmute(a))) }
}

#[inline]
#[target_feature(enable = "lsx,frecipe")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vfrsqrte_d(a: m128d) -> m128d {
    unsafe { transmute(__lsx_vfrsqrte_d(transmute(a))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vfrint_s(a: m128) -> m128 {
    unsafe { transmute(__lsx_vfrint_s(transmute(a))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vfrint_d(a: m128d) -> m128d {
    unsafe { transmute(__lsx_vfrint_d(transmute(a))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vflogb_s(a: m128) -> m128 {
    unsafe { transmute(__lsx_vflogb_s(transmute(a))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vflogb_d(a: m128d) -> m128d {
    unsafe { transmute(__lsx_vflogb_d(transmute(a))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vfcvth_s_h(a: m128i) -> m128 {
    unsafe { transmute(__lsx_vfcvth_s_h(transmute(a))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vfcvth_d_s(a: m128) -> m128d {
    unsafe { transmute(__lsx_vfcvth_d_s(transmute(a))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vfcvtl_s_h(a: m128i) -> m128 {
    unsafe { transmute(__lsx_vfcvtl_s_h(transmute(a))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vfcvtl_d_s(a: m128) -> m128d {
    unsafe { transmute(__lsx_vfcvtl_d_s(transmute(a))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vftint_w_s(a: m128) -> m128i {
    unsafe { transmute(__lsx_vftint_w_s(transmute(a))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vftint_l_d(a: m128d) -> m128i {
    unsafe { transmute(__lsx_vftint_l_d(transmute(a))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vftint_wu_s(a: m128) -> m128i {
    unsafe { transmute(__lsx_vftint_wu_s(transmute(a))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vftint_lu_d(a: m128d) -> m128i {
    unsafe { transmute(__lsx_vftint_lu_d(transmute(a))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vftintrz_w_s(a: m128) -> m128i {
    unsafe { transmute(__lsx_vftintrz_w_s(transmute(a))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vftintrz_l_d(a: m128d) -> m128i {
    unsafe { transmute(__lsx_vftintrz_l_d(transmute(a))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vftintrz_wu_s(a: m128) -> m128i {
    unsafe { transmute(__lsx_vftintrz_wu_s(transmute(a))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vftintrz_lu_d(a: m128d) -> m128i {
    unsafe { transmute(__lsx_vftintrz_lu_d(transmute(a))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vffint_s_w(a: m128i) -> m128 {
    unsafe { transmute(__lsx_vffint_s_w(transmute(a))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vffint_d_l(a: m128i) -> m128d {
    unsafe { transmute(__lsx_vffint_d_l(transmute(a))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vffint_s_wu(a: m128i) -> m128 {
    unsafe { transmute(__lsx_vffint_s_wu(transmute(a))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vffint_d_lu(a: m128i) -> m128d {
    unsafe { transmute(__lsx_vffint_d_lu(transmute(a))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vsllwil_h_b<const IMM3: u32>(a: m128i) -> m128i {
    static_assert_uimm_bits!(IMM3, 3);
    unsafe { transmute(__lsx_vsllwil_h_b(transmute(a), IMM3)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vsllwil_w_h<const IMM4: u32>(a: m128i) -> m128i {
    static_assert_uimm_bits!(IMM4, 4);
    unsafe { transmute(__lsx_vsllwil_w_h(transmute(a), IMM4)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vsllwil_d_w<const IMM5: u32>(a: m128i) -> m128i {
    static_assert_uimm_bits!(IMM5, 5);
    unsafe { transmute(__lsx_vsllwil_d_w(transmute(a), IMM5)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vsllwil_hu_bu<const IMM3: u32>(a: m128i) -> m128i {
    static_assert_uimm_bits!(IMM3, 3);
    unsafe { transmute(__lsx_vsllwil_hu_bu(transmute(a), IMM3)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vsllwil_wu_hu<const IMM4: u32>(a: m128i) -> m128i {
    static_assert_uimm_bits!(IMM4, 4);
    unsafe { transmute(__lsx_vsllwil_wu_hu(transmute(a), IMM4)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vsllwil_du_wu<const IMM5: u32>(a: m128i) -> m128i {
    static_assert_uimm_bits!(IMM5, 5);
    unsafe { transmute(__lsx_vsllwil_du_wu(transmute(a), IMM5)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vsran_b_h(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vsran_b_h(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vsran_h_w(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vsran_h_w(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vsran_w_d(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vsran_w_d(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vssran_b_h(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vssran_b_h(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vssran_h_w(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vssran_h_w(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vssran_w_d(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vssran_w_d(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vssran_bu_h(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vssran_bu_h(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vssran_hu_w(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vssran_hu_w(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vssran_wu_d(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vssran_wu_d(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vsrarn_b_h(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vsrarn_b_h(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vsrarn_h_w(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vsrarn_h_w(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vsrarn_w_d(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vsrarn_w_d(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vssrarn_b_h(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vssrarn_b_h(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vssrarn_h_w(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vssrarn_h_w(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vssrarn_w_d(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vssrarn_w_d(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vssrarn_bu_h(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vssrarn_bu_h(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vssrarn_hu_w(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vssrarn_hu_w(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vssrarn_wu_d(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vssrarn_wu_d(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vsrln_b_h(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vsrln_b_h(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vsrln_h_w(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vsrln_h_w(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vsrln_w_d(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vsrln_w_d(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vssrln_bu_h(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vssrln_bu_h(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vssrln_hu_w(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vssrln_hu_w(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vssrln_wu_d(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vssrln_wu_d(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vsrlrn_b_h(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vsrlrn_b_h(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vsrlrn_h_w(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vsrlrn_h_w(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vsrlrn_w_d(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vsrlrn_w_d(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vssrlrn_bu_h(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vssrlrn_bu_h(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vssrlrn_hu_w(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vssrlrn_hu_w(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vssrlrn_wu_d(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vssrlrn_wu_d(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vfrstpi_b<const IMM5: u32>(a: m128i, b: m128i) -> m128i {
    static_assert_uimm_bits!(IMM5, 5);
    unsafe { transmute(__lsx_vfrstpi_b(transmute(a), transmute(b), IMM5)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vfrstpi_h<const IMM5: u32>(a: m128i, b: m128i) -> m128i {
    static_assert_uimm_bits!(IMM5, 5);
    unsafe { transmute(__lsx_vfrstpi_h(transmute(a), transmute(b), IMM5)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vfrstp_b(a: m128i, b: m128i, c: m128i) -> m128i {
    unsafe { transmute(__lsx_vfrstp_b(transmute(a), transmute(b), transmute(c))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vfrstp_h(a: m128i, b: m128i, c: m128i) -> m128i {
    unsafe { transmute(__lsx_vfrstp_h(transmute(a), transmute(b), transmute(c))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vextrins_b<const IMM8: u32>(a: m128i, b: m128i) -> m128i {
    static_assert_uimm_bits!(IMM8, 8);
    unsafe { transmute(__lsx_vextrins_b(transmute(a), transmute(b), IMM8)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vextrins_h<const IMM8: u32>(a: m128i, b: m128i) -> m128i {
    static_assert_uimm_bits!(IMM8, 8);
    unsafe { transmute(__lsx_vextrins_h(transmute(a), transmute(b), IMM8)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vextrins_w<const IMM8: u32>(a: m128i, b: m128i) -> m128i {
    static_assert_uimm_bits!(IMM8, 8);
    unsafe { transmute(__lsx_vextrins_w(transmute(a), transmute(b), IMM8)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vextrins_d<const IMM8: u32>(a: m128i, b: m128i) -> m128i {
    static_assert_uimm_bits!(IMM8, 8);
    unsafe { transmute(__lsx_vextrins_d(transmute(a), transmute(b), IMM8)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vmskltz_b(a: m128i) -> m128i {
    unsafe { transmute(__lsx_vmskltz_b(transmute(a))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vmskltz_h(a: m128i) -> m128i {
    unsafe { transmute(__lsx_vmskltz_h(transmute(a))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vmskltz_w(a: m128i) -> m128i {
    unsafe { transmute(__lsx_vmskltz_w(transmute(a))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vmskltz_d(a: m128i) -> m128i {
    unsafe { transmute(__lsx_vmskltz_d(transmute(a))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vsigncov_b(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vsigncov_b(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vsigncov_h(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vsigncov_h(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vsigncov_w(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vsigncov_w(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vsigncov_d(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vsigncov_d(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vftintrne_w_s(a: m128) -> m128i {
    unsafe { transmute(__lsx_vftintrne_w_s(transmute(a))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vftintrne_l_d(a: m128d) -> m128i {
    unsafe { transmute(__lsx_vftintrne_l_d(transmute(a))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vftintrp_w_s(a: m128) -> m128i {
    unsafe { transmute(__lsx_vftintrp_w_s(transmute(a))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vftintrp_l_d(a: m128d) -> m128i {
    unsafe { transmute(__lsx_vftintrp_l_d(transmute(a))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vftintrm_w_s(a: m128) -> m128i {
    unsafe { transmute(__lsx_vftintrm_w_s(transmute(a))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vftintrm_l_d(a: m128d) -> m128i {
    unsafe { transmute(__lsx_vftintrm_l_d(transmute(a))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vftint_w_d(a: m128d, b: m128d) -> m128i {
    unsafe { transmute(__lsx_vftint_w_d(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vffint_s_l(a: m128i, b: m128i) -> m128 {
    unsafe { transmute(__lsx_vffint_s_l(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vftintrz_w_d(a: m128d, b: m128d) -> m128i {
    unsafe { transmute(__lsx_vftintrz_w_d(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vftintrp_w_d(a: m128d, b: m128d) -> m128i {
    unsafe { transmute(__lsx_vftintrp_w_d(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vftintrm_w_d(a: m128d, b: m128d) -> m128i {
    unsafe { transmute(__lsx_vftintrm_w_d(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vftintrne_w_d(a: m128d, b: m128d) -> m128i {
    unsafe { transmute(__lsx_vftintrne_w_d(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vftintl_l_s(a: m128) -> m128i {
    unsafe { transmute(__lsx_vftintl_l_s(transmute(a))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vftinth_l_s(a: m128) -> m128i {
    unsafe { transmute(__lsx_vftinth_l_s(transmute(a))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vffinth_d_w(a: m128i) -> m128d {
    unsafe { transmute(__lsx_vffinth_d_w(transmute(a))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vffintl_d_w(a: m128i) -> m128d {
    unsafe { transmute(__lsx_vffintl_d_w(transmute(a))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vftintrzl_l_s(a: m128) -> m128i {
    unsafe { transmute(__lsx_vftintrzl_l_s(transmute(a))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vftintrzh_l_s(a: m128) -> m128i {
    unsafe { transmute(__lsx_vftintrzh_l_s(transmute(a))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vftintrpl_l_s(a: m128) -> m128i {
    unsafe { transmute(__lsx_vftintrpl_l_s(transmute(a))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vftintrph_l_s(a: m128) -> m128i {
    unsafe { transmute(__lsx_vftintrph_l_s(transmute(a))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vftintrml_l_s(a: m128) -> m128i {
    unsafe { transmute(__lsx_vftintrml_l_s(transmute(a))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vftintrmh_l_s(a: m128) -> m128i {
    unsafe { transmute(__lsx_vftintrmh_l_s(transmute(a))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vftintrnel_l_s(a: m128) -> m128i {
    unsafe { transmute(__lsx_vftintrnel_l_s(transmute(a))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vftintrneh_l_s(a: m128) -> m128i {
    unsafe { transmute(__lsx_vftintrneh_l_s(transmute(a))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vfrintrne_s(a: m128) -> m128 {
    unsafe { transmute(__lsx_vfrintrne_s(transmute(a))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vfrintrne_d(a: m128d) -> m128d {
    unsafe { transmute(__lsx_vfrintrne_d(transmute(a))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub unsafe fn lsx_vstelm_b<const IMM_S8: i32, const IMM4: u32>(a: m128i, mem_addr: *mut i8) {
    static_assert_simm_bits!(IMM_S8, 8);
    static_assert_uimm_bits!(IMM4, 4);
    __lsx_vstelm_b(transmute(a), mem_addr, IMM_S8, IMM4)
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub unsafe fn lsx_vstelm_h<const IMM_S8: i32, const IMM3: u32>(a: m128i, mem_addr: *mut i8) {
    static_assert_simm_bits!(IMM_S8, 8);
    static_assert_uimm_bits!(IMM3, 3);
    __lsx_vstelm_h(transmute(a), mem_addr, IMM_S8, IMM3)
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub unsafe fn lsx_vstelm_w<const IMM_S8: i32, const IMM2: u32>(a: m128i, mem_addr: *mut i8) {
    static_assert_simm_bits!(IMM_S8, 8);
    static_assert_uimm_bits!(IMM2, 2);
    __lsx_vstelm_w(transmute(a), mem_addr, IMM_S8, IMM2)
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub unsafe fn lsx_vstelm_d<const IMM_S8: i32, const IMM1: u32>(a: m128i, mem_addr: *mut i8) {
    static_assert_simm_bits!(IMM_S8, 8);
    static_assert_uimm_bits!(IMM1, 1);
    __lsx_vstelm_d(transmute(a), mem_addr, IMM_S8, IMM1)
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vaddwev_d_w(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vaddwev_d_w(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vaddwev_w_h(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vaddwev_w_h(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vaddwev_h_b(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vaddwev_h_b(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vaddwod_d_w(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vaddwod_d_w(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vaddwod_w_h(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vaddwod_w_h(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vaddwod_h_b(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vaddwod_h_b(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vaddwev_d_wu(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vaddwev_d_wu(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vaddwev_w_hu(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vaddwev_w_hu(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vaddwev_h_bu(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vaddwev_h_bu(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vaddwod_d_wu(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vaddwod_d_wu(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vaddwod_w_hu(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vaddwod_w_hu(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vaddwod_h_bu(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vaddwod_h_bu(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vaddwev_d_wu_w(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vaddwev_d_wu_w(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vaddwev_w_hu_h(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vaddwev_w_hu_h(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vaddwev_h_bu_b(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vaddwev_h_bu_b(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vaddwod_d_wu_w(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vaddwod_d_wu_w(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vaddwod_w_hu_h(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vaddwod_w_hu_h(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vaddwod_h_bu_b(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vaddwod_h_bu_b(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vsubwev_d_w(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vsubwev_d_w(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vsubwev_w_h(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vsubwev_w_h(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vsubwev_h_b(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vsubwev_h_b(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vsubwod_d_w(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vsubwod_d_w(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vsubwod_w_h(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vsubwod_w_h(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vsubwod_h_b(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vsubwod_h_b(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vsubwev_d_wu(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vsubwev_d_wu(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vsubwev_w_hu(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vsubwev_w_hu(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vsubwev_h_bu(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vsubwev_h_bu(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vsubwod_d_wu(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vsubwod_d_wu(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vsubwod_w_hu(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vsubwod_w_hu(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vsubwod_h_bu(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vsubwod_h_bu(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vaddwev_q_d(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vaddwev_q_d(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vaddwod_q_d(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vaddwod_q_d(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vaddwev_q_du(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vaddwev_q_du(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vaddwod_q_du(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vaddwod_q_du(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vsubwev_q_d(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vsubwev_q_d(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vsubwod_q_d(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vsubwod_q_d(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vsubwev_q_du(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vsubwev_q_du(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vsubwod_q_du(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vsubwod_q_du(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vaddwev_q_du_d(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vaddwev_q_du_d(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vaddwod_q_du_d(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vaddwod_q_du_d(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vmulwev_d_w(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vmulwev_d_w(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vmulwev_w_h(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vmulwev_w_h(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vmulwev_h_b(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vmulwev_h_b(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vmulwod_d_w(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vmulwod_d_w(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vmulwod_w_h(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vmulwod_w_h(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vmulwod_h_b(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vmulwod_h_b(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vmulwev_d_wu(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vmulwev_d_wu(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vmulwev_w_hu(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vmulwev_w_hu(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vmulwev_h_bu(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vmulwev_h_bu(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vmulwod_d_wu(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vmulwod_d_wu(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vmulwod_w_hu(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vmulwod_w_hu(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vmulwod_h_bu(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vmulwod_h_bu(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vmulwev_d_wu_w(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vmulwev_d_wu_w(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vmulwev_w_hu_h(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vmulwev_w_hu_h(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vmulwev_h_bu_b(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vmulwev_h_bu_b(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vmulwod_d_wu_w(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vmulwod_d_wu_w(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vmulwod_w_hu_h(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vmulwod_w_hu_h(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vmulwod_h_bu_b(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vmulwod_h_bu_b(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vmulwev_q_d(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vmulwev_q_d(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vmulwod_q_d(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vmulwod_q_d(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vmulwev_q_du(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vmulwev_q_du(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vmulwod_q_du(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vmulwod_q_du(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vmulwev_q_du_d(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vmulwev_q_du_d(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vmulwod_q_du_d(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vmulwod_q_du_d(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vhaddw_q_d(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vhaddw_q_d(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vhaddw_qu_du(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vhaddw_qu_du(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vhsubw_q_d(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vhsubw_q_d(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vhsubw_qu_du(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vhsubw_qu_du(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vmaddwev_d_w(a: m128i, b: m128i, c: m128i) -> m128i {
    unsafe { transmute(__lsx_vmaddwev_d_w(transmute(a), transmute(b), transmute(c))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vmaddwev_w_h(a: m128i, b: m128i, c: m128i) -> m128i {
    unsafe { transmute(__lsx_vmaddwev_w_h(transmute(a), transmute(b), transmute(c))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vmaddwev_h_b(a: m128i, b: m128i, c: m128i) -> m128i {
    unsafe { transmute(__lsx_vmaddwev_h_b(transmute(a), transmute(b), transmute(c))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vmaddwev_d_wu(a: m128i, b: m128i, c: m128i) -> m128i {
    unsafe {
        transmute(__lsx_vmaddwev_d_wu(
            transmute(a),
            transmute(b),
            transmute(c),
        ))
    }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vmaddwev_w_hu(a: m128i, b: m128i, c: m128i) -> m128i {
    unsafe {
        transmute(__lsx_vmaddwev_w_hu(
            transmute(a),
            transmute(b),
            transmute(c),
        ))
    }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vmaddwev_h_bu(a: m128i, b: m128i, c: m128i) -> m128i {
    unsafe {
        transmute(__lsx_vmaddwev_h_bu(
            transmute(a),
            transmute(b),
            transmute(c),
        ))
    }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vmaddwod_d_w(a: m128i, b: m128i, c: m128i) -> m128i {
    unsafe { transmute(__lsx_vmaddwod_d_w(transmute(a), transmute(b), transmute(c))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vmaddwod_w_h(a: m128i, b: m128i, c: m128i) -> m128i {
    unsafe { transmute(__lsx_vmaddwod_w_h(transmute(a), transmute(b), transmute(c))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vmaddwod_h_b(a: m128i, b: m128i, c: m128i) -> m128i {
    unsafe { transmute(__lsx_vmaddwod_h_b(transmute(a), transmute(b), transmute(c))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vmaddwod_d_wu(a: m128i, b: m128i, c: m128i) -> m128i {
    unsafe {
        transmute(__lsx_vmaddwod_d_wu(
            transmute(a),
            transmute(b),
            transmute(c),
        ))
    }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vmaddwod_w_hu(a: m128i, b: m128i, c: m128i) -> m128i {
    unsafe {
        transmute(__lsx_vmaddwod_w_hu(
            transmute(a),
            transmute(b),
            transmute(c),
        ))
    }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vmaddwod_h_bu(a: m128i, b: m128i, c: m128i) -> m128i {
    unsafe {
        transmute(__lsx_vmaddwod_h_bu(
            transmute(a),
            transmute(b),
            transmute(c),
        ))
    }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vmaddwev_d_wu_w(a: m128i, b: m128i, c: m128i) -> m128i {
    unsafe {
        transmute(__lsx_vmaddwev_d_wu_w(
            transmute(a),
            transmute(b),
            transmute(c),
        ))
    }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vmaddwev_w_hu_h(a: m128i, b: m128i, c: m128i) -> m128i {
    unsafe {
        transmute(__lsx_vmaddwev_w_hu_h(
            transmute(a),
            transmute(b),
            transmute(c),
        ))
    }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vmaddwev_h_bu_b(a: m128i, b: m128i, c: m128i) -> m128i {
    unsafe {
        transmute(__lsx_vmaddwev_h_bu_b(
            transmute(a),
            transmute(b),
            transmute(c),
        ))
    }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vmaddwod_d_wu_w(a: m128i, b: m128i, c: m128i) -> m128i {
    unsafe {
        transmute(__lsx_vmaddwod_d_wu_w(
            transmute(a),
            transmute(b),
            transmute(c),
        ))
    }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vmaddwod_w_hu_h(a: m128i, b: m128i, c: m128i) -> m128i {
    unsafe {
        transmute(__lsx_vmaddwod_w_hu_h(
            transmute(a),
            transmute(b),
            transmute(c),
        ))
    }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vmaddwod_h_bu_b(a: m128i, b: m128i, c: m128i) -> m128i {
    unsafe {
        transmute(__lsx_vmaddwod_h_bu_b(
            transmute(a),
            transmute(b),
            transmute(c),
        ))
    }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vmaddwev_q_d(a: m128i, b: m128i, c: m128i) -> m128i {
    unsafe { transmute(__lsx_vmaddwev_q_d(transmute(a), transmute(b), transmute(c))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vmaddwod_q_d(a: m128i, b: m128i, c: m128i) -> m128i {
    unsafe { transmute(__lsx_vmaddwod_q_d(transmute(a), transmute(b), transmute(c))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vmaddwev_q_du(a: m128i, b: m128i, c: m128i) -> m128i {
    unsafe {
        transmute(__lsx_vmaddwev_q_du(
            transmute(a),
            transmute(b),
            transmute(c),
        ))
    }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vmaddwod_q_du(a: m128i, b: m128i, c: m128i) -> m128i {
    unsafe {
        transmute(__lsx_vmaddwod_q_du(
            transmute(a),
            transmute(b),
            transmute(c),
        ))
    }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vmaddwev_q_du_d(a: m128i, b: m128i, c: m128i) -> m128i {
    unsafe {
        transmute(__lsx_vmaddwev_q_du_d(
            transmute(a),
            transmute(b),
            transmute(c),
        ))
    }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vmaddwod_q_du_d(a: m128i, b: m128i, c: m128i) -> m128i {
    unsafe {
        transmute(__lsx_vmaddwod_q_du_d(
            transmute(a),
            transmute(b),
            transmute(c),
        ))
    }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vadd_q(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vadd_q(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vsub_q(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vsub_q(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub unsafe fn lsx_vldrepl_b<const IMM_S12: i32>(mem_addr: *const i8) -> m128i {
    static_assert_simm_bits!(IMM_S12, 12);
    transmute(__lsx_vldrepl_b(mem_addr, IMM_S12))
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub unsafe fn lsx_vldrepl_h<const IMM_S11: i32>(mem_addr: *const i8) -> m128i {
    static_assert_simm_bits!(IMM_S11, 11);
    transmute(__lsx_vldrepl_h(mem_addr, IMM_S11))
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub unsafe fn lsx_vldrepl_w<const IMM_S10: i32>(mem_addr: *const i8) -> m128i {
    static_assert_simm_bits!(IMM_S10, 10);
    transmute(__lsx_vldrepl_w(mem_addr, IMM_S10))
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub unsafe fn lsx_vldrepl_d<const IMM_S9: i32>(mem_addr: *const i8) -> m128i {
    static_assert_simm_bits!(IMM_S9, 9);
    transmute(__lsx_vldrepl_d(mem_addr, IMM_S9))
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vmskgez_b(a: m128i) -> m128i {
    unsafe { transmute(__lsx_vmskgez_b(transmute(a))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vmsknz_b(a: m128i) -> m128i {
    unsafe { transmute(__lsx_vmsknz_b(transmute(a))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vexth_h_b(a: m128i) -> m128i {
    unsafe { transmute(__lsx_vexth_h_b(transmute(a))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vexth_w_h(a: m128i) -> m128i {
    unsafe { transmute(__lsx_vexth_w_h(transmute(a))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vexth_d_w(a: m128i) -> m128i {
    unsafe { transmute(__lsx_vexth_d_w(transmute(a))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vexth_q_d(a: m128i) -> m128i {
    unsafe { transmute(__lsx_vexth_q_d(transmute(a))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vexth_hu_bu(a: m128i) -> m128i {
    unsafe { transmute(__lsx_vexth_hu_bu(transmute(a))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vexth_wu_hu(a: m128i) -> m128i {
    unsafe { transmute(__lsx_vexth_wu_hu(transmute(a))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vexth_du_wu(a: m128i) -> m128i {
    unsafe { transmute(__lsx_vexth_du_wu(transmute(a))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vexth_qu_du(a: m128i) -> m128i {
    unsafe { transmute(__lsx_vexth_qu_du(transmute(a))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vextl_q_d(a: m128i) -> m128i {
    unsafe { transmute(__lsx_vextl_q_d(transmute(a))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vsrlni_b_h<const IMM4: u32>(a: m128i, b: m128i) -> m128i {
    static_assert_uimm_bits!(IMM4, 4);
    unsafe { transmute(__lsx_vsrlni_b_h(transmute(a), transmute(b), IMM4)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vsrlni_h_w<const IMM5: u32>(a: m128i, b: m128i) -> m128i {
    static_assert_uimm_bits!(IMM5, 5);
    unsafe { transmute(__lsx_vsrlni_h_w(transmute(a), transmute(b), IMM5)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vsrlni_w_d<const IMM6: u32>(a: m128i, b: m128i) -> m128i {
    static_assert_uimm_bits!(IMM6, 6);
    unsafe { transmute(__lsx_vsrlni_w_d(transmute(a), transmute(b), IMM6)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vsrlni_d_q<const IMM7: u32>(a: m128i, b: m128i) -> m128i {
    static_assert_uimm_bits!(IMM7, 7);
    unsafe { transmute(__lsx_vsrlni_d_q(transmute(a), transmute(b), IMM7)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vsrlrni_b_h<const IMM4: u32>(a: m128i, b: m128i) -> m128i {
    static_assert_uimm_bits!(IMM4, 4);
    unsafe { transmute(__lsx_vsrlrni_b_h(transmute(a), transmute(b), IMM4)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vsrlrni_h_w<const IMM5: u32>(a: m128i, b: m128i) -> m128i {
    static_assert_uimm_bits!(IMM5, 5);
    unsafe { transmute(__lsx_vsrlrni_h_w(transmute(a), transmute(b), IMM5)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vsrlrni_w_d<const IMM6: u32>(a: m128i, b: m128i) -> m128i {
    static_assert_uimm_bits!(IMM6, 6);
    unsafe { transmute(__lsx_vsrlrni_w_d(transmute(a), transmute(b), IMM6)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vsrlrni_d_q<const IMM7: u32>(a: m128i, b: m128i) -> m128i {
    static_assert_uimm_bits!(IMM7, 7);
    unsafe { transmute(__lsx_vsrlrni_d_q(transmute(a), transmute(b), IMM7)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vssrlni_b_h<const IMM4: u32>(a: m128i, b: m128i) -> m128i {
    static_assert_uimm_bits!(IMM4, 4);
    unsafe { transmute(__lsx_vssrlni_b_h(transmute(a), transmute(b), IMM4)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vssrlni_h_w<const IMM5: u32>(a: m128i, b: m128i) -> m128i {
    static_assert_uimm_bits!(IMM5, 5);
    unsafe { transmute(__lsx_vssrlni_h_w(transmute(a), transmute(b), IMM5)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vssrlni_w_d<const IMM6: u32>(a: m128i, b: m128i) -> m128i {
    static_assert_uimm_bits!(IMM6, 6);
    unsafe { transmute(__lsx_vssrlni_w_d(transmute(a), transmute(b), IMM6)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vssrlni_d_q<const IMM7: u32>(a: m128i, b: m128i) -> m128i {
    static_assert_uimm_bits!(IMM7, 7);
    unsafe { transmute(__lsx_vssrlni_d_q(transmute(a), transmute(b), IMM7)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vssrlni_bu_h<const IMM4: u32>(a: m128i, b: m128i) -> m128i {
    static_assert_uimm_bits!(IMM4, 4);
    unsafe { transmute(__lsx_vssrlni_bu_h(transmute(a), transmute(b), IMM4)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vssrlni_hu_w<const IMM5: u32>(a: m128i, b: m128i) -> m128i {
    static_assert_uimm_bits!(IMM5, 5);
    unsafe { transmute(__lsx_vssrlni_hu_w(transmute(a), transmute(b), IMM5)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vssrlni_wu_d<const IMM6: u32>(a: m128i, b: m128i) -> m128i {
    static_assert_uimm_bits!(IMM6, 6);
    unsafe { transmute(__lsx_vssrlni_wu_d(transmute(a), transmute(b), IMM6)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vssrlni_du_q<const IMM7: u32>(a: m128i, b: m128i) -> m128i {
    static_assert_uimm_bits!(IMM7, 7);
    unsafe { transmute(__lsx_vssrlni_du_q(transmute(a), transmute(b), IMM7)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vssrlrni_b_h<const IMM4: u32>(a: m128i, b: m128i) -> m128i {
    static_assert_uimm_bits!(IMM4, 4);
    unsafe { transmute(__lsx_vssrlrni_b_h(transmute(a), transmute(b), IMM4)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vssrlrni_h_w<const IMM5: u32>(a: m128i, b: m128i) -> m128i {
    static_assert_uimm_bits!(IMM5, 5);
    unsafe { transmute(__lsx_vssrlrni_h_w(transmute(a), transmute(b), IMM5)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vssrlrni_w_d<const IMM6: u32>(a: m128i, b: m128i) -> m128i {
    static_assert_uimm_bits!(IMM6, 6);
    unsafe { transmute(__lsx_vssrlrni_w_d(transmute(a), transmute(b), IMM6)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vssrlrni_d_q<const IMM7: u32>(a: m128i, b: m128i) -> m128i {
    static_assert_uimm_bits!(IMM7, 7);
    unsafe { transmute(__lsx_vssrlrni_d_q(transmute(a), transmute(b), IMM7)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vssrlrni_bu_h<const IMM4: u32>(a: m128i, b: m128i) -> m128i {
    static_assert_uimm_bits!(IMM4, 4);
    unsafe { transmute(__lsx_vssrlrni_bu_h(transmute(a), transmute(b), IMM4)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vssrlrni_hu_w<const IMM5: u32>(a: m128i, b: m128i) -> m128i {
    static_assert_uimm_bits!(IMM5, 5);
    unsafe { transmute(__lsx_vssrlrni_hu_w(transmute(a), transmute(b), IMM5)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vssrlrni_wu_d<const IMM6: u32>(a: m128i, b: m128i) -> m128i {
    static_assert_uimm_bits!(IMM6, 6);
    unsafe { transmute(__lsx_vssrlrni_wu_d(transmute(a), transmute(b), IMM6)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vssrlrni_du_q<const IMM7: u32>(a: m128i, b: m128i) -> m128i {
    static_assert_uimm_bits!(IMM7, 7);
    unsafe { transmute(__lsx_vssrlrni_du_q(transmute(a), transmute(b), IMM7)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vsrani_b_h<const IMM4: u32>(a: m128i, b: m128i) -> m128i {
    static_assert_uimm_bits!(IMM4, 4);
    unsafe { transmute(__lsx_vsrani_b_h(transmute(a), transmute(b), IMM4)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vsrani_h_w<const IMM5: u32>(a: m128i, b: m128i) -> m128i {
    static_assert_uimm_bits!(IMM5, 5);
    unsafe { transmute(__lsx_vsrani_h_w(transmute(a), transmute(b), IMM5)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vsrani_w_d<const IMM6: u32>(a: m128i, b: m128i) -> m128i {
    static_assert_uimm_bits!(IMM6, 6);
    unsafe { transmute(__lsx_vsrani_w_d(transmute(a), transmute(b), IMM6)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vsrani_d_q<const IMM7: u32>(a: m128i, b: m128i) -> m128i {
    static_assert_uimm_bits!(IMM7, 7);
    unsafe { transmute(__lsx_vsrani_d_q(transmute(a), transmute(b), IMM7)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vsrarni_b_h<const IMM4: u32>(a: m128i, b: m128i) -> m128i {
    static_assert_uimm_bits!(IMM4, 4);
    unsafe { transmute(__lsx_vsrarni_b_h(transmute(a), transmute(b), IMM4)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vsrarni_h_w<const IMM5: u32>(a: m128i, b: m128i) -> m128i {
    static_assert_uimm_bits!(IMM5, 5);
    unsafe { transmute(__lsx_vsrarni_h_w(transmute(a), transmute(b), IMM5)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vsrarni_w_d<const IMM6: u32>(a: m128i, b: m128i) -> m128i {
    static_assert_uimm_bits!(IMM6, 6);
    unsafe { transmute(__lsx_vsrarni_w_d(transmute(a), transmute(b), IMM6)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vsrarni_d_q<const IMM7: u32>(a: m128i, b: m128i) -> m128i {
    static_assert_uimm_bits!(IMM7, 7);
    unsafe { transmute(__lsx_vsrarni_d_q(transmute(a), transmute(b), IMM7)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vssrani_b_h<const IMM4: u32>(a: m128i, b: m128i) -> m128i {
    static_assert_uimm_bits!(IMM4, 4);
    unsafe { transmute(__lsx_vssrani_b_h(transmute(a), transmute(b), IMM4)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vssrani_h_w<const IMM5: u32>(a: m128i, b: m128i) -> m128i {
    static_assert_uimm_bits!(IMM5, 5);
    unsafe { transmute(__lsx_vssrani_h_w(transmute(a), transmute(b), IMM5)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vssrani_w_d<const IMM6: u32>(a: m128i, b: m128i) -> m128i {
    static_assert_uimm_bits!(IMM6, 6);
    unsafe { transmute(__lsx_vssrani_w_d(transmute(a), transmute(b), IMM6)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vssrani_d_q<const IMM7: u32>(a: m128i, b: m128i) -> m128i {
    static_assert_uimm_bits!(IMM7, 7);
    unsafe { transmute(__lsx_vssrani_d_q(transmute(a), transmute(b), IMM7)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vssrani_bu_h<const IMM4: u32>(a: m128i, b: m128i) -> m128i {
    static_assert_uimm_bits!(IMM4, 4);
    unsafe { transmute(__lsx_vssrani_bu_h(transmute(a), transmute(b), IMM4)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vssrani_hu_w<const IMM5: u32>(a: m128i, b: m128i) -> m128i {
    static_assert_uimm_bits!(IMM5, 5);
    unsafe { transmute(__lsx_vssrani_hu_w(transmute(a), transmute(b), IMM5)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vssrani_wu_d<const IMM6: u32>(a: m128i, b: m128i) -> m128i {
    static_assert_uimm_bits!(IMM6, 6);
    unsafe { transmute(__lsx_vssrani_wu_d(transmute(a), transmute(b), IMM6)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vssrani_du_q<const IMM7: u32>(a: m128i, b: m128i) -> m128i {
    static_assert_uimm_bits!(IMM7, 7);
    unsafe { transmute(__lsx_vssrani_du_q(transmute(a), transmute(b), IMM7)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vssrarni_b_h<const IMM4: u32>(a: m128i, b: m128i) -> m128i {
    static_assert_uimm_bits!(IMM4, 4);
    unsafe { transmute(__lsx_vssrarni_b_h(transmute(a), transmute(b), IMM4)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vssrarni_h_w<const IMM5: u32>(a: m128i, b: m128i) -> m128i {
    static_assert_uimm_bits!(IMM5, 5);
    unsafe { transmute(__lsx_vssrarni_h_w(transmute(a), transmute(b), IMM5)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vssrarni_w_d<const IMM6: u32>(a: m128i, b: m128i) -> m128i {
    static_assert_uimm_bits!(IMM6, 6);
    unsafe { transmute(__lsx_vssrarni_w_d(transmute(a), transmute(b), IMM6)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vssrarni_d_q<const IMM7: u32>(a: m128i, b: m128i) -> m128i {
    static_assert_uimm_bits!(IMM7, 7);
    unsafe { transmute(__lsx_vssrarni_d_q(transmute(a), transmute(b), IMM7)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vssrarni_bu_h<const IMM4: u32>(a: m128i, b: m128i) -> m128i {
    static_assert_uimm_bits!(IMM4, 4);
    unsafe { transmute(__lsx_vssrarni_bu_h(transmute(a), transmute(b), IMM4)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vssrarni_hu_w<const IMM5: u32>(a: m128i, b: m128i) -> m128i {
    static_assert_uimm_bits!(IMM5, 5);
    unsafe { transmute(__lsx_vssrarni_hu_w(transmute(a), transmute(b), IMM5)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vssrarni_wu_d<const IMM6: u32>(a: m128i, b: m128i) -> m128i {
    static_assert_uimm_bits!(IMM6, 6);
    unsafe { transmute(__lsx_vssrarni_wu_d(transmute(a), transmute(b), IMM6)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vssrarni_du_q<const IMM7: u32>(a: m128i, b: m128i) -> m128i {
    static_assert_uimm_bits!(IMM7, 7);
    unsafe { transmute(__lsx_vssrarni_du_q(transmute(a), transmute(b), IMM7)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vpermi_w<const IMM8: u32>(a: m128i, b: m128i) -> m128i {
    static_assert_uimm_bits!(IMM8, 8);
    unsafe { transmute(__lsx_vpermi_w(transmute(a), transmute(b), IMM8)) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vssrlrn_b_h(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vssrlrn_b_h(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vssrlrn_h_w(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vssrlrn_h_w(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vssrlrn_w_d(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vssrlrn_w_d(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vssrln_b_h(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vssrln_b_h(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vssrln_h_w(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vssrln_h_w(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vssrln_w_d(a: m128i, b: m128i) -> m128i {
    unsafe { transmute(__lsx_vssrln_w_d(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vshuf_b(a: m128i, b: m128i, c: m128i) -> m128i {
    unsafe { transmute(__lsx_vshuf_b(transmute(a), transmute(b), transmute(c))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vextl_qu_du(a: m128i) -> m128i {
    unsafe { transmute(__lsx_vextl_qu_du(transmute(a))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_bnz_b(a: m128i) -> i32 {
    unsafe { transmute(__lsx_bnz_b(transmute(a))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_bnz_d(a: m128i) -> i32 {
    unsafe { transmute(__lsx_bnz_d(transmute(a))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_bnz_h(a: m128i) -> i32 {
    unsafe { transmute(__lsx_bnz_h(transmute(a))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_bnz_v(a: m128i) -> i32 {
    unsafe { transmute(__lsx_bnz_v(transmute(a))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_bnz_w(a: m128i) -> i32 {
    unsafe { transmute(__lsx_bnz_w(transmute(a))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_bz_b(a: m128i) -> i32 {
    unsafe { transmute(__lsx_bz_b(transmute(a))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_bz_d(a: m128i) -> i32 {
    unsafe { transmute(__lsx_bz_d(transmute(a))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_bz_h(a: m128i) -> i32 {
    unsafe { transmute(__lsx_bz_h(transmute(a))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_bz_v(a: m128i) -> i32 {
    unsafe { transmute(__lsx_bz_v(transmute(a))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_bz_w(a: m128i) -> i32 {
    unsafe { transmute(__lsx_bz_w(transmute(a))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vfcmp_caf_d(a: m128d, b: m128d) -> m128i {
    unsafe { transmute(__lsx_vfcmp_caf_d(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vfcmp_caf_s(a: m128, b: m128) -> m128i {
    unsafe { transmute(__lsx_vfcmp_caf_s(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vfcmp_ceq_d(a: m128d, b: m128d) -> m128i {
    unsafe { transmute(__lsx_vfcmp_ceq_d(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vfcmp_ceq_s(a: m128, b: m128) -> m128i {
    unsafe { transmute(__lsx_vfcmp_ceq_s(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vfcmp_cle_d(a: m128d, b: m128d) -> m128i {
    unsafe { transmute(__lsx_vfcmp_cle_d(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vfcmp_cle_s(a: m128, b: m128) -> m128i {
    unsafe { transmute(__lsx_vfcmp_cle_s(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vfcmp_clt_d(a: m128d, b: m128d) -> m128i {
    unsafe { transmute(__lsx_vfcmp_clt_d(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vfcmp_clt_s(a: m128, b: m128) -> m128i {
    unsafe { transmute(__lsx_vfcmp_clt_s(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vfcmp_cne_d(a: m128d, b: m128d) -> m128i {
    unsafe { transmute(__lsx_vfcmp_cne_d(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vfcmp_cne_s(a: m128, b: m128) -> m128i {
    unsafe { transmute(__lsx_vfcmp_cne_s(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vfcmp_cor_d(a: m128d, b: m128d) -> m128i {
    unsafe { transmute(__lsx_vfcmp_cor_d(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vfcmp_cor_s(a: m128, b: m128) -> m128i {
    unsafe { transmute(__lsx_vfcmp_cor_s(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vfcmp_cueq_d(a: m128d, b: m128d) -> m128i {
    unsafe { transmute(__lsx_vfcmp_cueq_d(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vfcmp_cueq_s(a: m128, b: m128) -> m128i {
    unsafe { transmute(__lsx_vfcmp_cueq_s(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vfcmp_cule_d(a: m128d, b: m128d) -> m128i {
    unsafe { transmute(__lsx_vfcmp_cule_d(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vfcmp_cule_s(a: m128, b: m128) -> m128i {
    unsafe { transmute(__lsx_vfcmp_cule_s(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vfcmp_cult_d(a: m128d, b: m128d) -> m128i {
    unsafe { transmute(__lsx_vfcmp_cult_d(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vfcmp_cult_s(a: m128, b: m128) -> m128i {
    unsafe { transmute(__lsx_vfcmp_cult_s(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vfcmp_cun_d(a: m128d, b: m128d) -> m128i {
    unsafe { transmute(__lsx_vfcmp_cun_d(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vfcmp_cune_d(a: m128d, b: m128d) -> m128i {
    unsafe { transmute(__lsx_vfcmp_cune_d(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vfcmp_cune_s(a: m128, b: m128) -> m128i {
    unsafe { transmute(__lsx_vfcmp_cune_s(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vfcmp_cun_s(a: m128, b: m128) -> m128i {
    unsafe { transmute(__lsx_vfcmp_cun_s(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vfcmp_saf_d(a: m128d, b: m128d) -> m128i {
    unsafe { transmute(__lsx_vfcmp_saf_d(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vfcmp_saf_s(a: m128, b: m128) -> m128i {
    unsafe { transmute(__lsx_vfcmp_saf_s(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vfcmp_seq_d(a: m128d, b: m128d) -> m128i {
    unsafe { transmute(__lsx_vfcmp_seq_d(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vfcmp_seq_s(a: m128, b: m128) -> m128i {
    unsafe { transmute(__lsx_vfcmp_seq_s(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vfcmp_sle_d(a: m128d, b: m128d) -> m128i {
    unsafe { transmute(__lsx_vfcmp_sle_d(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vfcmp_sle_s(a: m128, b: m128) -> m128i {
    unsafe { transmute(__lsx_vfcmp_sle_s(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vfcmp_slt_d(a: m128d, b: m128d) -> m128i {
    unsafe { transmute(__lsx_vfcmp_slt_d(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vfcmp_slt_s(a: m128, b: m128) -> m128i {
    unsafe { transmute(__lsx_vfcmp_slt_s(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vfcmp_sne_d(a: m128d, b: m128d) -> m128i {
    unsafe { transmute(__lsx_vfcmp_sne_d(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vfcmp_sne_s(a: m128, b: m128) -> m128i {
    unsafe { transmute(__lsx_vfcmp_sne_s(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vfcmp_sor_d(a: m128d, b: m128d) -> m128i {
    unsafe { transmute(__lsx_vfcmp_sor_d(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vfcmp_sor_s(a: m128, b: m128) -> m128i {
    unsafe { transmute(__lsx_vfcmp_sor_s(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vfcmp_sueq_d(a: m128d, b: m128d) -> m128i {
    unsafe { transmute(__lsx_vfcmp_sueq_d(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vfcmp_sueq_s(a: m128, b: m128) -> m128i {
    unsafe { transmute(__lsx_vfcmp_sueq_s(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vfcmp_sule_d(a: m128d, b: m128d) -> m128i {
    unsafe { transmute(__lsx_vfcmp_sule_d(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vfcmp_sule_s(a: m128, b: m128) -> m128i {
    unsafe { transmute(__lsx_vfcmp_sule_s(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vfcmp_sult_d(a: m128d, b: m128d) -> m128i {
    unsafe { transmute(__lsx_vfcmp_sult_d(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vfcmp_sult_s(a: m128, b: m128) -> m128i {
    unsafe { transmute(__lsx_vfcmp_sult_s(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vfcmp_sun_d(a: m128d, b: m128d) -> m128i {
    unsafe { transmute(__lsx_vfcmp_sun_d(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vfcmp_sune_d(a: m128d, b: m128d) -> m128i {
    unsafe { transmute(__lsx_vfcmp_sune_d(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vfcmp_sune_s(a: m128, b: m128) -> m128i {
    unsafe { transmute(__lsx_vfcmp_sune_s(transmute(a), transmute(b))) }
}

#[inline]
#[target_feature(enable = "lsx")]
#[stable(feature = "stdarch_loongarch_simd", since = "CURRENT_RUSTC_VERSION")]
pub fn lsx_vfcmp_sun_s(a: m128, b: m128) -> m128i {
    unsafe { transmute(__lsx_vfcmp_sun_s(transmute(a), transmute(b))) }
}
