//! Owned and borrowed Unix-like file descriptors.

#![stable(feature = "io_safety", since = "1.63.0")]
#![deny(unsafe_op_in_unsafe_fn)]

#[cfg(target_os = "motor")]
use moto_rt::libc;

use super::raw::{AsRawFd, FromRawFd, IntoRawFd, RawFd};
use crate::alloc::Allocator;
#[cfg(not(target_os = "trusty"))]
use crate::fs;
use crate::macros::rustdoc_skip_body;
use crate::marker::PhantomData;
use crate::mem::ManuallyDrop;
#[cfg(not(any(
    all(target_family = "wasm", not(target_os = "emscripten")),
    target_env = "sgx",
    target_os = "hermit",
    target_os = "trusty",
    target_os = "motor"
)))]
use crate::sys::cvt;
#[cfg(not(target_os = "trusty"))]
use crate::sys::{AsInner, FromInner, IntoInner};
use crate::{fmt, io};

type ValidRawFd = core::num::niche_types::NotAllOnes<RawFd>;

/// A borrowed file descriptor.
///
/// This has a lifetime parameter to tie it to the lifetime of something that owns the file
/// descriptor. For the duration of that lifetime, it is guaranteed that nobody will close the file
/// descriptor.
///
/// This uses `repr(transparent)` and has the representation of a host file
/// descriptor, so it can be used in FFI in places where a file descriptor is
/// passed as an argument, it is not captured or consumed, and it never has the
/// value `-1`.
///
/// This type does not have a [`ToOwned`][crate::borrow::ToOwned]
/// implementation. Calling `.to_owned()` on a variable of this type will call
/// it on `&BorrowedFd` and use `Clone::clone()` like `ToOwned` does for all
/// types implementing `Clone`. The result will be descriptor borrowed under
/// the same lifetime.
///
/// To obtain an [`OwnedFd`], you can use [`BorrowedFd::try_clone_to_owned`]
/// instead, but this is not supported on all platforms.
#[derive(Copy, Clone)]
#[repr(transparent)]
#[rustc_nonnull_optimization_guaranteed]
#[stable(feature = "io_safety", since = "1.63.0")]
pub struct BorrowedFd<'fd> {
    fd: ValidRawFd,
    _phantom: PhantomData<&'fd OwnedFd>,
}

/// An owned file descriptor.
///
/// This closes the file descriptor on drop. It is guaranteed that nobody else will close the file
/// descriptor.
///
/// This uses `repr(transparent)` and has the representation of a host file
/// descriptor, so it can be used in FFI in places where a file descriptor is
/// passed as a consumed argument or returned as an owned value, and it never
/// has the value `-1`.
///
/// You can use [`AsFd::as_fd`] to obtain a [`BorrowedFd`].
#[repr(transparent)]
#[rustc_nonnull_optimization_guaranteed]
#[stable(feature = "io_safety", since = "1.63.0")]
pub struct OwnedFd {
    fd: ValidRawFd,
}

impl BorrowedFd<'_> {
    /// Returns a `BorrowedFd` holding the given raw file descriptor.
    ///
    /// # Safety
    ///
    /// The resource pointed to by `fd` must remain open for the duration of
    /// the returned `BorrowedFd`.
    ///
    /// # Panics
    ///
    /// Panics if the raw file descriptor has the value `-1`.
    #[inline]
    #[track_caller]
    #[rustc_const_stable(feature = "io_safety", since = "1.63.0")]
    #[stable(feature = "io_safety", since = "1.63.0")]
    pub const unsafe fn borrow_raw(fd: RawFd) -> Self {
        Self { fd: ValidRawFd::new(fd).expect("fd != -1"), _phantom: PhantomData }
    }

    /// Converts a `BorrowedFd` into a reference to a file-like type.
    ///
    #[cfg_attr(all(unix, not(miri)), doc = "```")]
    #[cfg_attr(not(unix), doc = "```ignore (needs unix)")]
    /// # #![feature(fd_view)]
    /// # use std::fs::File;
    /// # use std::io;
    /// # use std::os::fd::AsFd;
    /// let meta = io::stdout().as_fd().to_view::<File>().metadata().unwrap();
    /// if meta.is_file() {
    ///     println!("stdout is a regular file");
    /// }
    /// ```
    #[unstable(feature = "fd_view", issue = "160402")]
    pub fn to_view<T>(&self) -> &T
    where
        Self: AsRef<T>,
    {
        self.as_ref()
    }
}

impl OwnedFd {
    /// Creates a new `OwnedFd` instance that shares the same underlying file
    /// description as the existing `OwnedFd` instance.
    #[stable(feature = "io_safety", since = "1.63.0")]
    pub fn try_clone(&self) -> io::Result<Self> {
        self.as_fd().try_clone_to_owned()
    }
}

impl BorrowedFd<'_> {
    /// Creates a new `OwnedFd` instance that shares the same underlying file
    /// description as the existing `BorrowedFd` instance.
    #[cfg(not(any(
        all(target_family = "wasm", not(target_os = "emscripten")),
        target_os = "hermit",
        target_os = "trusty",
        target_os = "motor"
    )))]
    #[stable(feature = "io_safety", since = "1.63.0")]
    #[rustdoc_skip_body]
    pub fn try_clone_to_owned(&self) -> io::Result<OwnedFd> {
        // We want to atomically duplicate this file descriptor and set the
        // CLOEXEC flag, and currently that's done via F_DUPFD_CLOEXEC. This
        // is a POSIX flag that was added to Linux in 2.6.24.
        #[cfg(not(any(target_os = "espidf", target_os = "vita")))]
        let cmd = libc::F_DUPFD_CLOEXEC;

        // For ESP-IDF, F_DUPFD is used instead, because the CLOEXEC semantics
        // will never be supported, as this is a bare metal framework with
        // no capabilities for multi-process execution. While F_DUPFD is also
        // not supported yet, it might be (currently it returns ENOSYS).
        #[cfg(any(target_os = "espidf", target_os = "vita"))]
        let cmd = libc::F_DUPFD;

        // Avoid using file descriptors below 3 as they are used for stdio
        let fd = cvt(unsafe { libc::fcntl(self.as_raw_fd(), cmd, 3) })?;
        Ok(unsafe { OwnedFd::from_raw_fd(fd) })
    }

    /// Creates a new `OwnedFd` instance that shares the same underlying file
    /// description as the existing `BorrowedFd` instance.
    #[cfg(any(
        all(target_family = "wasm", not(target_os = "emscripten")),
        target_os = "hermit",
        target_os = "trusty"
    ))]
    #[stable(feature = "io_safety", since = "1.63.0")]
    pub fn try_clone_to_owned(&self) -> io::Result<OwnedFd> {
        Err(io::Error::UNSUPPORTED_PLATFORM)
    }

    /// Creates a new `OwnedFd` instance that shares the same underlying file
    /// description as the existing `BorrowedFd` instance.
    #[cfg(target_os = "motor")]
    #[stable(feature = "io_safety", since = "1.63.0")]
    pub fn try_clone_to_owned(&self) -> io::Result<OwnedFd> {
        let fd = moto_rt::fs::duplicate(self.as_raw_fd()).map_err(crate::sys::map_motor_error)?;
        Ok(unsafe { OwnedFd::from_raw_fd(fd) })
    }
}

#[stable(feature = "io_safety", since = "1.63.0")]
impl AsRawFd for BorrowedFd<'_> {
    #[inline]
    fn as_raw_fd(&self) -> RawFd {
        self.fd.as_inner()
    }
}

#[stable(feature = "io_safety", since = "1.63.0")]
impl AsRawFd for OwnedFd {
    #[inline]
    fn as_raw_fd(&self) -> RawFd {
        self.fd.as_inner()
    }
}

#[stable(feature = "io_safety", since = "1.63.0")]
impl IntoRawFd for OwnedFd {
    #[inline]
    fn into_raw_fd(self) -> RawFd {
        ManuallyDrop::new(self).fd.as_inner()
    }
}

#[stable(feature = "io_safety", since = "1.63.0")]
impl FromRawFd for OwnedFd {
    /// Constructs a new instance of `Self` from the given raw file descriptor.
    ///
    /// # Safety
    ///
    /// The resource pointed to by `fd` must be open and suitable for assuming
    /// [ownership][io-safety]. The resource must not require any cleanup other than `close`.
    ///
    /// [io-safety]: io#io-safety
    ///
    /// # Panics
    ///
    /// Panics if the raw file descriptor has the value `-1`.
    #[inline]
    #[track_caller]
    unsafe fn from_raw_fd(fd: RawFd) -> Self {
        Self { fd: ValidRawFd::new(fd).expect("fd != -1") }
    }
}

#[stable(feature = "io_safety", since = "1.63.0")]
impl Drop for OwnedFd {
    #[inline]
    #[rustdoc_skip_body]
    fn drop(&mut self) {
        unsafe {
            // Note that errors are ignored when closing a file descriptor. According to POSIX 2024,
            // we can and indeed should retry `close` on `EINTR`
            // (https://pubs.opengroup.org/onlinepubs/9799919799/functions/close.html),
            // but it is not clear yet how well widely-used implementations are conforming with this
            // mandate since older versions of POSIX left the state of the FD after an `EINTR`
            // unspecified. Ignoring errors is "fine" because some of the major Unices (in
            // particular, Linux) do make sure to always close the FD, even when `close()` is
            // interrupted, and the scenario is rare to begin with. If we retried on a
            // not-POSIX-compliant implementation, the consequences could be really bad since we may
            // close the wrong FD. Helpful link to an epic discussion by POSIX workgroup that led to
            // the latest POSIX wording: http://austingroupbugs.net/view.php?id=529
            #[cfg(not(target_os = "hermit"))]
            {
                #[cfg(unix)]
                crate::sys::fs::debug_assert_fd_is_open(self.fd.as_inner());

                let _ = libc::close(self.fd.as_inner());
            }
            #[cfg(target_os = "hermit")]
            let _ = hermit_abi::close(self.fd.as_inner());
        }
    }
}

#[stable(feature = "io_safety", since = "1.63.0")]
impl fmt::Debug for BorrowedFd<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("BorrowedFd").field("fd", &self.fd).finish()
    }
}

#[stable(feature = "io_safety", since = "1.63.0")]
impl fmt::Debug for OwnedFd {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("OwnedFd").field("fd", &self.fd).finish()
    }
}

macro_rules! impl_is_terminal {
    ($($t:ty),*$(,)?) => {$(
        #[stable(feature = "is_terminal", since = "1.70.0")]
        impl io::IsTerminal for $t {
            #[inline]
            fn is_terminal(&self) -> bool {
                crate::sys::io::is_terminal(self)
            }
        }
    )*}
}

impl_is_terminal!(BorrowedFd<'_>, OwnedFd);

/// A trait to borrow the file descriptor from an underlying object.
///
/// This is only available on unix platforms and must be imported in order to
/// call the method. Windows platforms have a corresponding `AsHandle` and
/// `AsSocket` set of traits.
#[stable(feature = "io_safety", since = "1.63.0")]
pub trait AsFd {
    /// Borrows the file descriptor.
    ///
    /// # Example
    ///
    /// ```rust,no_run
    /// use std::fs::File;
    /// # use std::io;
    /// # #[cfg(any(unix, target_os = "wasi"))]
    /// # use std::os::fd::{AsFd, BorrowedFd};
    ///
    /// let mut f = File::open("foo.txt")?;
    /// # #[cfg(any(unix, target_os = "wasi"))]
    /// let borrowed_fd: BorrowedFd<'_> = f.as_fd();
    /// # Ok::<(), io::Error>(())
    /// ```
    #[stable(feature = "io_safety", since = "1.63.0")]
    fn as_fd(&self) -> BorrowedFd<'_>;
}

#[stable(feature = "io_safety", since = "1.63.0")]
impl<T: AsFd + ?Sized> AsFd for &T {
    #[inline]
    fn as_fd(&self) -> BorrowedFd<'_> {
        T::as_fd(self)
    }
}

#[stable(feature = "io_safety", since = "1.63.0")]
impl<T: AsFd + ?Sized> AsFd for &mut T {
    #[inline]
    fn as_fd(&self) -> BorrowedFd<'_> {
        T::as_fd(self)
    }
}

#[stable(feature = "io_safety", since = "1.63.0")]
impl AsFd for BorrowedFd<'_> {
    #[inline]
    fn as_fd(&self) -> BorrowedFd<'_> {
        *self
    }
}

#[stable(feature = "io_safety", since = "1.63.0")]
impl AsFd for OwnedFd {
    #[inline]
    fn as_fd(&self) -> BorrowedFd<'_> {
        // Safety: `OwnedFd` and `BorrowedFd` have the same validity
        // invariants, and the `BorrowedFd` is bounded by the lifetime
        // of `&self`.
        unsafe { BorrowedFd::borrow_raw(self.as_raw_fd()) }
    }
}

#[stable(feature = "io_safety", since = "1.63.0")]
#[cfg(not(target_os = "trusty"))]
impl AsFd for fs::File {
    #[inline]
    #[rustdoc_skip_body]
    fn as_fd(&self) -> BorrowedFd<'_> {
        self.as_inner().as_fd()
    }
}

#[stable(feature = "io_safety", since = "1.63.0")]
#[cfg(not(target_os = "trusty"))]
impl From<fs::File> for OwnedFd {
    /// Takes ownership of a [`File`](fs::File)'s underlying file descriptor.
    #[inline]
    #[rustdoc_skip_body]
    fn from(file: fs::File) -> OwnedFd {
        file.into_inner().into_inner().into_inner()
    }
}

#[stable(feature = "io_safety", since = "1.63.0")]
#[cfg(not(target_os = "trusty"))]
impl From<OwnedFd> for fs::File {
    /// Returns a [`File`](fs::File) that takes ownership of the given
    /// file descriptor.
    #[inline]
    #[rustdoc_skip_body]
    fn from(owned_fd: OwnedFd) -> Self {
        Self::from_inner(FromInner::from_inner(FromInner::from_inner(owned_fd)))
    }
}

#[stable(feature = "io_safety", since = "1.63.0")]
#[cfg(not(target_os = "trusty"))]
impl AsFd for crate::net::TcpStream {
    #[inline]
    #[rustdoc_skip_body]
    fn as_fd(&self) -> BorrowedFd<'_> {
        self.as_inner().socket().as_fd()
    }
}

#[stable(feature = "io_safety", since = "1.63.0")]
#[cfg(not(target_os = "trusty"))]
impl From<crate::net::TcpStream> for OwnedFd {
    /// Takes ownership of a [`TcpStream`](crate::net::TcpStream)'s socket file descriptor.
    #[inline]
    #[rustdoc_skip_body]
    fn from(tcp_stream: crate::net::TcpStream) -> OwnedFd {
        tcp_stream.into_inner().into_socket().into_inner().into_inner()
    }
}

#[stable(feature = "io_safety", since = "1.63.0")]
#[cfg(not(target_os = "trusty"))]
impl From<OwnedFd> for crate::net::TcpStream {
    #[inline]
    #[rustdoc_skip_body]
    fn from(owned_fd: OwnedFd) -> Self {
        Self::from_inner(FromInner::from_inner(FromInner::from_inner(FromInner::from_inner(
            owned_fd,
        ))))
    }
}

#[stable(feature = "io_safety", since = "1.63.0")]
#[cfg(not(target_os = "trusty"))]
impl AsFd for crate::net::TcpListener {
    #[inline]
    #[rustdoc_skip_body]
    fn as_fd(&self) -> BorrowedFd<'_> {
        self.as_inner().socket().as_fd()
    }
}

#[stable(feature = "io_safety", since = "1.63.0")]
#[cfg(not(target_os = "trusty"))]
impl From<crate::net::TcpListener> for OwnedFd {
    /// Takes ownership of a [`TcpListener`](crate::net::TcpListener)'s socket file descriptor.
    #[inline]
    #[rustdoc_skip_body]
    fn from(tcp_listener: crate::net::TcpListener) -> OwnedFd {
        tcp_listener.into_inner().into_socket().into_inner().into_inner()
    }
}

#[stable(feature = "io_safety", since = "1.63.0")]
#[cfg(not(target_os = "trusty"))]
impl From<OwnedFd> for crate::net::TcpListener {
    #[inline]
    #[rustdoc_skip_body]
    fn from(owned_fd: OwnedFd) -> Self {
        Self::from_inner(FromInner::from_inner(FromInner::from_inner(FromInner::from_inner(
            owned_fd,
        ))))
    }
}

#[stable(feature = "io_safety", since = "1.63.0")]
#[cfg(not(target_os = "trusty"))]
impl AsFd for crate::net::UdpSocket {
    #[inline]
    #[rustdoc_skip_body]
    fn as_fd(&self) -> BorrowedFd<'_> {
        self.as_inner().socket().as_fd()
    }
}

#[stable(feature = "io_safety", since = "1.63.0")]
#[cfg(not(target_os = "trusty"))]
impl From<crate::net::UdpSocket> for OwnedFd {
    /// Takes ownership of a [`UdpSocket`](crate::net::UdpSocket)'s file descriptor.
    #[inline]
    #[rustdoc_skip_body]
    fn from(udp_socket: crate::net::UdpSocket) -> OwnedFd {
        udp_socket.into_inner().into_socket().into_inner().into_inner()
    }
}

#[stable(feature = "io_safety", since = "1.63.0")]
#[cfg(not(target_os = "trusty"))]
impl From<OwnedFd> for crate::net::UdpSocket {
    #[inline]
    #[rustdoc_skip_body]
    fn from(owned_fd: OwnedFd) -> Self {
        Self::from_inner(FromInner::from_inner(FromInner::from_inner(FromInner::from_inner(
            owned_fd,
        ))))
    }
}

/// Implements `AsRef<$t>` conversions from `BorrowedFd` to the specified types.
///
/// # Safety
///
/// It must be sound to transmute `&BorrowedFd` to `&$t`.
///
/// This typically implies that:
///
/// - $t must be a wrapper with `BorrowedFd`, `OwnedFd` or `RawFd` being the single non-ZST-field.
///   Nominally it also requires repr(transparent), but std can cheat because we can stay in
///   sync with rustc's layout implementation details.
/// - `&$t` must not have any methods that would allow closing the file descriptor.
/// - `&$t` impls must tolerate instances being created from any kind of file-descriptor without
///   going through some dedicated constructor function, akin to `From<OwnedFd>` being a noop
///   conversion.
pub(crate) macro unsafe_impl_fd_asrefs {
    ($($t:ty),*$(,)?) => {$(
        #[unstable(feature = "fd_view", issue = "160402")]
        #[unstable_feature_bound(fd_view)]
        impl AsRef<$t> for BorrowedFd<'_> {
            #[inline]
            fn as_ref(&self) -> &$t {
                use core::mem;

                // These are neither necessary nor sufficient, but generally
                // a type that implements them is more likely to have the required behavior.
                fn type_check<T: From<OwnedFd> + Into<OwnedFd> + AsFd>() {}

                // sanity check in case layouts change
                const {
                    assert!(mem::size_of::<RawFd>() == mem::size_of::<$t>());
                    assert!(mem::size_of::<RawFd>() == mem::size_of::<BorrowedFd<'_>>());
                }
                type_check::<$t>();
                // SAFETY: See macro-level requirements.
                unsafe { mem::transmute::<&BorrowedFd<'_>, &$t>(self) }
            }
        }
    )*}
}

#[cfg(not(target_os = "trusty"))]
unsafe_impl_fd_asrefs!(
    crate::fs::File,
    crate::net::TcpStream,
    crate::net::TcpListener,
    crate::net::UdpSocket,
);

#[cfg(unix)]
unsafe_impl_fd_asrefs!(io::PipeWriter, io::PipeReader);

#[stable(feature = "asfd_ptrs", since = "1.64.0")]
/// This impl allows implementing traits that require `AsFd` on Arc.
/// ```
/// # #[cfg(any(unix, target_os = "wasi"))] mod group_cfg {
/// # #[cfg(target_os = "wasi")]
/// # use std::os::wasi::io::AsFd;
/// # #[cfg(unix)]
/// # use std::os::unix::io::AsFd;
/// use std::net::UdpSocket;
/// use std::sync::Arc;
///
/// trait MyTrait: AsFd {}
/// impl MyTrait for Arc<UdpSocket> {}
/// impl MyTrait for Box<UdpSocket> {}
/// # }
/// ```
impl<T: AsFd + ?Sized> AsFd for crate::sync::Arc<T> {
    #[inline]
    fn as_fd(&self) -> BorrowedFd<'_> {
        (**self).as_fd()
    }
}

#[stable(feature = "asfd_rc", since = "1.69.0")]
impl<T: AsFd + ?Sized> AsFd for crate::rc::Rc<T> {
    #[inline]
    fn as_fd(&self) -> BorrowedFd<'_> {
        (**self).as_fd()
    }
}

#[unstable(feature = "unique_rc_arc", issue = "112566")]
impl<T: AsFd + ?Sized> AsFd for crate::rc::UniqueRc<T> {
    #[inline]
    fn as_fd(&self) -> BorrowedFd<'_> {
        (**self).as_fd()
    }
}

#[stable(feature = "asfd_ptrs", since = "1.64.0")]
impl<T: AsFd + ?Sized, A: Allocator> AsFd for Box<T, A> {
    #[inline]
    fn as_fd(&self) -> BorrowedFd<'_> {
        (**self).as_fd()
    }
}

#[stable(feature = "io_safety", since = "1.63.0")]
impl AsFd for io::Stdin {
    #[inline]
    fn as_fd(&self) -> BorrowedFd<'_> {
        unsafe { BorrowedFd::borrow_raw(0) }
    }
}

#[stable(feature = "io_safety", since = "1.63.0")]
impl<'a> AsFd for io::StdinLock<'a> {
    #[inline]
    fn as_fd(&self) -> BorrowedFd<'_> {
        // SAFETY: user code should not close stdin out from under the standard library
        unsafe { BorrowedFd::borrow_raw(0) }
    }
}

#[stable(feature = "io_safety", since = "1.63.0")]
impl AsFd for io::Stdout {
    #[inline]
    fn as_fd(&self) -> BorrowedFd<'_> {
        unsafe { BorrowedFd::borrow_raw(1) }
    }
}

#[stable(feature = "io_safety", since = "1.63.0")]
impl<'a> AsFd for io::StdoutLock<'a> {
    #[inline]
    fn as_fd(&self) -> BorrowedFd<'_> {
        // SAFETY: user code should not close stdout out from under the standard library
        unsafe { BorrowedFd::borrow_raw(1) }
    }
}

#[stable(feature = "io_safety", since = "1.63.0")]
impl AsFd for io::Stderr {
    #[inline]
    fn as_fd(&self) -> BorrowedFd<'_> {
        unsafe { BorrowedFd::borrow_raw(2) }
    }
}

#[stable(feature = "io_safety", since = "1.63.0")]
impl<'a> AsFd for io::StderrLock<'a> {
    #[inline]
    fn as_fd(&self) -> BorrowedFd<'_> {
        // SAFETY: user code should not close stderr out from under the standard library
        unsafe { BorrowedFd::borrow_raw(2) }
    }
}

#[stable(feature = "anonymous_pipe", since = "1.87.0")]
#[cfg(not(target_os = "trusty"))]
impl AsFd for io::PipeReader {
    #[rustdoc_skip_body]
    fn as_fd(&self) -> BorrowedFd<'_> {
        self.0.as_fd()
    }
}

#[stable(feature = "anonymous_pipe", since = "1.87.0")]
#[cfg(not(target_os = "trusty"))]
impl From<io::PipeReader> for OwnedFd {
    #[rustdoc_skip_body]
    fn from(pipe: io::PipeReader) -> Self {
        pipe.0.into_inner()
    }
}

#[stable(feature = "anonymous_pipe", since = "1.87.0")]
#[cfg(not(target_os = "trusty"))]
impl AsFd for io::PipeWriter {
    #[rustdoc_skip_body]
    fn as_fd(&self) -> BorrowedFd<'_> {
        self.0.as_fd()
    }
}

#[stable(feature = "anonymous_pipe", since = "1.87.0")]
#[cfg(not(target_os = "trusty"))]
impl From<io::PipeWriter> for OwnedFd {
    #[rustdoc_skip_body]
    fn from(pipe: io::PipeWriter) -> Self {
        pipe.0.into_inner()
    }
}

#[stable(feature = "anonymous_pipe", since = "1.87.0")]
#[cfg(not(target_os = "trusty"))]
impl From<OwnedFd> for io::PipeReader {
    fn from(owned_fd: OwnedFd) -> Self {
        Self(FromInner::from_inner(owned_fd))
    }
}

#[stable(feature = "anonymous_pipe", since = "1.87.0")]
#[cfg(not(target_os = "trusty"))]
impl From<OwnedFd> for io::PipeWriter {
    fn from(owned_fd: OwnedFd) -> Self {
        Self(FromInner::from_inner(owned_fd))
    }
}
